import React from 'react';
import { createRoot } from 'react-dom/client';
import { StoreProvider } from './state/store';
import { App } from './App';
import './styles/app.css';

const el = document.getElementById('root');
if (el) createRoot(el).render(<StoreProvider><App /></StoreProvider>);
