import React, { useMemo, useState } from 'react';
import type { IndicatorId } from '../data/config';
import { INDICATORS, formatIndicator } from '../data/indicators';
import { SNAPSHOT_LABEL, STOCK_BY_ID, formatPrice, priceSeries } from '../data/stocks';
import { UNIVERSE, evaluateStock, filteringOptions } from '../engine/screener';
import { getIndicatorValue } from '../engine/rules';
import { useStore } from '../state/store';
import { track } from '../state/analytics';
import { Button, Drawer, Tag } from '../ui/primitives';
import { IconBookmark, IconChevronLeft, IconInfo } from '../ui/icons';
import { PriceChart } from '../ui/icons';
import { LessonModal, MatchExplanation } from '../ui/explain';
import { CompanyLogo } from '../ui/companyLogo';

const RANGES: { id: '1M' | '6M' | '1Y'; label: string; points: number }[] = [
  { id: '1M', label: '1M', points: 22 },
  { id: '6M', label: '6M', points: 40 },
  { id: '1Y', label: '1Y', points: 60 },
];

const METRICS: IndicatorId[] = [
  'pe', 'pb', 'roe', 'patCagr3Y', 'revenueCagr3Y', 'debtToEquity',
  'volatility', 'rsi', 'marketCap', 'return1Y', 'return3Y', 'avgDailyValue',
];

export function StockDetailScreen({ id, onToast }: { id: string; onToast: (m: string) => void }) {
  const { state, dispatch } = useStore();
  const stock = STOCK_BY_ID[id];
  const [range, setRange] = useState<'1M' | '6M' | '1Y'>('1Y');
  const [lesson, setLesson] = useState<IndicatorId | null>(null);
  const [why, setWhy] = useState(false);
  const [watched, setWatched] = useState(false);

  // hooks run before any early return, so the order never changes between renders
  const active = filteringOptions(state.selections);
  const result = useMemo(() => (stock ? evaluateStock(stock, state.selections) : null), [id, state.selections]);
  const series = useMemo(
    () => (stock ? priceSeries(stock, RANGES.find((r) => r.id === range)!.points) : [1, 1]),
    [id, range],
  );

  if (!stock || !result) {
    return (
      <div className="shell page">
        <p className="muted">That company is not in the demo dataset.</p>
        <Button variant="outline" onClick={() => dispatch({ type: 'go', route: { name: 'screener' } })}>Back to screener</Button>
      </div>
    );
  }

  const rangeReturn = ((series[series.length - 1] - series[0]) / series[0]) * 100;
  const peerPE = UNIVERSE.median('pe', stock.sector);
  const sizeTag = stock.marketCap >= 100000 ? 'Large size' : stock.marketCap >= 20000 ? 'Mid size' : 'Small size';
  const shares = state.profile.amount ? Math.floor(state.profile.amount / stock.price) : null;

  return (
    <div className="page sd-page">
      <div className="shell shell--wide">
        <button className="link-btn link-btn--plain small" onClick={() => dispatch({ type: 'back' })} style={{ marginBottom: 16 }}>
          <IconChevronLeft size={14} /> Back
        </button>

        <div className="sd-wrap">
          <div className="sd-main">

        <div className="detail__head">
          <CompanyLogo stock={stock} size={52} />
          <div className="stack gap6 grow">
            <h1>{stock.name}</h1>
            <div className="row gap8 wrap">
              {active.length && result.exact ? <Tag tone="green">Matches your screen</Tag> : null}
              <Tag>{sizeTag}</Tag>
              <Tag>{stock.sector}</Tag>
              <Tag tone="amber">Demo data</Tag>
              {stock.listedYears < 3 ? <Tag tone="blue">Listed {stock.listedYears} years ago</Tag> : null}
              {stock.pe === null ? <Tag tone="red">Loss-making, so no P/E</Tag> : null}
            </div>
          </div>
          <button className={`sd-save${watched ? ' is-on' : ''}`} aria-pressed={watched}
            aria-label={watched ? 'Remove from your watchlist' : 'Add to watchlist'}
            onClick={() => { setWatched((w) => !w); track('watchlist_toggled', { id: stock.id, on: !watched }); onToast(watched ? 'Removed from your demo watchlist.' : 'Added to your demo watchlist.'); }}>
            <IconBookmark size={20} />
          </button>
        </div>

        <div className="detail__price">
          <b className="mono-num">{formatPrice(stock.price)}</b>
          <span className={`mono-num ${stock.changePct1D >= 0 ? 'pos' : 'neg'}`}>
            {stock.change1D >= 0 ? '+' : ''}{stock.change1D.toFixed(2)} ({stock.changePct1D.toFixed(2)}%) today
          </span>
        </div>

        <div className="chart-wrap card card__pad">
          <PriceChart series={series} up={rangeReturn >= 0} />
          <div className="range-row">
            {RANGES.map((r) => (
              <button key={r.id} className={`chip${range === r.id ? ' is-selected' : ''}`} onClick={() => setRange(r.id)}>{r.label}</button>
            ))}
          </div>
          <p className="tiny faint center" style={{ marginTop: 10 }}>
            {range} change {rangeReturn >= 0 ? '+' : ''}{rangeReturn.toFixed(1)}% · illustrative demo series pinned to the quoted price · snapshot {SNAPSHOT_LABEL}
          </p>
        </div>

        {active.length ? (
          <div className="card card__pad" style={{ marginTop: 18 }}>
            <div className="row gap16 wrap">
              <div className="stack gap4 grow">
                <span className={`match${result.exact ? '' : ' match--partial'}`} style={{ alignSelf: 'flex-start' }}>
                  {result.matchedCount} of {result.filterCount} of your conditions matched
                </span>
                <p className="small muted" style={{ marginTop: 6 }}>
                  {result.exact
                    ? 'Every condition in your screen was met by this company on the demo figures.'
                    : 'Some conditions were not met. The breakdown shows exactly which, and by how much.'}
                </p>
              </div>
              <Button variant="outline" size="sm"
                onClick={() => { track('stock_match_explanation_opened', { id: stock.id, from: 'detail' }); dispatch({ type: 'go', route: { name: 'whyMatched', stockId: stock.id } }); }}>
                Why it {result.exact ? 'matched' : 'did not match'}
              </Button>
            </div>
          </div>
        ) : null}

        <h2 style={{ margin: '26px 0 12px' }}>The numbers behind it</h2>
        <div className="metric-grid">
          {METRICS.map((m) => {
            const meta = INDICATORS[m];
            const value = getIndicatorValue(stock, m);
            return (
              <div key={m}>
                <button className="link-btn link-btn--plain tiny" style={{ textAlign: 'left' }}
                  onClick={() => { setLesson(m); track('indicator_lesson_opened', { indicator: m, from: 'stock_detail' }); }}>
                  {meta.name}
                </button>
                <span className="mono-num" style={{ color: 'var(--heading)', fontSize: 15 }}>{formatIndicator(m, value)}</span>
                {m === 'pe' && peerPE ? <span className="tiny faint">Sector peers {peerPE.toFixed(1)}x</span> : null}
                {m === 'rsi' ? <span className="tiny faint">{stock.rsi <= 30 ? 'In the oversold range' : stock.rsi >= 70 ? 'In the overbought range' : 'Middle of the range'}</span> : null}
              </div>
            );
          })}
        </div>
        <p className="tiny faint" style={{ marginTop: 10 }}>Tap any label to see what the number means, how to read it and where it misleads.</p>

        {shares !== null ? (
          <div className="notice notice--info" style={{ marginTop: 18 }}>
            <IconInfo />
            <div>
              <div>₹{state.profile.amount!.toLocaleString('en-IN')} would buy about {shares} {shares === 1 ? 'share' : 'shares'} at this price.</div>
              <div className="small muted">
                That is only an affordability note. Share price says nothing about whether a company is cheap or expensive — that is what the valuation comparison is for.
              </div>
            </div>
          </div>
        ) : null}

        {!stock.cfoPositive || stock.patCagr3Y === null ? (
          <div className="notice" style={{ marginTop: 12 }}>
            <IconInfo />
            <div>
              {stock.patCagr3Y === null ? 'This company has no meaningful profit growth figure in the demo data, usually because it is loss-making. ' : ''}
              {!stock.cfoPositive ? 'Cash from day-to-day operations is negative here. ' : ''}
              Any condition that needs those figures could not pass, because missing or negative data is never treated as a pass.
            </div>
          </div>
        ) : null}

        <div className="row gap8 wrap" style={{ marginTop: 22 }}>
          <Button variant="outline" onClick={() => dispatch({ type: 'go', route: { name: 'results' } })}>Back to results</Button>
          <Button variant="ghost" onClick={() => dispatch({ type: 'go', route: { name: 'screener' } })}>Edit my screen</Button>
        </div>
          </div>

          <aside className="sd-trade" aria-label="Trade panel">
            <div className="sd-trade__card">
              <div className="sd-trade__row">
                <span className="small muted">Price</span>
                <b className="mono-num">{formatPrice(stock.price)}</b>
              </div>
              <div className="sd-trade__row">
                <span className="small muted">Today</span>
                <span className={`mono-num ${stock.changePct1D >= 0 ? 'pos' : 'neg'}`}>
                  {stock.change1D >= 0 ? '+' : ''}{stock.change1D.toFixed(2)} ({stock.changePct1D.toFixed(2)}%)
                </span>
              </div>
              {shares !== null ? (
                <div className="sd-trade__row">
                  <span className="small muted">Your ₹{state.profile.amount!.toLocaleString('en-IN')} buys</span>
                  <span className="mono-num">{shares} {shares === 1 ? 'share' : 'shares'}</span>
                </div>
              ) : null}
              <div className="sd-trade__foot">
                <Button variant="primary" block className="btn--lg" disabled>Buy</Button>
                <p className="tiny faint" style={{ marginTop: 10, textAlign: 'center' }}>
                  Buying is not part of this prototype — these companies are invented.
                </p>
              </div>
            </div>

            <button className={`sd-watch${watched ? ' is-on' : ''}`}
              onClick={() => { setWatched((w) => !w); track('watchlist_toggled', { id: stock.id, on: !watched }); onToast(watched ? 'Removed from your demo watchlist.' : 'Added to your demo watchlist.'); }}>
              <IconBookmark size={17} /> {watched ? 'In your watchlist' : 'Add to watchlist'}
            </button>
          </aside>
        </div>
      </div>

      {why ? (
        <Drawer title={`Why ${stock.name} ${result.exact ? 'matched' : 'did not match'}`} subtitle="Condition by condition"
          onClose={() => setWhy(false)}
          footer={<Button variant="primary" className="grow" onClick={() => setWhy(false)}>Okay</Button>}>
          <MatchExplanation result={result} onIndicator={(id) => { setWhy(false); setLesson(id); }} />
        </Drawer>
      ) : null}

      {lesson ? <LessonModal indicatorId={lesson} stock={stock} selections={state.selections} onClose={() => setLesson(null)} /> : null}
    </div>
  );
}
