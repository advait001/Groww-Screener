import React, { useEffect, useRef, useState } from 'react';
import { PROFILE_QUESTIONS, profileSummary } from '../data/profile';
import { countMatches, filteringOptions, type Selections } from '../engine/screener';
import { STOCKS } from '../data/stocks';
import { sentenceText } from '../engine/sentence';
import { learnTitle, primaryIndicatorFor } from '../data/learning';
import { useStore } from '../state/store';
import { track } from '../state/analytics';
import { getIdentity, looksLikeEmail, setIdentity } from '../state/sheet';
import { Button, Chip, RadioRow } from '../ui/primitives';
import { IconArrowDown, IconChevronLeft, IconEdit, IconInfo, OptionIcon } from '../ui/icons';

/* ----------------------------------------------------------------- intro */

export function IntroScreen() {
  const { dispatch } = useStore();
  return (
    <div className="shell shell--wide">
      <div className="intro">
        <div className="intro__copy">
          <h1>Find stocks without speaking finance</h1>
          <p className="intro__sub">What kind of stock are you looking for?</p>
          <div className="intro__actions">
            <Button variant="primary" className="btn--lg"
              onClick={() => { track('onboarding_started'); dispatch({ type: 'go', route: { name: 'onboarding' } }); }}>
              Get started
            </Button>
            <Button variant="outline" className="btn--lg intro__alt"
              onClick={() => { track('onboarding_skipped', { from: 'intro' }); dispatch({ type: 'go', route: { name: 'screener' } }); }}>
              Explore the screener
            </Button>
          </div>
          <p className="intro__note">
            A prototype on 1,000 made-up companies with invented figures. It filters and explains. It never
            tells you what to buy.
          </p>
        </div>
        <div className="intro__art" aria-hidden="true"><DeskArt /></div>
      </div>
    </div>
  );
}

/**
 * The isometric desk from the reference: a tablet showing a rising line, a
 * calculator and a receipt. Drawn as flat shapes so it stays crisp at any size
 * and costs nothing to load.
 */
function DeskArt() {
  return (
    <svg viewBox="0 0 560 440" width="100%" height="100%" role="presentation" focusable="false">
      <defs>
        <linearGradient id="dk-scr" x1="0" y1="0" x2="0.6" y2="1">
          <stop offset="0" stopColor="#7a74ff" /><stop offset="1" stopColor="#4b45d8" />
        </linearGradient>
        <linearGradient id="dk-mint" x1="0" y1="0" x2="0.5" y2="1">
          <stop offset="0" stopColor="#3ae0b6" /><stop offset="1" stopColor="#0f9f7d" />
        </linearGradient>
      </defs>

      {/* ---- tablet, standing up: back face, then the screen on its front ---- */}
      <path d="M150 54l176 46v196l-176-46z" fill="#303138" />
      <path d="M326 100l58-34v196l-58 34z" fill="#1b1c21" />
      <path d="M150 54l58-34 176 46-58 34z" fill="#3c3d45" />
      <path d="M166 82l144 38v150l-144-38z" fill="#101116" />

      {/* purple app panel inside the screen */}
      <path d="M180 108l88 23v96l-88-23z" fill="url(#dk-scr)" />
      <path d="M190 198c14-20 20-52 32-48s16 36 30 16 20-44 30-56" fill="none"
        stroke="#ffffff" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" opacity="0.92" />
      <rect x="190" y="124" width="34" height="5" rx="2.5" fill="#ffffff" opacity="0.55" />

      {/* two small cards to the right of it */}
      <path d="M278 136l24 6v34l-24-6z" fill="url(#dk-mint)" />
      <path d="M284 158c4-6 6-14 9-13s4 10 8 6" fill="none" stroke="#06241c" strokeWidth="2.6" strokeLinecap="round" />
      <path d="M278 182l24 6v34l-24-6z" fill="#2b2c33" />
      <path d="M284 204c4-6 6-13 9-12s4 9 8 5" fill="none" stroke="#9aa0ab" strokeWidth="2.4" strokeLinecap="round" />

      {/* ---- calculator, lying flat ---- */}
      <path d="M300 300l92-52 96 56-92 52z" fill="#2b2c32" />
      <path d="M300 300v30l92 54v-32z" fill="#17181d" />
      <path d="M488 304v30l-96 52v-32z" fill="#101115" />
      <path d="M330 300l48-27 30 18-48 27z" fill="#0a0b0e" />
      <path d="M338 294l34-19 10 6-34 19z" fill="#2fd9ad" opacity="0.5" />
      <g fill="#eef0f3">
        <path d="M352 314l15-9 13 8-15 9zM376 328l15-9 13 8-15 9zM400 342l15-9 13 8-15 9z" />
        <path d="M378 300l15-9 13 8-15 9zM402 314l15-9 13 8-15 9z" />
        <path d="M404 286l15-9 13 8-15 9z" />
      </g>
      <path d="M428 300l15-9 13 8-15 9z" fill="#6a63f5" />

      {/* ---- receipt curling out of it ---- */}
      <path d="M470 296c20 14 24 40 10 56s-6 36 12 46l-40-23c-18-11-14-30 0-46s2-36-16-45z"
        fill="#dcdfe4" />
      <g stroke="#a7acb5" strokeWidth="2.4" strokeLinecap="round">
        <path d="M466 320l20 11M460 338l20 11M466 358l20 11" />
      </g>

      {/* ---- mint card deck in front ---- */}
      <path d="M176 322l80-46 66 38-80 46z" fill="url(#dk-mint)" />
      <path d="M176 322v22l80 40v-22z" fill="#0a6b55" />
      <path d="M256 362v22l66-40v-22z" fill="#0d8268" />
      <path d="M160 338l80-46 20 12-80 46z" fill="#24252b" />
      <path d="M160 338v20l80 40v-20z" fill="#15161a" />
      <circle cx="243" cy="312" r="13" fill="#063127" opacity="0.6" />

      {/* ---- cables ---- */}
      <path d="M150 250c-34 10-46 44-26 62" fill="none" stroke="#c9cdd4" strokeWidth="5" strokeLinecap="round" />
      <circle cx="128" cy="318" r="8" fill="#6a63f5" />
      <path d="M384 142c38 4 54 34 40 56" fill="none" stroke="#c9cdd4" strokeWidth="5" strokeLinecap="round" />
      <circle cx="420" cy="206" r="7" fill="#c9cdd4" />
    </svg>
  );
}

/* ------------------------------------------------------------ onboarding */

export function OnboardingScreen() {
  const { state, dispatch } = useStore();
  const step = state.onboardingStep;

  /**
   * Who is trying this comes first, as its own step in the same flow. It is
   * only asked once: a visitor who has already given their details drops
   * straight into the profile questions, and the step counter adjusts so it
   * never reads "step 2 of 5" with four questions left.
   */
  const asksContact = useRef(getIdentity() === null).current;
  const [onContact, setOnContact] = useState(asksContact);
  const offset = asksContact ? 1 : 0;
  const total = PROFILE_QUESTIONS.length + offset;

  if (onContact) {
    return (
      <ContactStep
        total={total}
        onNext={(name, email) => {
          setIdentity(name, email);
          track('visitor_identified', { hasName: name.length > 0 });
          setOnContact(false);
        }} />
    );
  }

  return <ProfileStep step={step} offset={offset} total={total}
    onBackToContact={asksContact ? () => setOnContact(true) : undefined} />;
}

/** Name and email, built from the same pieces as every other onboarding step. */
function ContactStep({ total, onNext }:
{ total: number; onNext: (name: string, email: string) => void }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [tried, setTried] = useState(false);
  const nameBad = tried && name.trim().length < 2;
  const emailBad = tried && !looksLikeEmail(email);

  const submit = () => {
    setTried(true);
    if (name.trim().length < 2 || !looksLikeEmail(email)) return;
    onNext(name.trim(), email.trim());
  };

  return (
    <div className="shell">
      <div className="onb">
        <div className="onb__bar"><span style={{ width: `${(1 / total) * 100}%` }} /></div>
        <div className="onb__step">
          <span className="small muted">Step 1 of {total}</span>
        </div>

        <h1>Let's set up your screener</h1>

        <form className="onb__contact" onSubmit={(e) => { e.preventDefault(); submit(); }}>
          <div className="onb__field">
            <label className="small muted" htmlFor="ob-name">Your name</label>
            <div className={`amount-field${nameBad ? ' is-bad' : ''}`}>
              <input id="ob-name" value={name} autoComplete="name" autoFocus
                placeholder="Priya Sharma" onChange={(e) => setName(e.target.value)} />
            </div>
            {nameBad ? <span className="onb__err">Please enter your name.</span> : null}
          </div>

          <div className="onb__field">
            <label className="small muted" htmlFor="ob-email">Email address</label>
            <div className={`amount-field${emailBad ? ' is-bad' : ''}`}>
              <input id="ob-email" value={email} type="email" inputMode="email" autoComplete="email"
                placeholder="priya@example.com" onChange={(e) => setEmail(e.target.value)} />
            </div>
            {emailBad ? <span className="onb__err">That does not look like an email address.</span> : null}
          </div>
        </form>

        <div className="onb__actions">
          <Button variant="primary" className="grow" onClick={submit}>Continue</Button>
        </div>
        <p className="small faint" style={{ marginTop: 10 }}>
          Demo data throughout — fictional companies and invented numbers.
        </p>
      </div>
    </div>
  );
}

function ProfileStep({ step, offset, total, onBackToContact }:
{ step: number; offset: number; total: number; onBackToContact?: () => void }) {
  const { state, dispatch } = useStore();
  const q = PROFILE_QUESTIONS[step];
  const value = state.profile[q.id];
  // the amount box mirrors the answer, so a preset lands in it and stays editable
  const [custom, setCustom] = useState(
    q.kind === 'amount' && typeof value === 'number' ? value.toLocaleString('en-IN') : '');
  const answered = value !== undefined && value !== '';

  const next = () => {
    track('onboarding_step_answered', { question: q.id, step: step + 1 });
    if (step === PROFILE_QUESTIONS.length - 1) {
      dispatch({ type: 'finishOnboarding' });
      track('onboarding_completed', { profile: state.profile });
      dispatch({ type: 'go', route: { name: 'summary' } });
    } else {
      dispatch({ type: 'onboardingStep', step: step + 1 });
    }
  };

  return (
    <div className="shell">
      <div className="onb">
        <div className="onb__bar"><span style={{ width: `${((step + 1 + offset) / total) * 100}%` }} /></div>
        <div className="onb__step">
          <span className="small muted">Step {step + 1 + offset} of {total}</span>
          <button className="link-btn link-btn--plain small"
            onClick={() => { track('onboarding_skipped', { atStep: step + 1 + offset }); dispatch({ type: 'go', route: { name: 'screener' } }); }}>
            Skip for now
          </button>
        </div>

        <h1>{q.title}</h1>
        <p className="onb__help">{q.help}</p>

        {q.kind === 'single' ? (
          <div className="onb__choices" role="radiogroup" aria-label={q.title}>
            {q.choices!.map((c) => (
              <RadioRow key={c.id} selected={value === c.id} label={c.label} note={c.note}
                onClick={() => dispatch({ type: 'profileField', field: q.id, value: c.id })} />
            ))}
          </div>
        ) : (
          <>
            <div className="amount-presets">
              {q.presets!.map((p) => (
                <Chip key={p} selected={value === p}
                  onClick={() => { setCustom(p.toLocaleString('en-IN')); dispatch({ type: 'profileField', field: q.id, value: p }); }}>
                  ₹{p.toLocaleString('en-IN')}
                </Chip>
              ))}
            </div>
            <label className="amount-field">
              <span className="muted">₹</span>
              <input
                inputMode="numeric"
                value={custom}
                placeholder="Another amount"
                aria-label="Custom amount"
                onChange={(e) => {
                  const digits = e.target.value.replace(/[^0-9]/g, '');
                  setCustom(digits);
                  dispatch({ type: 'profileField', field: q.id, value: digits ? Number(digits) : '' });
                }}
              />
            </label>
            <p className="small faint" style={{ marginTop: 10 }}>
              Nothing is invested and this does not change which stocks match. A lower share price does not make a company cheaper.
            </p>
          </>
        )}

        <div className="onb__actions">
          {step > 0 || onBackToContact ? (
            <Button variant="outline" onClick={() => (step > 0
              ? dispatch({ type: 'onboardingStep', step: step - 1 })
              : onBackToContact!())}>
              <IconChevronLeft /> Back
            </Button>
          ) : null}
          <Button variant="primary" className="grow" onClick={next} disabled={!answered && q.kind === 'single'}>
            {step === PROFILE_QUESTIONS.length - 1 ? 'See my profile' : 'Continue'}
          </Button>
        </div>
        {!answered && q.kind === 'amount' ? (
          <p className="small muted" style={{ marginTop: 10 }}>You can leave this blank and carry on.</p>
        ) : null}
      </div>
    </div>
  );
}

/* --------------------------------------------------------------- summary */

export function SummaryScreen() {
  const { state, dispatch } = useStore();
  const rows = profileSummary(state.profile);

  return (
    <div className="shell">
      <div className="onb">
        <h1>Your investing profile</h1>
        <p className="onb__help">
          Groww uses this to highlight a few options and to decide how much explaining to do. You still choose every filter yourself.
        </p>

        {rows.length ? (
          <div className="card" style={{ marginTop: 22 }}>
            {rows.map((r, i) => (
              <div className="card__row" key={r.fieldId} style={{ cursor: 'default', borderTop: i ? '1px solid var(--border)' : 0 }}>
                <span className="stack gap4">
                  <span className="small muted">{r.label}</span>
                  <span style={{ color: 'var(--heading)' }}>{r.value}</span>
                </span>
                <Button size="xs" variant="ghost"
                  onClick={() => {
                    const step = PROFILE_QUESTIONS.findIndex((q) => q.id === r.fieldId);
                    dispatch({ type: 'onboardingStep', step: Math.max(0, step) });
                    dispatch({ type: 'go', route: { name: 'onboarding' } });
                    track('profile_edit_opened', { field: r.fieldId });
                  }}>
                  <IconEdit /> Edit
                </Button>
              </div>
            ))}
          </div>
        ) : (
          <div className="card card__pad" style={{ marginTop: 22 }}>
            <p className="muted">You skipped the questions, which is fine. The screener works the same way without them.</p>
            <Button size="sm" variant="outline" style={{ marginTop: 12 }}
              onClick={() => { dispatch({ type: 'onboardingStep', step: 0 }); dispatch({ type: 'go', route: { name: 'onboarding' } }); }}>
              Answer them now
            </Button>
          </div>
        )}

        <div className="notice notice--info" style={{ marginTop: 18 }}>
          <IconInfo />
          <span>No label is attached to you, and nothing here picks stocks. Your answers only change which options are suggested and how much is explained.</span>
        </div>

        <div className="onb__actions">
          <Button variant="primary" className="grow" onClick={() => dispatch({ type: 'go', route: { name: 'screener' } })}>
            Open screener
          </Button>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------ processing */

const STEPS = [
  'Reading what you asked for',
  'Turning it into checks we can measure',
  `Looking at all ${STOCKS.length.toLocaleString('en-IN')} companies`,
  'Writing down why each one matched',
];

export function ProcessingScreen() {
  const { state, dispatch } = useStore();
  const [i, setI] = useState(0);

  useEffect(() => {
    const timers = STEPS.map((_, n) => window.setTimeout(() => setI(n + 1), 260 * (n + 1)));
    const done = window.setTimeout(() => {
      const count = countMatches(state.selections);
      dispatch({ type: 'recordRun', count });
      dispatch({ type: 'go', route: { name: 'results' } });
    }, 1180);
    return () => { timers.forEach(clearTimeout); clearTimeout(done); };
  }, []);

  return (
    <div className="shell">
      <div className="processing">
        <h1>Running your screen</h1>
        <p className="muted" style={{ marginTop: 8 }}>{sentenceText(state.selections)}</p>
        <div className="processing__steps">
          {STEPS.map((s, n) => (
            <div key={s} className={`processing__step${n < i ? ' is-done' : ''}${n === i ? ' is-active' : ''}`}>
              {n === i ? <span className="spinner" /> : <span style={{ width: 18, textAlign: 'center' }}>{n < i ? '✓' : '·'}</span>}
              <span>{s}</span>
            </div>
          ))}
        </div>
        <p className="tiny faint" style={{ marginTop: 22 }}>
          {filteringOptions(state.selections).length} filters · made-up data, worked out right here in your browser
        </p>
      </div>
    </div>
  );
}
