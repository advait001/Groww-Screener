import React, { useEffect, useMemo, useRef, useState } from 'react';
import type { CategoryId, IndicatorId, Option } from '../data/config';
import { CATEGORIES, OPTION_BY_ID, OPTIONS, SUMMARY_PHRASES } from '../data/config';
import { learnTitle, primaryIndicatorFor } from '../data/learning';
import { TEMPLATES } from '../data/templates';
import { STOCKS, formatPrice } from '../data/stocks';
import type { Stock } from '../data/stocks';
import { profileSummary, suggestedOptionIds } from '../data/profile';
import {
  conflicts, countMatches, filteringOptions, runScreener, selectedOptions, sortResults, type StockResult,
} from '../engine/screener';
import { plainSummary, screenName, shortLabel } from '../engine/sentence';
import { useStore } from '../state/store';
import { track } from '../state/analytics';
import { Button, Drawer, Modal, Tag } from '../ui/primitives';
import {
  IconArrowRight, IconBook, IconBookmark, IconBulb, IconCheck, IconChevronDown, IconChevronRight, IconClose,
  IconInfo, IconPlay, IconPlus, IconTrash, IconUser, OptionIcon,
} from '../ui/icons';
import { FilterPicker } from '../ui/filterPicker';
import { CompanyLogo } from '../ui/companyLogo';
import { OptionExplainer, LessonModal } from '../ui/explain';
import { CoachMarks, type CoachStep } from '../ui/chrome';
import { Stage, StageStrip } from '../ui/sidebars';

const COACH: CoachStep[] = [
  { target: 'add', title: 'Pick what you want', body: 'Open this to see every filter, sorted into simple groups.' },
  { target: 'statement', title: 'It reads back as a sentence', body: 'Tap any word in the sentence to see what it means.' },
  { target: 'run', title: 'Run it when you are ready', body: 'Pick at least two. The count updates as you go.' },
];

const sizeTag = (s: Stock) => (s.marketCap >= 100000 ? 'Large cap' : s.marketCap >= 20000 ? 'Mid cap' : 'Small cap');

export function ScreenerScreen({ onToast }: { onToast: (m: string) => void }) {
  const { state, dispatch } = useStore();
  const { selections, profile } = state;

  const [pickerOpen, setPickerOpen] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [swapOpen, setSwapOpen] = useState<CategoryId | null>(null);
  const [lesson, setLesson] = useState<IndicatorId | null>(null);
  const [explainOption, setExplainOption] = useState<string | null>(null);
  const [guideOpen, setGuideOpen] = useState(false);
  const [templatesOpen, setTemplatesOpen] = useState(false);
  const [savedOpen, setSavedOpen] = useState(false);
  const [coachReplay, setCoachReplay] = useState(false);
  const [watched, setWatched] = useState<string[]>([]);

  const suggestions = useMemo(() => suggestedOptionIds(profile), [profile]);
  const chosen = useMemo(() => selectedOptions(selections), [selections]);
  const active = useMemo(() => filteringOptions(selections), [selections]);
  const conflictNotes = useMemo(() => conflicts(selections), [selections]);
  const run = useMemo(() => runScreener(selections), [selections]);
  const canRun = active.length >= 2;

  /** one headline indicator per active filter, shown as the translation preview */
  const checkIndicators = useMemo(() => {
    const out: IndicatorId[] = [];
    for (const o of active) {
      const primary = primaryIndicatorFor(o);
      if (primary && !out.includes(primary)) out.push(primary);
    }
    return out;
  }, [active]);

  const previewRows: StockResult[] = useMemo(() => {
    if (active.length) return sortResults(run.exact, 'relevance').slice(0, 4);
    return sortResults(
      STOCKS.map((s) => ({ stock: s, conditions: [], matchedCount: 0, filterCount: 0, exact: true })),
      'marketCap',
    ).slice(0, 4);
  }, [run.exact, active.length]);

  useEffect(() => { track('screener_opened', { returning: state.sessions > 1 }); }, []);
  useEffect(() => { if (conflictNotes.length) track('conflict_shown', { pairs: conflictNotes.length }); }, [conflictNotes.length]);

  const pick = (optionId: string, from: 'tap' | 'drop' | 'keyboard') => {
    const option = OPTION_BY_ID[optionId];
    const wasSelected = selections[option.categoryId] === optionId;
    dispatch({ type: 'select', category: option.categoryId, optionId });
    track(
      wasSelected ? 'screener_option_removed' : from === 'drop' ? 'screener_option_dropped' : 'screener_option_selected',
      { option: optionId, category: option.categoryId, from },
    );
  };

  const runScreen = (from: string) => {
    if (!canRun) {
      onToast('Pick at least two filters — one on its own is not much of a screen.');
      return;
    }
    track('screener_run', { conditions: active.length, from });
    dispatch({ type: 'go', route: { name: 'processing' } });
  };

  const applyTemplate = (id: string, from: 'drawer' | 'statement' = 'drawer') => {
    const tpl = TEMPLATES.find((t) => t.id === id)!;
    dispatch({ type: 'setSelections', selections: tpl.selections });
    setPickerOpen(false);
    setTemplatesOpen(false);
    track('template_applied', { template: id, from });
    onToast(`“${tpl.name}” loaded — ${countMatches(tpl.selections)} companies match. Edit anything, then run it.`);
  };

  const openStock = (id: string) => {
    track('stock_detail_opened', { id, from: 'preview' });
    dispatch({ type: 'go', route: { name: 'stock', id } });
  };

  const profileRows = profileSummary(profile);
  /** starter tips are shown on the first visit only, then the space goes back to the workspace */
  const showTips = !state.tipsDone && state.sessions <= 1;

  return (
    <div className="ex-page">
      <div className="shell shell--wide">
        <div className="ex-wrap">

          {/* ============================================ main column */}
          <div className="ex-main">
            <header className="ex-head">
              <h1>Find stocks that fit you</h1>
              <p>What kind of stock are you looking for?</p>
            </header>

            {chosen.length ? (
              <>
                <div className="ex-filters__head" data-coach="add">
                  <h2>Your filters</h2>
                  <span className="ex-filters__count">{active.length} of {CATEGORIES.length}</span>
                  <button className="link-btn small"
                    onClick={() => { dispatch({ type: 'resetSelections' }); track('screener_reset', { from: 'filters_head' }); }}>
                    Clear all
                  </button>
                </div>

                <div className="ex-filters"
                  onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                  onDragLeave={() => setDragOver(false)}
                  onDrop={(e) => {
                    e.preventDefault(); setDragOver(false);
                    const id = e.dataTransfer.getData('text/plain');
                    if (OPTION_BY_ID[id]) pick(id, 'drop');
                  }}
                  data-drop="statement">
                  {chosen.map((o) => (
                    <FilterCard key={o.id} option={o}
                      open={swapOpen === o.categoryId}
                      onToggleSwap={() => setSwapOpen(swapOpen === o.categoryId ? null : o.categoryId)}
                      onPick={(id) => { pick(id, 'tap'); setSwapOpen(null); }}
                      onExplain={() => setExplainOption(o.id)}
                      onRemove={() => {
                        dispatch({ type: 'clearCategory', category: o.categoryId });
                        track('screener_option_removed', { option: o.id, from: 'filter_card' });
                      }} />
                  ))}
                </div>

                <button className={`ex-drop${dragOver ? ' is-over' : ''}`} data-picker-toggle
                  onClick={() => { setPickerOpen(true); track('filter_picker_opened', { from: 'dropzone' }); }}>
                  <IconPlus size={20} /> <span>Tap to add more filters</span>
                </button>
              </>
            ) : (
              <>
                <button className="ex-drop ex-drop--first" data-picker-toggle data-coach="add"
                  onClick={() => { setPickerOpen(true); track('filter_picker_opened', { from: 'dropzone' }); }}>
                  <IconPlus size={22} /> <span>Tap to add filters</span>
                </button>

                <div className="ex-sec-head">
                  <h2>Or start from a ready-made set</h2>
                  <button className="link-btn small"
                    onClick={() => { setTemplatesOpen(true); track('templates_opened', { from: 'explore' }); }}>
                    See all {TEMPLATES.length}
                  </button>
                </div>

                <div className="ex-tpl-grid">
                  {TEMPLATES.slice(0, 6).map((t) => {
                    const opts = filteringOptions(t.selections);
                    return (
                      <article className={`ex-tpl cat-${t.accent}`} key={t.id}>
                        <span className="ex-tpl__icon"><OptionIcon name={t.icon} size={20} /></span>
                        <h3>{t.name}</h3>
                        <span className="ex-tpl__tags">
                          {opts.slice(0, 3).map((o) => (
                            <span className="ex-tpl__tag" key={o.id}>{o.chip}</span>
                          ))}
                        </span>
                        <p>{t.description}</p>
                        <button className="ex-tpl__add" aria-label={`Use ${t.name}`}
                          onClick={() => applyTemplate(t.id, 'drawer')}>
                          <IconPlus size={16} />
                        </button>
                      </article>
                    );
                  })}
                </div>
              </>
            )}

            {conflictNotes.map((c, i) => (
              <div className="notice" key={i} style={{ marginTop: 16 }}>
                <IconInfo />
                <div>
                  <div>{c.message}</div>
                  <div className="notice__actions">
                    <Button size="xs" variant="ghost" data-picker-toggle onClick={() => setPickerOpen(true)}>
                      Change {c.changeCategoryLabel.toLowerCase()}
                    </Button>
                  </div>
                </div>
              </div>
            ))}

            {/* --------------------------------------- stock preview */}
            <section className="ex-sec" aria-labelledby="preview-title">
              <div className="ex-sec-head">
                <div className="stack gap4">
                  <h2 id="preview-title">{active.length ? 'A few that match' : 'Safe stocks to start with'}</h2>
                  <p className="small muted">
                    {active.length
                      ? 'A sample of what your filters find. Run the screen for the whole list.'
                      : 'The biggest companies on the list. Add filters and this narrows down live.'}
                  </p>
                </div>
              </div>

              <div className="ex-stocks">
                {previewRows.map((r) => {
                  const st = r.stock;
                  return (
                    <button className="ex-stock" key={st.id} onClick={() => openStock(st.id)}>
                      <CompanyLogo stock={st} size={36} />
                      <span className="ex-stock__name">{st.name}</span>
                      <span className="ex-stock__price mono-num">{formatPrice(st.price)}</span>
                      <span className={`ex-stock__chg mono-num ${st.changePct1D >= 0 ? 'pos' : 'neg'}`}>
                        {st.changePct1D >= 0 ? '+' : ''}{st.changePct1D.toFixed(2)}%
                      </span>
                    </button>
                  );
                })}
                {!previewRows.length ? (
                  <p className="small muted">
                    Nothing matches every filter yet. Run the screen to see what to relax.
                  </p>
                ) : null}
              </div>

              <button className="link-btn small" style={{ marginTop: 12 }}
                onClick={() => (active.length ? runScreen('preview') : setPickerOpen(true))}>
                {active.length ? 'See all results' : 'See more'} <IconChevronRight size={13} />
              </button>
            </section>
          </div>

          {/* ============================================ right rail */}
          <aside className="ex-rail" aria-label="Your screen">
            <section className="ex-sentence" data-coach="statement">
              <span className="ex-sentence__art" aria-hidden="true"><TowerArt /></span>
              <p className="ex-sentence__lead">Show me companies that are</p>

              {active.length ? (
                <>
                  <p className="ex-sentence__body">
                    {chosen.map((o, i) => (
                      <React.Fragment key={o.id}>
                        {i > 0 ? <span className="ex-sentence__join">{i === chosen.length - 1 ? ' and ' : ', '}</span> : null}
                        <button className={`ex-sentence__word cat-${o.categoryId}`}
                          onClick={() => setExplainOption(o.id)}
                          aria-label={`What does "${o.chip}" mean?`}>
                          {SUMMARY_PHRASES[o.id] ?? o.chip}
                        </button>
                      </React.Fragment>
                    ))}
                    <span className="ex-sentence__join">.</span>
                  </p>
                  <p className="ex-sentence__count">
                    {run.exact.length.toLocaleString('en-IN')} {run.exact.length === 1 ? 'match' : 'matches'}
                  </p>
                </>
              ) : (
                <p className="ex-sentence__empty">Add a filter to start the sentence</p>
              )}

              <div className="ex-sentence__foot" data-coach="run">
                <Button variant="primary" block className="btn--lg" disabled={!canRun}
                  onClick={() => runScreen('rail')}>
                  Run Screener
                </Button>
                {active.length && !canRun ? (
                  <p className="tiny faint" style={{ marginTop: 8, textAlign: 'center' }}>Add one more filter to run</p>
                ) : null}
              </div>
            </section>

            <button className="ex-goal" data-coach="goal" onClick={() => {
              track('goal_planner_opened', { from: 'rail' });
              dispatch({ type: 'go', route: { name: 'goal' } });
            }}>
              <span className="stack gap4 grow">
                <b>Invest for a goal</b>
                <span className="small muted">Saving up for something? We will do the maths</span>
                <span className="ex-goal__steps">4 quick questions</span>
              </span>
              <span className="ex-goal__art" aria-hidden="true"><GoalArt /></span>
            </button>

            <div className="ex-rail-sec">
              <h2>Beginner's guide</h2>
              <button className="ex-link-card" onClick={() => { setGuideOpen(true); track('indicator_lesson_opened', { from: 'rail_guide' }); }}>
                <span className="ex-link-card__icon tone-blue"><IconBook size={17} /></span>
                <span className="grow">How the screener works</span>
                <IconChevronRight size={16} />
              </button>
              <button className="ex-link-card" onClick={() => {
                track('profile_edit_opened', { from: 'rail' });
                dispatch({ type: 'go', route: { name: profileRows.length ? 'summary' : 'onboarding' } });
              }}>
                <span className="ex-link-card__icon tone-purple"><IconUser size={17} /></span>
                <span className="grow">{profileRows.length ? 'Your answers' : 'Tell us about you'}</span>
                <IconChevronRight size={16} />
              </button>
            </div>

            <div className="ex-rail-sec">
              <h2>Ready-made sets</h2>
              <button className="ex-link-card" onClick={() => { setTemplatesOpen(true); track('templates_opened', { from: 'rail' }); }}>
                <span className="ex-link-card__icon tone-green"><IconBulb size={17} /></span>
                <span className="grow">Filters already picked for you</span>
                <IconChevronRight size={16} />
              </button>
            </div>

            {state.saved.length ? (
              <div className="ex-rail-sec">
                <h2>Your saved screens</h2>
                <button className="ex-link-card" onClick={() => setSavedOpen(true)}>
                  <span className="ex-link-card__icon tone-purple"><IconBookmark size={17} /></span>
                  <span className="grow">{state.saved.length} saved {state.saved.length === 1 ? 'screen' : 'screens'}</span>
                  <IconChevronRight size={16} />
                </button>
              </div>
            ) : null}
          </aside>
        </div>
      </div>

      {/* --------------------------------------------- sticky (mobile) */}
      <div className="sc-sticky">
        <div className="stack gap4 grow" style={{ minWidth: 0 }}>
          <span className="tiny faint">{active.length} selected · {active.length ? run.exact.length : STOCKS.length} match now</span>
          <span className="small" style={{ color: 'var(--heading)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {chosen.length ? shortLabel(selections) : 'No filters yet'}
          </span>
        </div>
        <Button size="sm" variant="primary" disabled={!canRun} onClick={() => runScreen('sticky')}>Run</Button>
      </div>

      {pickerOpen ? (
        <FilterPicker
          selections={selections}
          suggestions={suggestions}
          onToggle={(id, from) => pick(id, from)}
          onClearAll={() => { dispatch({ type: 'resetSelections' }); track('screener_reset', { from: 'picker' }); }}
          onClose={() => setPickerOpen(false)}
        />
      ) : null}

      {templatesOpen ? (
        <Drawer title="Guided templates" subtitle="A ready-made set of filters you can edit afterwards" wide
          onClose={() => setTemplatesOpen(false)}
          footer={<Button variant="primary" className="grow" onClick={() => setTemplatesOpen(false)}>Close</Button>}>
          <div className="tpl-grid">
            {TEMPLATES.map((t) => {
              const opts = filteringOptions(t.selections);
              return (
                <button className={`tpl-card cat-${t.accent}`} key={t.id}
                  onClick={() => applyTemplate(t.id, 'drawer')}>
                  <span className="tpl-card__count">{opts.length} filters</span>
                  <span className="tpl-card__title">{t.name}</span>
                  <span className="tpl-card__theme">{t.theme}</span>
                  <span className="tpl-card__filters">{opts.map((o) => o.chip).join(' · ')}</span>
                  <span className="tpl-card__foot">
                    <span className="tpl-card__pill">Use this <IconArrowRight size={12} /></span>
                  </span>
                </button>
              );
            })}
          </div>
        </Drawer>
      ) : null}

      {savedOpen ? (
        <Drawer title="My screeners" subtitle="Screens you saved from the results page"
          onClose={() => setSavedOpen(false)}
          footer={<Button variant="primary" className="grow" onClick={() => setSavedOpen(false)}>Close</Button>}>
          {state.saved.length ? (
            <div className="stack gap12">
              {state.saved.map((sv) => {
                const filters = filteringOptions(sv.selections);
                const shownChips = filters.slice(0, 4);
                const extra = filters.length - shownChips.length;
                return (
                  <div className="saved-card" key={sv.id}>
                    <div className="saved-card__head">
                      <b>{screenName(sv.selections)}</b>
                      <span className="count-badge">{countMatches(sv.selections)} match now</span>
                    </div>
                    <span className="tiny faint">
                      {new Date(sv.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
                      {' · '}{filters.length} {filters.length === 1 ? 'filter' : 'filters'}
                    </span>
                    <div className="saved-card__chips">
                      {shownChips.map((o) => (
                        <span className={`stmt-chip cat-${o.categoryId}`} key={o.id} style={{ fontSize: 12 }}>
                          <OptionIcon name={o.icon} size={14} /> {o.chip}
                        </span>
                      ))}
                      {extra > 0 ? <span className="tiny faint">+{extra} more</span> : null}
                    </div>
                    <div className="saved-card__foot">
                      <Button size="sm" variant="outline"
                        onClick={() => { dispatch({ type: 'setSelections', selections: sv.selections }); setSavedOpen(false); track('screener_edited', { from: 'saved' }); }}>
                        Load
                      </Button>
                      <Button size="sm" variant="primary"
                        onClick={() => {
                          dispatch({ type: 'setSelections', selections: sv.selections });
                          dispatch({ type: 'go', route: { name: 'processing' } });
                          track('saved_screen_run', { id: sv.id });
                        }}>
                        <IconPlay size={13} /> Run
                      </Button>
                      <button className="saved-card__del" aria-label={`Delete ${screenName(sv.selections)}`}
                        onClick={() => { dispatch({ type: 'deleteScreen', id: sv.id }); track('screener_deleted', { id: sv.id }); }}>
                        <IconTrash size={15} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="small muted">
              Nothing saved yet. Run a screen and use “Save screen” on the results page to keep it here.
            </p>
          )}
        </Drawer>
      ) : null}

      {explainOption ? (
        <OptionExplainer
          optionId={explainOption}
          selections={selections}
          selected={selections[OPTION_BY_ID[explainOption].categoryId] === explainOption}
          onToggle={(id) => pick(id, 'tap')}
          onIndicator={(id) => { setExplainOption(null); setLesson(id); }}
          onClose={() => setExplainOption(null)} />
      ) : null}

      {guideOpen ? (
        <Modal
          title="How the screener works"
          subtitle="There is no video in this prototype — here is the two-minute version in writing"
          onClose={() => setGuideOpen(false)}
          footer={
            <>
              <Button variant="tint" onClick={() => { setGuideOpen(false); setCoachReplay(true); }}>Replay the quick tour</Button>
              <Button variant="primary" className="grow" onClick={() => setGuideOpen(false)}>Okay</Button>
            </>
          }
        >
          <ol className="stack gap16" style={{ paddingLeft: 18, margin: 0 }}>
            <li><b style={{ color: 'var(--heading)', fontWeight: 500 }}>Pick what matters to you.</b>
              <p className="small muted">Six categories in the sidebar, all optional. One filter each, in plain English.</p></li>
            <li><b style={{ color: 'var(--heading)', fontWeight: 500 }}>Read the summary.</b>
              <p className="small muted">“Your screen at a glance” shows the sentence you built and the financial check behind each choice.</p></li>
            <li><b style={{ color: 'var(--heading)', fontWeight: 500 }}>Run and read the reasons.</b>
              <p className="small muted">Each result shows how many filters it met, and “Why it matched” traces every rule with the actual number.</p></li>
            <li><b style={{ color: 'var(--heading)', fontWeight: 500 }}>Adjust and try again.</b>
              <p className="small muted">Too few results? The screen tells you which filter is holding the list back.</p></li>
          </ol>
          <p className="tiny faint" style={{ marginTop: 16 }}>
            A screener narrows a list. It does not tell you what to buy, and nothing here is a recommendation.
          </p>
        </Modal>
      ) : null}

      {lesson ? <LessonModal indicatorId={lesson} selections={selections} onClose={() => setLesson(null)} /> : null}

      {!state.coachDone || coachReplay ? (
        <CoachMarks steps={COACH} onDone={() => { dispatch({ type: 'coachDone' }); setCoachReplay(false); }} />
      ) : null}
    </div>
  );
}

/* ------------------------------------------------------------- fragments */

/**
 * One chosen filter. The category name doubles as a switch: tapping it opens a
 * short list of the other filters in that category, so a choice can be changed
 * without going back to the picker. The whole card is draggable, and the label
 * opens the plain-English explanation.
 */
function FilterCard({ option, open, onToggleSwap, onPick, onExplain, onRemove }: {
  option: Option;
  open: boolean;
  onToggleSwap: () => void;
  onPick: (id: string) => void;
  onExplain: () => void;
  onRemove: () => void;
}) {
  const category = CATEGORIES.find((c) => c.id === option.categoryId);
  const siblings = OPTIONS.filter((o) => o.categoryId === option.categoryId && o.rules.length);
  return (
    <div className={`fcard cat-${option.categoryId}${open ? ' is-open' : ''}`}>
      <span className="fcard__icon"><OptionIcon name={option.icon} size={18} /></span>
      <div className="fcard__body">
        <button className="fcard__cat" aria-expanded={open}
          aria-label={`Change the ${category?.label.toLowerCase()} filter`}
          onClick={onToggleSwap}>
          {category?.label}
          <IconChevronDown size={13} />
        </button>
        <button className="fcard__label" onClick={onExplain}
          aria-label={`What does "${option.chip}" mean?`}>
          {option.chip}
        </button>
      </div>
      <button className="fcard__x" aria-label={`Remove ${option.chip}`} onClick={onRemove}>
        <IconClose size={15} />
      </button>

      {open ? (
        <div className="fswap" role="dialog" aria-label={`${category?.label} filters`}>
          <div className="fswap__head">
            <b>{category?.label}</b>
            <button className="fswap__x" aria-label="Close" onClick={onToggleSwap}><IconClose size={13} /></button>
          </div>
          <ul className="fswap__list">
            {siblings.map((o) => {
              const on = o.id === option.id;
              return (
                <li key={o.id}>
                  <button className={`fswap__opt${on ? ' is-on' : ''}`} aria-pressed={on}
                    onClick={() => onPick(o.id)}>
                    <span className="fswap__dot" aria-hidden="true">{on ? <IconCheck size={11} /> : null}</span>
                    {o.label}
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      ) : null}
    </div>
  );
}

/** the stacked-tower mark that heads the sentence card in the reference */
function TowerArt() {
  return (
    <svg viewBox="0 0 72 76" width="64" height="68" aria-hidden="true" focusable="false">
      <defs>
        <linearGradient id="tw-a" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#8fe9d4" /><stop offset="1" stopColor="#1ea98a" />
        </linearGradient>
      </defs>
      <path d="M36 4l16 9v10L36 32 20 23V13z" fill="url(#tw-a)" />
      <path d="M20 23v30l16 9V32z" fill="#0f6f5c" />
      <path d="M52 23v30l-16 9V32z" fill="#17876f" />
      <path d="M26 34v18l6 3V37zM40 37v18l6-3V34z" fill="#bdf3e5" opacity="0.65" />
      <path d="M36 62v10M22 56l14 8M50 56l-14 8" stroke="#1ea98a" strokeWidth="1.4" opacity="0.5" fill="none" />
    </svg>
  );
}

/** the small chevron mark on the "invest for a goal" card */
function GoalArt() {
  return (
    <svg viewBox="0 0 56 44" width="52" height="41" aria-hidden="true" focusable="false">
      <path d="M4 30l12-12 8 8 10-14 10 10" fill="none" stroke="#2fd4ae" strokeWidth="5"
        strokeLinecap="round" strokeLinejoin="round" opacity="0.35" />
      <path d="M10 36l12-12 8 8 10-14 10 10" fill="none" stroke="#8ff0d8" strokeWidth="5"
        strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
