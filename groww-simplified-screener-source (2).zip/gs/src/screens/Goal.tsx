/**
 * Invest for a goal.
 *
 * Four questions — what for, how much, how long, how bumpy a ride you can
 * take — and the planner works out whether the monthly amount gets there,
 * then splits it across funds.
 *
 * The panel on the right is live from the first answer: it fills in as you go
 * and tells you straight away when the numbers do not work, rather than
 * waiting until the end. When the goal is out of reach it offers the four real
 * fixes, each with the number, and remembers what it changed so you can put it
 * back.
 */
import React, { useEffect, useMemo, useState } from 'react';
import {
  GOAL_CHIPS, GOAL_TYPES, HORIZON_TEXT, LIMITS, MIX_COUNT, MONTHLY_CHIPS, RISKS, YEAR_CHIPS,
  amcShort, clamp, durationText, evaluate, goalTypeById, horizonBand, inr, inrShort,
  futureValue, largestRemainder, mixRates, nextDebitDate, parseDigits, passedCount, pickFunds,
  riskById, trimNum,
  type GoalResult, type PlanSlice, type Suggestion, type SuggestionKind,
} from '../engine/goalPlan';
import type { RiskId } from '../data/funds';
import { useStore } from '../state/store';
import { track } from '../state/analytics';
import { Button, Drawer } from '../ui/primitives';
import {
  IconArrowRight, IconCheck, IconCheckCircle, IconChevronLeft, IconInfo, IconTarget,
} from '../ui/icons';

const pct1 = (rate: number) => trimNum(rate * 100, 1) + '%';

/** The planner keeps its answers while you wander off to the screener and back. */
const memory: {
  goalType: string | null; goal: number | null; years: number | null;
  monthly: number | null; risk: RiskId | null; step: 'form' | 'plan';
  mix: number; invested: { date: string } | null;
  changes: Partial<Record<SuggestionKind, number | RiskId>>;
} = {
  goalType: null, goal: null, years: null, monthly: null, risk: null,
  step: 'form', mix: 0, invested: null, changes: {},
};

/* ------------------------------------------------------------------ bits */

function GoalGlyph({ id, size = 24 }: { id: string; size?: number }) {
  const b = { fill: 'currentColor', opacity: 0.4 };
  const a = { fill: 'var(--green)' };
  const parts: Record<string, React.ReactNode> = {
    home: <>
      <path style={b} d="M3.5 11 L12 4 L20.5 11 V20 A1 1 0 0 1 19.5 21 H4.5 A1 1 0 0 1 3.5 20 Z" />
      <rect style={a} x="9.7" y="13.4" width="4.6" height="7.6" rx="1.1" />
    </>,
    car: <>
      <path style={b} d="M3 12.6 L5.2 7.6 A2 2 0 0 1 7 6.5 H17 A2 2 0 0 1 18.8 7.6 L21 12.6 V16.4 A1 1 0 0 1 20 17.4 H4 A1 1 0 0 1 3 16.4 Z" />
      <circle style={a} cx="7.4" cy="17.4" r="2.4" /><circle style={a} cx="16.6" cy="17.4" r="2.4" />
    </>,
    education: <>
      <path style={b} d="M12 4 L22 9 L12 14 L2 9 Z" />
      <path style={a} d="M6.5 11.2 V16 C6.5 17.6 9 19 12 19 C15 19 17.5 17.6 17.5 16 V11.2 L12 14 Z" />
    </>,
    retirement: <>
      <path style={b} d="M4 20 V12 A8 8 0 0 1 20 12 V20 Z" />
      <circle style={a} cx="12" cy="12.4" r="3.1" />
    </>,
    travel: <>
      <path style={b} d="M2.6 13.4 L21 5.4 A1.4 1.4 0 0 1 22.3 7.7 L10.5 19.2 L8.1 16 Z" />
      <path style={a} d="M8.1 16 L10.5 19.2 L7.2 21.4 Z" />
    </>,
    other: <>
      <circle style={b} cx="12" cy="12" r="8.4" />
      <circle style={a} cx="12" cy="12" r="3.2" />
    </>,
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true">
      {parts[id] ?? parts.other}
    </svg>
  );
}

/** A monogram tile for an invented fund house. */
function FundMark({ amc, tone }: { amc: string; tone: string }) {
  const letters = amcShort(amc).split(/\s+/).slice(0, 2).map((w) => w[0]).join('').toUpperCase();
  return (
    <span className="gp-mark" style={{ background: `color-mix(in srgb, ${tone} 20%, transparent)`, color: tone }}>
      {letters}
    </span>
  );
}

function Section({ n, title, sub, children }:
{ n: number; title: string; sub?: string; children: React.ReactNode }) {
  return (
    <section className="gp-sec">
      <div className="gp-sec__head">
        <span className="gp-sec__n">{n}</span>
        <div className="stack gap4">
          <b>{title}</b>
          {sub ? <span className="small muted">{sub}</span> : null}
        </div>
      </div>
      <div className="gp-sec__body">{children}</div>
    </section>
  );
}

function MoneyInput({ id, label, hideLabel, value, onChange, placeholder, error, flash, suffix, chips }: {
  id: string; label: string; hideLabel?: boolean; value: number | null;
  onChange: (v: number | null) => void; placeholder?: string; error?: string;
  flash?: boolean; suffix?: string; chips?: number[];
}) {
  return (
    <div className="stack gap8">
      <label htmlFor={id} className={hideLabel ? 'sr-only' : 'small muted'}>{label}</label>
      <div className={`gp-money${error ? ' is-bad' : ''}${flash ? ' is-flash' : ''}`}>
        <span className="gp-money__sym">₹</span>
        <input id={id} inputMode="numeric" autoComplete="off"
          value={value == null ? '' : value.toLocaleString('en-IN')}
          placeholder={placeholder}
          onChange={(e) => onChange(parseDigits(e.target.value))} />
        {suffix ? <span className="gp-money__suffix">{suffix}</span> : null}
      </div>
      {chips ? (
        <div className="gp-chips">
          {chips.map((c) => (
            <button key={c} type="button"
              className={`gp-chip${value === c ? ' is-on' : ''}`}
              onClick={() => onChange(c)}>{inrShort(c)}</button>
          ))}
        </div>
      ) : null}
      {error ? <span className="gp-err">{error}</span> : null}
    </div>
  );
}

/** A slider that moves fast at the low end, where most goals live. */
function LogSlider({ value, min, max, onChange, ends }: {
  value: number | null; min: number; max: number;
  onChange: (v: number) => void; ends: [string, string];
}) {
  const lo = Math.log(min), hi = Math.log(max);
  const pos = value == null ? 0 : ((Math.log(clamp(value, min, max)) - lo) / (hi - lo)) * 100;
  const round = (n: number) => {
    const step = n < 100_000 ? 5_000 : n < 1_000_000 ? 25_000 : n < 10_000_000 ? 100_000 : 500_000;
    return Math.round(n / step) * step;
  };
  return (
    <div className="gp-slider">
      <input type="range" min={0} max={100} step={0.5} value={pos}
        aria-label="Goal amount"
        onChange={(e) => onChange(round(Math.exp(lo + (Number(e.target.value) / 100) * (hi - lo))))} />
      <div className="gp-slider__ends"><span>{ends[0]}</span><span>{ends[1]}</span></div>
    </div>
  );
}

function YearsInput({ value, onChange, error, flash }: {
  value: number | null; onChange: (v: number | null) => void; error?: string; flash?: boolean;
}) {
  return (
    <div className="stack gap8">
      <div className={`gp-money${error ? ' is-bad' : ''}${flash ? ' is-flash' : ''}`}>
        <input id="gp-years" inputMode="numeric" autoComplete="off" aria-label="Number of years"
          value={value == null ? '' : String(value)} placeholder="10"
          onChange={(e) => {
            const n = parseDigits(e.target.value);
            onChange(n == null ? null : clamp(n, 0, 99));
          }} />
        <span className="gp-money__suffix">{value === 1 ? 'year' : 'years'}</span>
      </div>
      <div className="gp-chips">
        {YEAR_CHIPS.map((y) => (
          <button key={y} type="button" className={`gp-chip${value === y ? ' is-on' : ''}`}
            onClick={() => onChange(y)}>{y} years</button>
        ))}
      </div>
      {error ? <span className="gp-err">{error}</span> : null}
    </div>
  );
}

function RiskCards({ value, onChange, years, flash }: {
  value: RiskId | null; onChange: (v: RiskId) => void; years: number | null; flash?: boolean;
}) {
  return (
    <div className={`gp-risks${flash ? ' is-flash' : ''}`}>
      {RISKS.map((r) => {
        const on = value === r.id;
        const rate = years ? pct1(mixRates(r.id, years).base) : null;
        return (
          <button key={r.id} type="button" aria-pressed={on}
            className={`gp-risk${on ? ' is-on' : ''}`} onClick={() => onChange(r.id)}>
            <span className="gp-risk__top">
              <b>{r.label}</b>
              {rate ? <span className="gp-risk__rate">~{rate} a year</span> : null}
            </span>
            <span className="small muted">{r.blurb}</span>
          </button>
        );
      })}
    </div>
  );
}

/** Money in versus what it could become, with the goal line across it. */
function ProjectionChart({ monthly, months, rates, goal }: {
  monthly: number; months: number; rates: { low: number; base: number; high: number }; goal: number;
}) {
  const W = 320, H = 132, pad = 2;
  const steps = 28;
  const at = (i: number, rate: number) => futureValue(monthly, (months * i) / steps, rate);
  const reach = at(steps, rates.high);
  // When the goal towers over what the money reaches, a linear axis flattens
  // the curve into a line and the chart reads as broken. Cap the axis at the
  // projection and pin the goal to the top edge instead, labelled, so the gap
  // is still obvious but the shape of the growth survives.
  const far = goal > reach * 2.2;
  const top = (far ? reach : Math.max(reach, goal)) * 1.12;
  const x = (i: number) => pad + (i / steps) * (W - pad * 2);
  const y = (v: number) => H - pad - (Math.min(v, top) / top) * (H - pad * 2);
  const goalY = far ? pad + 7 : y(goal);
  const path = (rate: number) =>
    Array.from({ length: steps + 1 }, (_, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)} ${y(at(i, rate)).toFixed(1)}`).join(' ');
  const band = `${path(rates.high)} ` +
    Array.from({ length: steps + 1 }, (_, i) => steps - i)
      .map((i) => `L${x(i).toFixed(1)} ${y(at(i, rates.low)).toFixed(1)}`).join(' ') + ' Z';
  const paid = Array.from({ length: steps + 1 },
    (_, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)} ${y((monthly * months * i) / steps).toFixed(1)}`).join(' ');
  return (
    <svg className="gp-chart" viewBox={`0 0 ${W} ${H}`} role="img"
      aria-label={`Projection: about ${inrShort(at(steps, rates.base))} after ${durationText(months)}, against a goal of ${inrShort(goal)}`}>
      <path d={band} fill="var(--green)" opacity="0.13" />
      <path d={paid} fill="none" stroke="var(--text-3)" strokeWidth="1.6" strokeDasharray="3 3" />
      <path d={path(rates.base)} fill="none" stroke="var(--green)" strokeWidth="2.2" strokeLinecap="round" />
      <line x1={pad} x2={W - pad} y1={goalY} y2={goalY}
        stroke="var(--amber)" strokeWidth="1.4" strokeDasharray="5 4" />
      <text x={W - pad - 2} y={goalY - 5} textAnchor="end"
        fill="var(--amber)" fontSize="10" fontFamily="inherit">
        {far ? `goal ${inrShort(goal)} — far above` : `goal ${inrShort(goal)}`}
      </text>
    </svg>
  );
}

function ChartKey() {
  return (
    <div className="gp-key">
      <span><i className="gp-key__line" /> Could grow to</span>
      <span><i className="gp-key__dash" /> Money you put in</span>
      <span><i className="gp-key__goal" /> Your goal</span>
    </div>
  );
}

/* ------------------------------------------------- what the suggestions did */

const CHANGE_LABEL: Record<SuggestionKind, string> = {
  goal: 'Goal', years: 'How long', monthly: 'Every month', risk: 'Risk',
};

const changeText = (kind: SuggestionKind, v: number | RiskId) => {
  if (kind === 'goal') return inrShort(v as number);
  if (kind === 'monthly') return inr(v as number);
  if (kind === 'years') return `${v} ${v === 1 ? 'year' : 'years'}`;
  return riskById(v as RiskId)?.label ?? String(v);
};

interface ActiveChange { kind: SuggestionKind; from: string; }

function activeChanges(
  changes: Partial<Record<SuggestionKind, number | RiskId>>,
  now: { goal: number | null; years: number | null; monthly: number | null; risk: RiskId | null },
): ActiveChange[] {
  return (Object.keys(changes) as SuggestionKind[])
    .filter((k) => changes[k] !== undefined && changes[k] !== now[k])
    .map((k) => ({ kind: k, from: changeText(k, changes[k]!) }));
}

/* ----------------------------------------------------------- invest drawer */

function InvestDrawer({ rows, monthly, done, onClose, onConfirm, onHome }: {
  rows: (PlanSlice & { amount: number })[]; monthly: number;
  done: { date: string } | null; onClose: () => void;
  onConfirm: (date: string) => void; onHome: () => void;
}) {
  const date = nextDebitDate();
  return (
    <Drawer
      title={done ? 'Your monthly plans' : 'Start your monthly plans'}
      subtitle={done
        ? `Set up. First payment on ${done.date}.`
        : `${inr(monthly)} a month, split across ${rows.length} funds.`}
      onClose={onClose}
      footer={done ? (
        <Button variant="primary" className="grow" onClick={onHome}>Back to the screener</Button>
      ) : (
        <>
          <Button variant="outline" onClick={onClose}>Not yet</Button>
          <Button variant="primary" className="grow" onClick={() => onConfirm(date)}>
            Confirm {inr(monthly)} a month
          </Button>
        </>
      )}>
      <ul className="gp-confirm">
        {rows.map((r) => (
          <li key={r.fund.id}>
            <FundMark amc={r.fund.amc} tone={r.color} />
            <span className="stack gap4 grow">
              <b>{r.fund.name}</b>
              <span className="tiny muted">{r.cat}</span>
            </span>
            <b className="mono-num">{inr(r.amount)}</b>
          </li>
        ))}
      </ul>
      <div className="gp-confirm__foot">
        <div className="row gap8"><span className="grow muted">Every month</span><b className="mono-num">{inr(monthly)}</b></div>
        <div className="row gap8"><span className="grow muted">First payment</span><b>{date}</b></div>
      </div>
      <p className="tiny faint" style={{ marginTop: 14 }}>
        Nothing is really bought. These funds are invented for the prototype and no money moves.
      </p>
    </Drawer>
  );
}

/* ------------------------------------------------------------- the screens */

export function GoalScreen() {
  const [goalType, setGoalType] = useState(memory.goalType);
  const [goal, setGoal] = useState(memory.goal);
  const [years, setYears] = useState(memory.years);
  const [monthly, setMonthly] = useState(memory.monthly);
  const [risk, setRisk] = useState(memory.risk);
  const [step, setStep] = useState(memory.step);
  const [mix, setMix] = useState(memory.mix);
  const [invested, setInvested] = useState(memory.invested);
  const [changes, setChanges] = useState(memory.changes);
  const [flash, setFlash] = useState<SuggestionKind | null>(null);

  const check = useMemo(() => evaluate({ goal, years, monthly, risk }), [goal, years, monthly, risk]);

  useEffect(() => {
    Object.assign(memory, { goalType, goal, years, monthly, risk, step, mix, invested, changes });
  }, [goalType, goal, years, monthly, risk, step, mix, invested, changes]);
  useEffect(() => { window.scrollTo({ top: 0 }); }, [step]);
  useEffect(() => { track('goal_planner_viewed', {}); }, []);
  useEffect(() => { if (step === 'form') setInvested(null); }, [goal, years, monthly, risk]);

  const now = { goal, years, monthly, risk };
  const shownChanges = activeChanges(changes, now);

  const pickType = (t: typeof GOAL_TYPES[number]) => {
    setGoalType(t.id);
    if (t.amount) { setGoal(t.amount); setYears(t.years); }
    track('goal_type_picked', { type: t.id });
  };

  const apply = (sg: Suggestion) => {
    setChanges((c) => (sg.kind in c ? c : { ...c, [sg.kind]: now[sg.kind] as number | RiskId }));
    setFlash(sg.kind);
    window.setTimeout(() => setFlash((f) => (f === sg.kind ? null : f)), 1600);
    if (sg.kind === 'monthly') setMonthly(sg.value as number);
    if (sg.kind === 'years') setYears(sg.value as number);
    if (sg.kind === 'risk') setRisk(sg.value as RiskId);
    if (sg.kind === 'goal') setGoal(sg.value as number);
    track('goal_suggestion_applied', { kind: sg.kind, value: String(sg.value) });
  };

  if (step === 'plan' && check.ready && check.feasible) {
    return (
      <div className="sc-page"><div className="shell shell--wide">
        <PlanView
          goalType={goalType} goal={goal!} years={years!} monthly={monthly!} risk={risk!}
          check={check} mix={mix} setMix={setMix}
          invested={invested} setInvested={setInvested}
          onEdit={() => setStep('form')} changes={shownChanges} />
      </div></div>
    );
  }

  const done = [
    check.filled.goal && !check.errors.goal,
    check.filled.years && !check.errors.years,
    check.filled.monthly && !check.errors.monthly,
    check.filled.risk,
  ].filter(Boolean).length;
  const type = goalTypeById(goalType);
  const prefilled = type && type.amount && goal === type.amount && years === type.years;

  return (
    <div className="sc-page"><div className="shell shell--wide">
      <div className="gp">
        <header className="gp-hero">
          <div className="stack gap8">
            <span className="gp-kicker"><IconTarget size={15} /> Invest for a goal</span>
            <h1>What are you saving for?</h1>
            <p className="muted">
              Four quick questions. We check the numbers actually add up, then pick a set of
              funds to get you there.
            </p>
          </div>
          <HeroArt />
        </header>

        <div className="gp-grid">
          <div className="gp-form card">
            <div className="gp-form__top">
              <b>Your goal in 4 steps</b>
              <span className="gp-progress" aria-label={`${done} of 4 answered`}>
                <span className="gp-progress__bar"><i style={{ width: `${(done / 4) * 100}%` }} /></span>
                <span className="tiny faint">{done} of 4</span>
              </span>
            </div>

            <Section n={1} title="What is it for?" sub="Pick one, then put in how much you need.">
              <div className="gp-types">
                {GOAL_TYPES.map((t) => (
                  <button key={t.id} type="button" aria-pressed={goalType === t.id}
                    className={`gp-type${goalType === t.id ? ' is-on' : ''}`}
                    onClick={() => pickType(t)}>
                    <GoalGlyph id={t.id} />
                    <span>{t.label}</span>
                  </button>
                ))}
              </div>
              {prefilled ? (
                <p className="gp-typical">
                  We put in a usual {type!.label.toLowerCase()} amount. Change it to your own.
                </p>
              ) : null}
              <MoneyInput id="gp-goal" label="How much do you need?"
                value={goal} onChange={setGoal} placeholder="10,00,000"
                error={check.errors.goal} flash={flash === 'goal'} chips={GOAL_CHIPS} />
              <LogSlider value={goal} min={50_000} max={50_000_000}
                onChange={setGoal} ends={['₹50K', '₹5 Cr']} />
            </Section>

            <Section n={2} title="How long can you leave it alone?"
              sub="The longer you wait, the more the growth adds up.">
              <YearsInput value={years} onChange={setYears}
                error={check.errors.years} flash={flash === 'years'} />
            </Section>

            <Section n={3} title="How much can you put in each month?"
              sub="The least you are comfortable with. You can change it later.">
              <MoneyInput id="gp-monthly" label="Monthly amount" hideLabel
                value={monthly} onChange={setMonthly} placeholder="10,000"
                error={check.errors.monthly} flash={flash === 'monthly'}
                suffix="a month" chips={MONTHLY_CHIPS} />
            </Section>

            <Section n={4} title="How bumpy a ride can you take?"
              sub="More bounce can mean more growth, but the value drops harder on bad days.">
              <RiskCards value={risk} onChange={setRisk} years={years} flash={flash === 'risk'} />
            </Section>
          </div>

          <CheckPanel check={check} goal={goal} years={years} monthly={monthly} risk={risk}
            onApply={apply} onSubmit={() => {
              if (!(check.ready && check.feasible)) return;
              track('goal_plan_submitted', { goal: goal!, years: years!, monthly: monthly!, risk: risk! });
              setMix(0); setStep('plan');
            }} />
        </div>
      </div>
    </div></div>
  );
}

/* -------------------------------------------------------- the live panel */

function CheckPanel({ check, goal, years, monthly, risk, onApply, onSubmit }: {
  check: GoalResult; goal: number | null; years: number | null;
  monthly: number | null; risk: RiskId | null;
  onApply: (s: Suggestion) => void; onSubmit: () => void;
}) {
  if (!check.ready) {
    const left = 4 - [
      check.filled.goal && !check.errors.goal,
      check.filled.years && !check.errors.years,
      check.filled.monthly && !check.errors.monthly,
      check.filled.risk,
    ].filter(Boolean).length;
    return (
      <aside className="gp-check card">
        <span className="gp-status"><IconInfo size={13} /> Not enough yet</span>
        <p className="gp-check__empty">
          {left === 4
            ? 'Answer the questions and we will work out whether it adds up.'
            : `${left} more answer${left === 1 ? '' : 's'} and we can check this.`}
        </p>
        <ul className="gp-todo">
          {([['goal', 'What it is for and how much'], ['years', 'How long'],
            ['monthly', 'How much a month'], ['risk', 'How bumpy a ride']] as const).map(([k, label]) => {
            const ok = check.filled[k] && !(check.errors as Record<string, string>)[k];
            return (
              <li key={k} className={ok ? 'is-on' : ''}>
                {ok ? <IconCheck size={13} /> : <i className="gp-todo__dot" />}{label}
              </li>
            );
          })}
        </ul>
      </aside>
    );
  }

  const yearsWord = years === 1 ? 'year' : 'years';
  return (
    <aside className="gp-check card">
      <span className={`gp-status ${check.feasible ? 'is-ok' : 'is-short'}`}>
        {check.feasible ? <><IconCheckCircle size={13} /> This adds up</> : <><IconInfo size={13} /> Not quite enough</>}
      </span>

      <div className="gp-figure">
        <span className="gp-figure__num">≈ {inrShort(check.projected!)}</span>
        <span className="gp-figure__sub">
          after {years} {yearsWord}, from {inr(check.invested!)} put in
        </span>
      </div>

      <div className="gp-range">
        <span>If it goes badly<b>{inrShort(check.low!)}</b></span>
        <span>If it goes well<b>{inrShort(check.high!)}</b></span>
      </div>

      <ProjectionChart monthly={monthly!} months={check.months!} rates={check.rates!} goal={goal!} />
      <ChartKey />

      {check.feasible ? (
        <>
          <p className="gp-verdict">
            {check.safe
              ? <>You get there even if things go badly. </>
              : <>You get there in the usual case. If it goes badly you land near {inrShort(check.low!)}. </>}
            On the usual path you reach {inrShort(goal!)} in about {durationText(check.monthsToGoal!)}.
          </p>
          <Button variant="primary" block className="btn--lg" onClick={onSubmit}>
            Show me the funds <IconArrowRight size={16} />
          </Button>
        </>
      ) : (
        <>
          <p className="gp-verdict">
            You end up about <b>{inrShort(check.shortfall!)} short</b> of {inrShort(goal!)}.
            Here is what would close it — tap one and we will put the number in.
          </p>
          <ul className="gp-fixes">
            {check.suggestions!.map((s) => (
              <li key={s.kind}>
                <button type="button" onClick={() => onApply(s)}>
                  <span className="stack gap4 grow">
                    <b>{s.title}</b>
                    <span className="tiny muted">{s.sub}</span>
                  </span>
                  <IconArrowRight size={14} />
                </button>
              </li>
            ))}
          </ul>
        </>
      )}

      <p className="tiny faint gp-note">
        Growth is assumed at about {pct1(check.rates!.base)} a year for this mix, with a worse and a
        better case either side. Made-up numbers, not a promise.
      </p>
    </aside>
  );
}

/* ----------------------------------------------------------------- the plan */

function PlanView({ goalType, goal, years, monthly, risk, check, mix, setMix, invested, setInvested, onEdit, changes }: {
  goalType: string | null; goal: number; years: number; monthly: number; risk: RiskId;
  check: GoalResult; mix: number; setMix: (n: number) => void;
  invested: { date: string } | null; setInvested: (v: { date: string } | null) => void;
  onEdit: () => void; changes: ActiveChange[];
}) {
  const { state, dispatch } = useStore();
  const [open, setOpen] = useState(false);

  const plan = riskById(risk);
  const band = horizonBand(years);
  const base = useMemo(() => pickFunds(risk, years, mix % MIX_COUNT), [risk, years, mix]);
  const amounts = largestRemainder(base.map((r) => (monthly * r.pct) / 100), monthly);
  const rows = base.map((r, i) => ({ ...r, amount: amounts[i] }));
  const houses = new Set(rows.map((r) => r.fund.amc)).size;
  const equity = rows.filter((r) => r.type === 'Equity' || r.type === 'Index')
    .reduce((a, r) => a + r.pct, 0);
  const yearsWord = years === 1 ? 'year' : 'years';
  const name = goalTypeById(goalType)?.name;

  const goHome = () => dispatch({
    type: 'go', route: { name: state.onboardingComplete ? 'screener' : 'intro' },
  });

  const was = (k: SuggestionKind) => {
    const c = changes.find((x) => x.kind === k);
    return c ? <span className="gp-was">was {c.from}</span> : null;
  };

  return (
    <div className="gp-plan">
      <button type="button" className="link-btn small gp-back" onClick={onEdit}>
        <IconChevronLeft size={14} /> Change my goal
      </button>

      <header className="gp-head">
        <h1>{name
          ? `Your ${name} plan: ${inrShort(goal)} in ${years} ${yearsWord}`
          : `Your plan for ${inrShort(goal)} in ${years} ${yearsWord}`}</h1>
        <p className="muted">A set of funds matched to how long you have and how much bounce you can take.</p>
      </header>

      {changes.length ? (
        <div className="gp-changes">
          <b className="small">Changed to make it add up</b>
          <ul>
            {changes.map((c) => (
              <li key={c.kind}><span>{CHANGE_LABEL[c.kind]}</span><i>was {c.from}</i></li>
            ))}
          </ul>
        </div>
      ) : null}

      {invested ? (
        <div className="gp-banner">
          <IconCheckCircle size={16} />
          <span className="grow">Your monthly plans are set up. First payment on {invested.date}.</span>
          <button type="button" className="gp-banner__home" onClick={goHome}>
            Back to the screener <IconArrowRight size={13} />
          </button>
        </div>
      ) : null}

      <div className="gp-grid">
        <div className="gp-plan__main">
          <section className="card card__pad gp-block">
            <div className="gp-block__head">
              <h2>How these funds were picked</h2>
              <span className="tiny faint">{passedCount()} of 500 funds get through</span>
            </div>
            <div className="gp-rules">
              <span className="gp-rule is-key">{plan.label} · {HORIZON_TEXT[band]}</span>
              <span className="gp-rule">Big enough — ₹500 crore or more</span>
              <span className="gp-rule">Yearly fee of 0.75% or less</span>
              <span className="gp-rule">Has paid off for the risk it took</span>
            </div>
            <p className="small muted">
              How long you have and how much bounce you can take decide which kinds of fund go in
              and how much of your money each one gets. Inside every kind we take the fund that has
              paid off best for the risk it took, then the cheaper one — and never two from the same
              fund house.
            </p>
          </section>

          <section className="card card__pad gp-block">
            <div className="gp-block__head">
              <div className="stack gap4">
                <h2>Your funds</h2>
                <span className="tiny faint">
                  {rows.length} funds from {houses} fund houses · {equity > 0
                    ? `${equity}% in share funds`
                    : 'all steadier funds, no pure share funds'} · set {(mix % MIX_COUNT) + 1} of {MIX_COUNT}
                </span>
              </div>
              <Button size="sm" variant="outline" onClick={() => {
                setMix(mix + 1);
                track('goal_mix_shuffled', { mix: ((mix + 1) % MIX_COUNT) + 1 });
              }}>Show another set</Button>
            </div>

            <div className="gp-alloc" aria-label={rows.map((r) => `${r.cat} ${r.pct}%`).join(', ')}>
              {rows.map((r) => (
                <span key={r.fund.id} style={{ width: `${r.pct}%`, background: r.color }} />
              ))}
            </div>

            <ul className="gp-rows">
              {rows.map((r) => (
                <li key={r.fund.id} className="gp-row">
                  <FundMark amc={r.fund.amc} tone={r.color} />
                  <span className="stack gap4 grow">
                    <b className="gp-row__fund">{r.fund.name}</b>
                    <span className="tiny muted">{r.cat} · {amcShort(r.fund.amc)}</span>
                    <span className="gp-stats">
                      <span>Grows about {pct1(r.rates.base)} a year</span>
                      <span>Last 5 years {r.fund.r5}%</span>
                      <span>Yearly fee {r.fund.exp}%</span>
                    </span>
                  </span>
                  <span className="gp-row__pct">{r.pct}%</span>
                  <span className="gp-row__amt">
                    <b className="mono-num">{inr(r.amount)}</b>
                    <span className="tiny faint">a month</span>
                  </span>
                </li>
              ))}
            </ul>
          </section>

          <p className="tiny faint gp-disclaimer">
            These funds are invented for the prototype — the names, the returns and the fees are all
            made up, and none of this is live market data. The growth figures are what-ifs at a weak,
            usual and strong rate, not forecasts. Real mutual funds carry real risk; this screen
            sorts and explains, it does not tell you what to buy.
          </p>
        </div>

        <aside className="gp-check card">
          <span className="gp-status is-ok"><IconCheckCircle size={13} /> On track</span>
          <div className="gp-figure">
            <span className="gp-figure__num">≈ {inrShort(check.projected!)}</span>
            <span className="gp-figure__sub">
              after {years} {yearsWord}, from {inr(check.invested!)} put in
            </span>
          </div>
          <div className="gp-range">
            <span>If it goes badly<b>{inrShort(check.low!)}</b></span>
            <span>If it goes well<b>{inrShort(check.high!)}</b></span>
          </div>
          <ProjectionChart monthly={monthly} months={check.months!} rates={check.rates!} goal={goal} />
          <ChartKey />
          <dl className="gp-sum">
            <div><dt>Goal</dt><dd>{inrShort(goal)}{was('goal')}</dd></div>
            <div><dt>Every month</dt><dd>{inr(monthly)}{was('monthly')}</dd></div>
            <div><dt>For</dt><dd>{years} {yearsWord}{was('years')}</dd></div>
            <div><dt>Ride</dt><dd>{plan.label}{was('risk')}</dd></div>
            <div><dt>Growth assumed</dt><dd>about {pct1(check.rates!.base)} a year</dd></div>
          </dl>
          <div className="gp-check__foot">
            <Button variant="primary" block onClick={() => {
              setOpen(true);
              track('goal_invest_opened', { monthly, funds: rows.length });
            }}>
              {invested ? 'See my monthly plans' : `Start ${inr(monthly)} a month`}
            </Button>
            <Button variant="outline" block onClick={onEdit}>Change my goal</Button>
          </div>
        </aside>
      </div>

      {open ? (
        <InvestDrawer rows={rows} monthly={monthly} done={invested}
          onClose={() => setOpen(false)} onHome={goHome}
          onConfirm={(date) => {
            setInvested({ date });
            track('goal_invest_confirmed', { monthly, funds: rows.length });
          }} />
      ) : null}
    </div>
  );
}

/* --------------------------------------------------------------- hero art */

function HeroArt() {
  return (
    <svg className="gp-art" width="240" height="150" viewBox="0 0 240 150" aria-hidden="true">
      <defs>
        <linearGradient id="gp-bar" x1="0" y1="1" x2="0" y2="0">
          <stop offset="0%" stopColor="var(--green)" stopOpacity="0.25" />
          <stop offset="100%" stopColor="var(--green)" stopOpacity="0.95" />
        </linearGradient>
      </defs>
      {[0, 1, 2, 3, 4].map((i) => (
        <rect key={i} x={28 + i * 34} y={112 - i * 18} width="22" height={18 + i * 18}
          rx="5" fill="url(#gp-bar)" />
      ))}
      <path d="M22 112 C70 100, 120 74, 200 28" fill="none"
        stroke="var(--green)" strokeWidth="2.4" strokeLinecap="round" opacity="0.85" />
      <circle cx="200" cy="28" r="9" fill="var(--bg)" stroke="var(--green)" strokeWidth="2.4" />
      <circle cx="200" cy="28" r="3.4" fill="var(--green)" />
      <line x1="18" y1="130" x2="222" y2="130" stroke="var(--border-2)" strokeWidth="1.4" />
    </svg>
  );
}
