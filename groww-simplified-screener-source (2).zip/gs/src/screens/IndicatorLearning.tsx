import React, { useMemo } from 'react';
import type { IndicatorId } from '../data/config';
import { INDICATORS, formatIndicator } from '../data/indicators';
import { learningFor, LEARNING, goodToKnow, iconForIndicator, indicatorsForOption, learnTitle, primaryIndicatorFor } from '../data/learning';
import { STOCK_BY_ID } from '../data/stocks';
import { UNIVERSE, filteringOptions } from '../engine/screener';
import { getIndicatorValue } from '../engine/rules';
import { useStore } from '../state/store';
import { track } from '../state/analytics';
import { Button } from '../ui/primitives';
import {
  IconArrowRight, IconBars, IconBook, IconBulb, IconChevronLeft, IconClose, IconChevronRight,
  IconCompare, IconCoins, IconInfo, IconPulse, IconScales, IconShield, IconTarget, IconTrendUp, OptionIcon,
} from '../ui/icons';
import { LearnVisual } from '../ui/learnVisuals';

const STEP_ICONS: Record<string, React.ReactNode> = {
  bars: <IconBars size={18} />,
  compare: <IconCompare size={18} />,
  trendUp: <IconTrendUp size={18} />,
  shield: <IconShield size={18} />,
  coins: <IconCoins size={18} />,
  scales: <IconScales size={18} />,
  target: <IconTarget size={18} />,
  pulse: <IconPulse size={18} />,
};

export function IndicatorLearningScreen({ id, origin, stockId }: {
  id: IndicatorId; origin?: 'learning' | 'why' | 'results'; stockId?: string;
}) {
  const { state, dispatch } = useStore();
  const mod = learningFor(id);
  const meta = INDICATORS[id];
  const stock = stockId ? STOCK_BY_ID[stockId] : undefined;

  const options = useMemo(() => filteringOptions(state.selections), [state.selections]);
  /** one headline indicator per preference — the same set screen 1 shows */
  const screenIndicators = useMemo(() => {
    const out: IndicatorId[] = [];
    for (const o of options) {
      const primary = primaryIndicatorFor(o);
      if (primary && !out.includes(primary)) out.push(primary);
    }
    return out;
  }, [options]);
  const list = screenIndicators.includes(id) ? screenIndicators : [id, ...screenIndicators];
  const index = list.indexOf(id);

  /** the preference that brought this indicator in */
  const usedFor = options.find((o) => indicatorsForOption(o).includes(id));
  const rule = usedFor?.rules.find((r) => r.indicator === id || r.substitute?.indicator === id);

  const value = stock ? getIndicatorValue(stock, id) : null;
  const peer = stock && id === 'pe' ? UNIVERSE.median('pe', stock.sector)
    : stock && id === 'pb' ? UNIVERSE.median('pb', stock.sector) : null;

  const related = useMemo(() => {
    const fromScreen = screenIndicators.filter((x) => x !== id);
    const suggested = (mod?.related ?? []).filter((x) => x !== id);
    const merged = [...fromScreen, ...suggested.filter((x) => !fromScreen.includes(x))];
    return merged.slice(0, 2);
  }, [screenIndicators, id, mod]);

  React.useEffect(() => { track('indicator_lesson_opened', { indicator: id, from: origin ?? 'direct' }); }, [id]);

  const goBack = () => {
    if (origin === 'why' && stockId) dispatch({ type: 'go', route: { name: 'whyMatched', stockId } });
    else if (origin === 'learning') dispatch({ type: 'go', route: { name: 'learning' } });
    else if (origin === 'results') dispatch({ type: 'go', route: { name: 'results' } });
    else dispatch({ type: 'back' });
  };
  const backLabel = origin === 'why' && stock ? `Back to ${stock.name}`
    : origin === 'learning' ? 'Back to the numbers'
      : origin === 'results' ? 'Back to results' : 'Back to screener';

  const openIndicator = (next: IndicatorId) =>
    dispatch({ type: 'go', route: { name: 'indicator', id: next, origin, stockId } });

  const step = (n: number, title: string) => (
    <div className="sec-card__head">
      <span className="step-dot">{n}</span>
      <h2>{title}</h2>
    </div>
  );

  return (
    <div className="il-page">
      <div className="il-bar">
        <div className="shell shell--wide il-bar__row">
          <button className="il-bar__back" onClick={goBack}>
            <IconChevronLeft size={16} /> {backLabel}
          </button>
          <button className="close-btn" aria-label="Close"
            onClick={() => dispatch({ type: 'go', route: { name: state.lastRun ? 'results' : 'screener' } })}>
            <IconClose />
          </button>
        </div>
      </div>

      <div className="shell shell--wide">
        <div className="il-wrap">
          <div className="il-main">
            <h1>What this number means</h1>

            <section className="ind-summary">
              <span className="ind-summary__icon">
                <OptionIcon name={iconForIndicator(id)} size={26} />
              </span>
              <div className="grow">
                <h2>{learnTitle(id)}</h2>
                {usedFor ? (
                  <span className={`used-for cat-${usedFor.categoryId}`}>
                    Used for: <b>{usedFor.chip}</b>
                  </span>
                ) : (
                  <span className="used-for">Not part of your current screen — reading ahead</span>
                )}
              </div>
              <p className="ind-summary__note">{mod?.means ?? meta.what}</p>
            </section>

            <section className="sec-card">
              {step(1, 'What it means')}
              <p className="sec-card__lead">{mod?.means ?? meta.what}</p>
              <div className="means-row">
                <div className="means-visual">
                  <LearnVisual
                    kind={mod?.visual ?? 'levelBar'}
                    value={value}
                    peer={peer}
                    unit={id === 'pe' || id === 'pb' ? 'x' : id === 'roe' || id === 'roce' || id === 'capitalAdequacy' ? '%' : ''}
                    returns={stock ? { oneYear: stock.return1Y, threeYear: stock.return3Y, worst: stock.maxDrawdown1Y } : undefined}
                  />
                </div>
                <div className="insight">
                  <span className="insight__icon"><IconBulb size={16} /></span>
                  <p>{mod?.insight}</p>
                </div>
              </div>
              {stock && value !== null ? (
                <p className="tiny faint" style={{ marginTop: 10 }}>
                  On {stock.name}, this reads {formatIndicator(id, value)}
                  {peer ? ` against a peer median of ${peer.toFixed(1)}x` : ''}. Demo data.
                </p>
              ) : null}
            </section>

            <section className="sec-card">
              {step(2, 'Why we used it')}
              {usedFor ? (
                <div className="why-panel">
                  <span className="why-panel__icon"><IconTarget size={18} /></span>
                  <p>
                    You selected <span className={`used-for cat-${usedFor.categoryId}`}><b>{usedFor.chip}</b></span>,
                    so Groww checked {INDICATORS[id].name.toLowerCase()}
                    {rule ? <> — it needs {rule.requirement}</> : null}.
                    {rule ? <span className="why-panel__basis">{rule.basis}. {rule.why}</span> : null}
                  </p>
                </div>
              ) : (
                <div className="why-panel">
                  <span className="why-panel__icon"><IconInfo size={18} /></span>
                  <p>
                    Nothing in your screen uses this one right now. It is here so you can read ahead — add a
                    preference that relies on it and it will start filtering.
                  </p>
                </div>
              )}
            </section>

            <section className="sec-card">
              {step(3, 'How it works')}
              <div className="steps-row">
                {(mod?.steps ?? []).map((st, i) => (
                  <React.Fragment key={st.title}>
                    {i > 0 ? <span className="steps-row__arrow" aria-hidden="true"><IconArrowRight size={16} /></span> : null}
                    <div className="step-card">
                      <span className="step-card__top">
                        <span className="step-card__n">{i + 1}</span>
                        <span className="step-card__icon">{STEP_ICONS[st.icon]}</span>
                      </span>
                      <b>{st.title}</b>
                      <p>{st.desc}</p>
                    </div>
                  </React.Fragment>
                ))}
              </div>
            </section>

            <div className="good-to-know">
              <span className="good-to-know__icon"><IconInfo size={15} /></span>
              <b>Good to know</b>
              <span className="vdivider" />
              <p>{goodToKnow(id)}</p>
            </div>
          </div>

          <aside className="il-rail">
            <h2 className="il-rail__title">Your learning progress</h2>
            <div className="il-prog">
              <div className="il-prog__top">
                <b>{Math.round(((index + 1) / list.length) * 100)}%</b>
                <span className="small muted">{index + 1} of {list.length}</span>
              </div>
              <div className="progress-bar" role="progressbar" aria-valuenow={index + 1} aria-valuemin={1} aria-valuemax={list.length}
                aria-label={`Indicator ${index + 1} of ${list.length}`}>
                <span style={{ width: `${((index + 1) / list.length) * 100}%` }} />
              </div>
            </div>

            <div className="learn-nav">
              <Button variant="outline" onClick={() => (index > 0 ? openIndicator(list[index - 1]) : goBack())}>
                <IconChevronLeft size={15} /> Back
              </Button>
              <Button variant="primary" className="grow" disabled={list.length < 2}
                onClick={() => openIndicator(list[(index + 1) % list.length])}>
                Next number <IconArrowRight size={15} />
              </Button>
            </div>

            {related.length ? (
              <div className="stack gap12">
                <h2 style={{ fontSize: 17 }}>Close to this one</h2>
                {related.map((r) => (
                  <button className="related-card" key={r} onClick={() => openIndicator(r)}>
                    <span className="related-card__icon"><OptionIcon name={iconForIndicator(r)} size={17} /></span>
                    <span className="stack gap4 grow">
                      <b>{learnTitle(r)}</b>
                      <span className="small muted">{learningFor(r).checks}</span>
                    </span>
                    <IconChevronRight />
                  </button>
                ))}
              </div>
            ) : null}

            <button className="related-card related-card--keep" onClick={() => dispatch({ type: 'go', route: { name: 'learning' } })}>
              <span className="related-card__icon" style={{ background: 'var(--bg)', color: 'var(--blue)' }}><IconBook size={17} /></span>
              <span className="stack gap4 grow">
                <b>Keep learning</b>
                <span className="small muted">See every number behind your screen.</span>
              </span>
              <IconChevronRight />
            </button>

          </aside>
        </div>
      </div>
    </div>
  );
}
