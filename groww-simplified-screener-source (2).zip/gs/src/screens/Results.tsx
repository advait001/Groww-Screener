import React, { useEffect, useMemo, useState } from 'react';
import type { IndicatorId } from '../data/config';
import { CATEGORIES, OPTION_BY_ID } from '../data/config';
import type { Stock } from '../data/stocks';
import { SNAPSHOT_LABEL, formatPrice, priceSeries } from '../data/stocks';
import {
  SORT_LABELS, UNIVERSE, growthText, momentumText, narrowings, peerValuationText, relaxations,
  runScreener, sortResults, conflicts, filteringOptions, type SortKey, type StockResult,
} from '../engine/screener';
import { plainSummary, screenName, sentenceText, shortLabel } from '../engine/sentence';
import { useStore } from '../state/store';
import { track } from '../state/analytics';
import { Button, Chip, Drawer, SelectMenu, Tag } from '../ui/primitives';
import { IconBook, IconChevronRight, IconClose, IconEdit, IconInfo, IconSave, IconSort } from '../ui/icons';
import { Sparkline } from '../ui/icons';
import { LessonModal, TranslationRows } from '../ui/explain';
import type { RuleOutcome } from '../engine/rules';
import { CompanyLogo } from '../ui/companyLogo';
import { OptionIcon } from '../ui/icons';
import { INDICATORS, formatIndicator } from '../data/indicators';

/** how many matches the list shows before asking to load more */
const PAGE = 50;
const BROAD_THRESHOLD = 12;

export function ResultsScreen({ onToast }: { onToast: (m: string) => void }) {
  const { state, dispatch } = useStore();
  const { selections, sort } = state;
  const run = useMemo(() => runScreener(selections), [selections]);
  const [lesson, setLesson] = useState<IndicatorId | null>(null);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [showClose, setShowClose] = useState(false);
  const conflictNotes = useMemo(() => conflicts(selections), [selections]);

  const rows = useMemo(() => sortResults(run.exact, sort), [run.exact, sort]);
  const [visible, setVisible] = useState(PAGE);
  useEffect(() => { setVisible(PAGE); }, [run.exact, sort]);
  const shown = rows.slice(0, visible);
  const closeRows = useMemo(() => sortResults(run.close, 'relevance').slice(0, 6), [run.close]);
  const relax = useMemo(() => (run.exact.length === 0 ? relaxations(selections) : []), [run.exact.length, selections]);
  const narrow = useMemo(() => (run.exact.length > BROAD_THRESHOLD ? narrowings(selections) : []), [run.exact.length, selections]);

  useEffect(() => {
    track('results_viewed', { matched: run.exact.length, conditions: run.filterCount });
    if (!run.exact.length) track('zero_result_triggered', { conditions: run.filterCount });
    if (run.exact.length > BROAD_THRESHOLD) track('broad_result_triggered', { matched: run.exact.length });
  }, [run.exact.length, run.filterCount]);

  const sample = rows[0]?.stock ?? run.close[0]?.stock;

  if (!run.filterCount) {
    return (
      <div className="page">
        <div className="shell">
          <div className="card state-card">
            <h2>No conditions to run yet</h2>
            <p className="muted">You have cleared every filter, so there is nothing to screen for. Pick a couple of preferences and run it again.</p>
            <Button variant="primary" style={{ marginTop: 12 }} onClick={() => dispatch({ type: 'go', route: { name: 'screener' } })}>
              Back to the screener
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const setSort = (key: SortKey) => { dispatch({ type: 'sort', key }); track('results_sorted', { key }); };
  /** the full explanation now has its own screen */
  const openWhy = (stockId: string) => {
    track('stock_match_explanation_opened', { id: stockId, from: 'results' });
    dispatch({ type: 'go', route: { name: 'whyMatched', stockId } });
  };

  const activeFilters = filteringOptions(selections);

  const header = (
    <div className="res-head">
      <h1>{run.exact.length ? 'Stocks matching your filters' : 'No stocks match all your filters'}</h1>
      <p className="res-head__sub">{plainSummary(selections)}</p>

      <div className="res-bar">
        <div className="res-bar__chips">
          {activeFilters.map((o) => (
            <span className={`pchip cat-${o.categoryId}`} key={o.id}>
              <span className="pchip__icon"><OptionIcon name={o.icon} size={15} /></span>
              <span className="pchip__body">
                <span className="pchip__cat">{CATEGORIES.find((c) => c.id === o.categoryId)?.label}</span>
                <span className="pchip__label">{o.chip}</span>
              </span>
            </span>
          ))}
          <button className="link-btn small res-bar__edit"
            onClick={() => { track('screener_edited', { from: 'results' }); dispatch({ type: 'go', route: { name: 'screener' } }); }}>
            <IconEdit size={13} /> Edit filters
          </button>
        </div>

        <div className="res-bar__actions">
          <SelectMenu
            value={sort}
            label="Sort by"
            icon={<IconSort size={14} />}
            options={(Object.keys(SORT_LABELS) as SortKey[]).map((k) => ({ value: k, label: SORT_LABELS[k] }))}
            onChange={setSort}
          />
          <button className="res-bar__btn" onClick={() => { setFiltersOpen(true); track('translation_opened', { from: 'results' }); }}>
            <IconBook size={15} /> What we checked
          </button>
          <button className="res-bar__btn"
            onClick={() => {
              const name = screenName(selections);
              dispatch({ type: 'saveScreen', name });
              track('screener_saved', { name });
              onToast('Screen saved. You will find it on the screener page.');
            }}>
            <IconSave size={15} /> Save screener
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="page">
      <div className="shell">
        {header}

        {conflictNotes.map((c, i) => (
          <div className="notice" key={i} style={{ marginBottom: 12 }}>
            <IconInfo />
            <div>
              <div>{c.message}</div>
              <div className="notice__actions">
                <Button size="xs" variant="outline" onClick={() => dispatch({ type: 'go', route: { name: 'screener' } })}>Keep both, edit later</Button>
                <Button size="xs" variant="ghost" onClick={() => {
                  dispatch({ type: 'clearCategory', category: c.changeCategoryId });
                  track('relaxation_applied', { category: c.changeCategoryId, from: 'conflict' });
                }}>
                  Drop “{c.optionLabels[1]}”
                </Button>
              </div>
            </div>
          </div>
        ))}

        {!run.exact.length ? (
          <div className="card state-card">
            <h2>Nothing clears every condition</h2>
            <p className="muted">
              You have built a fairly specific combination. Nothing is changed unless you choose one of these.
            </p>
            <div className="suggestions">
              {relax.map((r) => (
                <button className="suggestion" key={r.categoryId}
                  onClick={() => {
                    dispatch({ type: 'clearCategory', category: r.categoryId });
                    track('relaxation_applied', { category: r.categoryId, resulting: r.resultingCount });
                  }}>
                  <span className="stack gap4">
                    <span style={{ color: 'var(--heading)' }}>Remove {r.categoryLabel.toLowerCase()}: “{r.optionLabel}”</span>
                    <span className="small muted">
                      {r.gain > 0
                        ? `This condition is the one holding the list back — dropping it leaves ${r.resultingCount} matches.`
                        : 'Dropping this alone does not open anything up, so something else is the binding condition.'}
                    </span>
                  </span>
                  <span className="suggestion__effect">{r.resultingCount} would match <IconChevronRight /></span>
                </button>
              ))}
            </div>
            <div className="row gap8" style={{ marginTop: 14 }}>
              <Button variant="outline" size="sm" onClick={() => dispatch({ type: 'go', route: { name: 'screener' } })}>Edit filters myself</Button>
              <Button variant="ghost" size="sm" onClick={() => setShowClose((s) => !s)}>
                {showClose ? 'Hide close matches' : `Show ${run.close.length} close matches`}
              </Button>
            </div>
          </div>
        ) : null}

        {narrow.length ? (
          <div className="notice notice--info" style={{ marginBottom: 14 }}>
            <IconInfo />
            <div>
              <div>This is a wide net. Want to be fussier?</div>
              <div className="notice__actions">
                {narrow.map((n) => (
                  <Button key={n.optionId} size="xs" variant="outline"
                    onClick={() => {
                      dispatch({ type: 'select', category: n.categoryId, optionId: n.optionId });
                      track('narrowing_applied', { option: n.optionId, resulting: n.resultingCount });
                    }}>
                    Add {n.categoryLabel.toLowerCase()}: {n.optionLabel} → {n.resultingCount}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        ) : null}

        {rows.length ? (
          <section className="results-panel" aria-label="Matching stocks">
            <div className="results-panel__head">
              <span className="res-count">
                {rows.length.toLocaleString('en-IN')} {rows.length === 1 ? 'stock' : 'stocks'}
                <span className="muted small"> of {run.universeSize.toLocaleString('en-IN')} checked</span>
              </span>
            </div>

            <div className="table-wrap">
              <table className="gw-table">
                <thead>
                  <tr>
                    <th scope="col">Company</th>
                    <th scope="col">
                      <button className={sort === 'return1Y' ? 'is-active' : ''} onClick={() => setSort('return1Y')}>Price · 1Y <IconSort /></button>
                    </th>
                    <th scope="col">
                      <button className={sort === 'valuation' ? 'is-active' : ''} onClick={() => setSort('valuation')}>Price tag <IconSort /></button>
                    </th>
                    <th scope="col">
                      <button className={sort === 'growth' ? 'is-active' : ''} onClick={() => setSort('growth')}>Growth <IconSort /></button>
                    </th>
                    <th scope="col">Lately</th>
                    <th scope="col">
                      <button className={sort === 'relevance' ? 'is-active' : ''} onClick={() => setSort('relevance')}>Match <IconSort /></button>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {shown.map((r) => (
                    <ResultRow key={r.stock.id} result={r} onWhy={() => openWhy(r.stock.id)}
                      onOpen={() => { track('stock_detail_opened', { id: r.stock.id, from: 'results' }); dispatch({ type: 'go', route: { name: 'stock', id: r.stock.id } }); }} />
                  ))}
                </tbody>
              </table>
            </div>

            <div className="cards-list cards-list--mobile">
              {shown.map((r) => (
                <ResultCard key={r.stock.id} result={r} onWhy={() => openWhy(r.stock.id)}
                  onOpen={() => dispatch({ type: 'go', route: { name: 'stock', id: r.stock.id } })} />
              ))}
            </div>

            {rows.length > shown.length ? (
              <div className="more-row">
                <span className="small muted">Showing {shown.length} of {rows.length} matches</span>
                <Button size="sm" variant="outline"
                  onClick={() => { setVisible((v) => v + PAGE); track('results_page_more', { shown: shown.length + PAGE }); }}>
                  Show {Math.min(PAGE, rows.length - shown.length)} more
                </Button>
              </div>
            ) : null}
          </section>
        ) : null}

        {(showClose || (rows.length > 0 && closeRows.length > 0)) && closeRows.length ? (
          <>
            <div className="section-label">
              <h2>Close matches</h2>
              <span className="small muted">Missed exactly one condition. Kept separate, never mixed into the matches above.</span>
            </div>
            <div className="close-grid">
              {closeRows.map((r) => {
                const missed = r.missed;
                const failed = missed?.outcomes.find((o) => o.status !== 'pass');
                const gap = failed ? shortfall(r.stock, failed) : null;
                return (
                  <article className="close-card" key={r.stock.id}>
                    <div className="close-card__top">
                      <CompanyLogo stock={r.stock} size={32} />
                      <div className="stack gap4 grow" style={{ minWidth: 0 }}>
                        <button className="stock-name close-card__name"
                          onClick={() => dispatch({ type: 'go', route: { name: 'stock', id: r.stock.id } })}>
                          {r.stock.name}
                        </button>
                        <span className="small muted">{r.stock.sector}</span>
                      </div>
                      <span className="close-card__score" aria-label={`${r.matchedCount} of ${r.filterCount} conditions met`}>
                        {Array.from({ length: r.filterCount }).map((_, i) => (
                          <i key={i} className={i < r.matchedCount ? 'is-met' : ''} />
                        ))}
                      </span>
                    </div>

                    {missed ? (
                      <div className="gap-block">
                        <span className="gap-block__head">
                          <span className="label-caps">Short on</span>
                          <span className={`gap-block__name cat-${missed.categoryId}`}>{missed.option.chip}</span>
                        </span>
                        {gap ? (
                          <>
                            <span className="gap-meter" role="img"
                              aria-label={`${gap.valueText} against ${gap.targetText}`}>
                              <span className="gap-meter__fill" style={{ width: `${Math.round(gap.pct * 100)}%` }} />
                            </span>
                            <span className="gap-meter__legend">
                              <span className="mono-num">{gap.valueText}</span>
                              <span>{gap.targetText}</span>
                            </span>
                          </>
                        ) : (
                          <span className="tiny muted">
                            {failed
                              ? `${INDICATORS[failed.applied.indicator].name} ${failed.valueText} · needs ${failed.applied.requirement}`
                              : 'One check in that preference did not pass.'}
                          </span>
                        )}
                      </div>
                    ) : null}

                    <Button size="xs" variant="outline" block onClick={() => openWhy(r.stock.id)}>
                      Why it nearly matched
                    </Button>
                  </article>
                );
              })}
            </div>
          </>
        ) : null}

        <div className="card card__pad" style={{ marginTop: 26 }}>
          <div className="row gap16 wrap">
            <div className="stack gap4 grow">
              <h3>How we picked these</h3>
              <p className="small muted">
                Every company above passed the filters you chose, and nothing else was used. Open "What we checked" to read the exact rules.
              </p>
            </div>
            <Button variant="outline" size="sm"
              onClick={() => { track('indicators_used_opened', { from: 'results_footer' }); dispatch({ type: 'go', route: { name: 'learning' } }); }}>
              What the numbers mean
            </Button>
          </div>
          <div className="divider" style={{ margin: '14px 0' }} />
          <p className="tiny faint">
            Demo data · snapshot {SNAPSHOT_LABEL} · the list is worked out again in your browser every time you change a filter.
            This screen sorts and explains. It does not tell you what to buy.
          </p>
        </div>
      </div>

      {filtersOpen ? (
        <Drawer title="What we checked" subtitle="Tap any check to see what it means"
          onClose={() => setFiltersOpen(false)}
          footer={<Button variant="primary" className="grow" onClick={() => setFiltersOpen(false)}>Back to results</Button>}>
          <TranslationRows selections={selections} onIndicator={(id) => setLesson(id)} />
        </Drawer>
      ) : null}

      {lesson ? <LessonModal indicatorId={lesson} stock={sample} selections={selections} onClose={() => setLesson(null)} /> : null}
    </div>
  );
}


/**
 * How near a company came to the one check it failed, as a fraction of what the
 * rule asked for, with both ends written out. Returns null where "how close"
 * has no honest meaning — a yes/no check, or a figure that was not reported.
 */
function shortfall(stock: Stock, outcome: RuleOutcome): { pct: number; valueText: string; targetText: string } | null {
  const { applied, value, valueText } = outcome;
  if (value === null || value === undefined) return null;
  const id = applied.indicator;
  const fmt = (v: number) => formatIndicator(id, v);
  const clamp = (n: number) => Math.max(0.04, Math.min(0.97, n));

  const against = (target: number, dir: 'gte' | 'lte') => {
    if (!Number.isFinite(target) || target === 0) return null;
    const pct = dir === 'gte' ? value / target : target / value;
    if (!Number.isFinite(pct) || pct <= 0) return null;
    const targetText = `needs ${dir === 'gte' ? '≥' : '≤'} ${fmt(target).replace(/^\+/, '')}`;
    return { pct: clamp(pct), valueText, targetText };
  };

  switch (applied.comparison) {
    case 'gte': return against(applied.value as number, 'gte');
    case 'lte': return against(applied.value as number, 'lte');
    case 'between':
      return value < (applied.value as number)
        ? against(applied.value as number, 'gte')
        : against(applied.value2 as number, 'lte');
    case 'median_ratio_lte': {
      const med = UNIVERSE.median(id, stock.sector);
      return med ? against(med * (applied.value as number), 'lte') : null;
    }
    case 'median_ratio_gte': {
      const med = UNIVERSE.median(id, stock.sector);
      return med ? against(med * (applied.value as number), 'gte') : null;
    }
    case 'percentile_gte':
    case 'percentile_lte': {
      const scope = applied.scope ?? 'sector';
      const rank = UNIVERSE.rank(id, value, scope, stock.sector);
      if (rank === null) return null;
      const target = applied.value as number;
      const top = applied.comparison === 'percentile_gte';
      const pct = top ? rank / target : (100 - rank) / (100 - target);
      if (!Number.isFinite(pct) || pct <= 0) return null;
      return {
        pct: clamp(pct),
        valueText: `ranks ${rank} of 100`,
        targetText: `needs ${top ? `top ${100 - target}%` : `lowest ${target}%`}`,
      };
    }
    default: return null;
  }
}

/* ------------------------------------------------------------------ rows */

function ResultRow({ result, onWhy, onOpen }: { result: StockResult; onWhy: () => void; onOpen: () => void }) {
  const s = result.stock;
  const series = useMemo(() => priceSeries(s, 40), [s.id]);
  return (
    <tr>
      <td>
        <div className="stock-cell">
          <CompanyLogo stock={s} size={36} />
          <div className="stack gap4">
            <span className="stock-name"><button onClick={onOpen}>{s.name}</button></span>
            <span className="small muted">{s.sector}</span>
          </div>
        </div>
      </td>
      <td>
        <div className="row gap12" style={{ justifyContent: 'flex-end' }}>
          <Sparkline series={series} up={s.return1Y >= 0} />
          <div className="stack gap4" style={{ alignItems: 'flex-end' }}>
            <span className="mono-num" style={{ color: 'var(--heading)' }}>{formatPrice(s.price)}</span>
            <span className={`small mono-num ${s.return1Y >= 0 ? 'pos' : 'neg'}`}>
              {s.return1Y >= 0 ? '+' : ''}{s.return1Y.toFixed(1)}% 1Y
            </span>
          </div>
        </div>
      </td>
      <td className="mono-num">{peerValuationText(s)}</td>
      <td className="mono-num">{growthText(s)}</td>
      <td>{momentumText(s)}</td>
      <td>
        <div className="stack gap4" style={{ alignItems: 'flex-end' }}>
          <span className={`match${result.exact ? '' : ' match--partial'}`}>{result.matchedCount}/{result.filterCount} matched</span>
          <button className="why-btn" onClick={onWhy}>Why it matched</button>
        </div>
      </td>
    </tr>
  );
}

function ResultCard({ result, onWhy, onOpen }: { result: StockResult; onWhy: () => void; onOpen: () => void }) {
  const s = result.stock;
  return (
    <div className="card stock-card">
      <div className="stock-card__top">
        <CompanyLogo stock={s} size={36} />
        <div className="stack gap4 grow">
          <button className="stock-name" style={{ background: 'none', border: 0, padding: 0, textAlign: 'left', cursor: 'pointer' }} onClick={onOpen}>{s.name}</button>
          <span className="small muted">{s.sector}</span>
        </div>
        <div className="stack gap4" style={{ alignItems: 'flex-end' }}>
          <span className="mono-num" style={{ color: 'var(--heading)' }}>{formatPrice(s.price)}</span>
          <span className={`small mono-num ${s.changePct1D >= 0 ? 'pos' : 'neg'}`}>
            {s.change1D >= 0 ? '+' : ''}{s.change1D.toFixed(2)} ({s.changePct1D.toFixed(2)}%)
          </span>
        </div>
      </div>
      <div className="stock-card__metrics">
        <div className="metric"><span className="metric__label">Last year</span><span className={`metric__value mono-num ${s.return1Y >= 0 ? 'pos' : 'neg'}`}>{s.return1Y >= 0 ? '+' : ''}{s.return1Y.toFixed(1)}%</span></div>
        <div className="metric"><span className="metric__label">Price tag</span><span className="metric__value mono-num">{peerValuationText(s)}</span></div>
        <div className="metric"><span className="metric__label">Growth</span><span className="metric__value mono-num">{growthText(s)}</span></div>
        <div className="metric"><span className="metric__label">Lately</span><span className="metric__value">{momentumText(s)}</span></div>
      </div>
      <div className="row gap12" style={{ justifyContent: 'space-between' }}>
        <span className={`match${result.exact ? '' : ' match--partial'}`}>{result.matchedCount}/{result.filterCount} matched</span>
        <Button size="xs" variant="outline" onClick={onWhy}>Why it matched</Button>
      </div>
    </div>
  );
}
