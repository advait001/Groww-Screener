import React, { useMemo, useState } from 'react';
import type { IndicatorId, Option } from '../data/config';
import { INDICATORS } from '../data/indicators';
import { learningFor, LEARNING, iconForIndicator, indicatorsForOption, learnTitle, primaryIndicatorFor } from '../data/learning';
import { filteringOptions } from '../engine/screener';
import { useStore } from '../state/store';
import { track } from '../state/analytics';
import { Button } from '../ui/primitives';
import {
  GuideArt, IconArrowRight, IconBook, IconBulb, IconChart, IconCheckCircle,
  IconChevronLeft, IconClose, OptionIcon,
} from '../ui/icons';
import { LearningStages, StageStrip } from '../ui/sidebars';

/** The rule that first brought this indicator in, so "why" comes from the real config. */
function reasonFor(option: Option, indicator: IndicatorId): string {
  const rule = option.rules.find((r) => r.indicator === indicator || r.substitute?.indicator === indicator);
  return rule?.why ?? learningFor(indicator).means ?? '';
}

export function LearningScreen() {
  const { state, dispatch } = useStore();
  const options = useMemo(() => filteringOptions(state.selections), [state.selections]);
  const [expanded, setExpanded] = useState<string | null>(null);

  React.useEffect(() => {
    track('indicators_used_opened', { from: 'learning_overview', conditions: options.length });
  }, []);

  const openIndicator = (id: IndicatorId) => {
    track('indicator_lesson_opened', { indicator: id, from: 'learning_overview' });
    dispatch({ type: 'go', route: { name: 'indicator', id, origin: 'learning' } });
  };

  const backToResults = () => dispatch({ type: 'go', route: { name: state.lastRun ? 'results' : 'screener' } });

  return (
    <div className="sc-page">
      <div className="shell shell--wide">
        <div className="sc-wrap">
          <aside className="side-left"><LearningStages active={1} /></aside>

          <div className="sc-main">
            <StageStrip steps={['What we checked', 'Why it matters', 'How it works']} active={1} />
            <div>
              <h1>What your filters really check</h1>
              <p className="muted" style={{ marginTop: 4 }}>
                Everything you picked turns into a real number we can measure. Here is which one.
              </p>
            </div>

            {!options.length ? (
              <div className="sc-card">
                <h2>Nothing to explain yet</h2>
                <p className="small muted" style={{ marginTop: 6 }}>
                  Pick a couple of filters and this page will show you the real numbers behind them.
                </p>
                <Button variant="primary" style={{ marginTop: 14 }} onClick={() => dispatch({ type: 'go', route: { name: 'screener' } })}>
                  Back to the screener
                </Button>
              </div>
            ) : (
              <>
                <section className="sc-card">
                  <div className="stack gap4" style={{ marginBottom: 14 }}>
                    <h2>What you asked for</h2>
                    <p className="small muted">All of these have to be true before a company shows up on your list.</p>
                  </div>
                  <div className="learn-chips">
                    {options.map((o) => (
                      <div className={`learn-chip cat-${o.categoryId}`} key={o.id}>
                        <OptionIcon name={o.icon} size={17} />
                        <span className="learn-chip__label">{o.chip}</span>
                        <button className="stmt-chip__x" aria-label={`Remove ${o.chip}`}
                          onClick={() => {
                            dispatch({ type: 'clearCategory', category: o.categoryId });
                            track('screener_option_removed', { option: o.id, from: 'learning_overview' });
                          }}>
                          <IconClose size={13} />
                        </button>
                      </div>
                    ))}
                  </div>
                </section>

                <div>
                  <div className="learn-heading">
                    <h2>The number behind each one</h2>
                    <p className="small muted">Every filter is measured by a real number. Tap one to learn what it means.</p>
                  </div>

                  <div className="map-list">
                    {options.map((o) => {
                      const primary = primaryIndicatorFor(o);
                      const extras = indicatorsForOption(o).slice(1);
                      const mod = learningFor(primary);
                      return (
                        <article className={`map-row cat-${o.categoryId}`} key={o.id}>
                          <div className="map-row__main">
                            <span className="map-row__chip">
                              <OptionIcon name={o.icon} size={16} />
                              {o.chip}
                            </span>
                            <span className="map-row__arrow" aria-hidden="true"><IconArrowRight size={16} /></span>
                            <span className="sr-only">is checked using</span>
                            <span className="map-row__ind">
                              <span className="map-row__ind-icon"><OptionIcon name={iconForIndicator(primary)} size={17} /></span>
                              <span className="stack gap4">
                                <b>{learnTitle(primary)}</b>
                                <span className="small muted">{mod?.checks ?? INDICATORS[primary].what}</span>
                              </span>
                            </span>
                          </div>

                          <button className="link-btn small map-row__cta" onClick={() => openIndicator(primary)}>
                            Learn how it works <IconArrowRight size={13} />
                          </button>

                          <p className="map-row__why">
                            <span className="map-row__why-label"><IconCheckCircle size={14} /> Why this matters</span>
                            {reasonFor(o, primary)}
                          </p>

                          {extras.length ? (
                            <p className="map-row__extras">
                              <span className="tiny faint">Also looks at</span>
                              {extras.map((id) => (
                                <button key={id} className="pill-link" onClick={() => openIndicator(id)}>
                                  {learnTitle(id)}
                                </button>
                              ))}
                            </p>
                          ) : null}
                        </article>
                      );
                    })}
                  </div>
                </div>

                <div className="learn-bottom">
                  <Button variant="outline" onClick={backToResults}>
                    <IconChevronLeft size={15} /> Back to results
                  </Button>
                  <div className="row gap16">
                    <Button variant="primary" onClick={() => openIndicator(primaryIndicatorFor(options[0]))}>
                      Continue <IconArrowRight />
                    </Button>
                    <span className="learn-note">
                      <b>Same screen, better understood</b>
                      <span>Go at your own speed</span>
                    </span>
                  </div>
                </div>
              </>
            )}
          </div>

          <aside className="side-right">
            <div className="sc-card">
              <h2 style={{ fontSize: 18 }}>What you’ll learn</h2>
              <p className="small muted" style={{ marginTop: 4, marginBottom: 14 }}>Three things this page shows you.</p>
              <div className="stack gap16">
                <LearnPoint icon={<IconBook />} tone="blue" title="What each number means" body="Said in plain words." />
                <LearnPoint icon={<IconBulb />} tone="purple" title="Why we checked it" body="The reason behind each one." />
                <LearnPoint icon={<IconChart />} tone="green" title="How it changes your list" body="See what happens when you use it." />
              </div>
            </div>

            <div className="tip-card">
              <div className="tip-card__body">
                <span className="tip-card__head"><IconBulb size={16} /> Beginner tip</span>
                <p>
                  A good screen looks at a few things, not just one. That gives you a fairer picture of a company.
                </p>
              </div>
              <span className="tip-card__art"><GuideArt /></span>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}

function LearnPoint({ icon, tone, title, body }: { icon: React.ReactNode; tone: 'green' | 'blue' | 'purple' | 'teal'; title: string; body: string }) {
  return (
    <div className="learn-row">
      <span className={`learn-row__icon tone-${tone}`}>{icon}</span>
      <div>
        <b>{title}</b>
        <p>{body}</p>
      </div>
    </div>
  );
}
