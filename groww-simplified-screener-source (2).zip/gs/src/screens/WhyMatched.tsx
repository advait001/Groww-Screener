import React, { useMemo, useState } from 'react';
import type { IndicatorId } from '../data/config';
import { CATEGORIES } from '../data/config';
import { INDICATORS } from '../data/indicators';
import { learningFor, LEARNING, iconForIndicator, learnTitle, primaryIndicatorFor } from '../data/learning';
import { STOCK_BY_ID, formatPrice } from '../data/stocks';
import { evaluateStock, filteringOptions } from '../engine/screener';
import type { ConditionResult, RuleOutcome } from '../engine/rules';
import { useStore } from '../state/store';
import { track } from '../state/analytics';
import { Button, Tag } from '../ui/primitives';
import {
  IconArrowRight, IconCheckCircle, IconChevronLeft, IconChevronRight, IconClose,
  IconCrossCircle, IconMinusCircle, OptionIcon,
} from '../ui/icons';
import { CompanyLogo } from '../ui/companyLogo';

/** the rule that decided this condition: the failing one, or the first that passed */
function decisive(c: ConditionResult): RuleOutcome | undefined {
  const applicable = c.outcomes.filter((o) => o.status !== 'not-applicable');
  if (c.matched) return applicable[0];
  return applicable.find((o) => o.status !== 'pass') ?? applicable[0];
}

/**
 * Every sentence here is generated from the evaluation the screener actually
 * ran: the indicator, the stock's value, the threshold and the pass or fail.
 */
function explain(c: ConditionResult): { line: string; detail?: string } {
  const o = decisive(c);
  if (!o) return { line: 'This preference applies no filter, so nothing was checked.' };
  const name = INDICATORS[o.applied.indicator].name;
  const area = c.categoryLabel.toLowerCase();
  // the resolved requirement carries peer medians and percentile cut-offs; keep it
  // as a second line so the headline sentence stays readable
  const detail = o.requirementText !== o.applied.requirement ? o.requirementText : undefined;
  if (o.status === 'no-data') {
    return {
      line: `${name} is not available for this company, and missing data is never treated as a pass, so this ${area} preference could not be met.`,
      detail: o.note,
    };
  }
  if (o.status === 'pass') {
    return { line: `${name} of ${o.valueText} clears ${o.applied.requirement}, so this matches your ${area} preference.`, detail };
  }
  return { line: `${name} of ${o.valueText} falls short of ${o.applied.requirement}, so this does not match your ${area} preference.`, detail };
}

const statusOf = (c: ConditionResult) =>
  c.matched ? 'matched' : c.passCount > 0 ? 'partial' : 'missed';

export function WhyMatchedScreen({ stockId }: { stockId: string }) {
  const { state, dispatch } = useStore();
  const stock = STOCK_BY_ID[stockId];
  const options = useMemo(() => filteringOptions(state.selections), [state.selections]);
  const result = useMemo(() => (stock ? evaluateStock(stock, state.selections) : null), [stockId, state.selections]);
  const [collapsed, setCollapsed] = useState<IndicatorId[]>([]);

  React.useEffect(() => {
    if (stock) track('stock_match_explanation_opened', { id: stock.id, from: 'why_matched_screen' });
  }, [stockId]);

  if (!stock || !result) {
    return (
      <div className="sc-page"><div className="shell shell--wide">
        <p className="muted">That company is not in the demo dataset.</p>
        <Button variant="outline" onClick={() => dispatch({ type: 'go', route: { name: 'results' } })}>Back to results</Button>
      </div></div>
    );
  }

  const indicators: IndicatorId[] = [];
  for (const o of options) {
    const primary = primaryIndicatorFor(o);
    if (primary && !indicators.includes(primary)) indicators.push(primary);
  }

  const openIndicator = (id: IndicatorId) =>
    dispatch({ type: 'go', route: { name: 'indicator', id, origin: 'why', stockId } });

  const sizeTag = stock.marketCap >= 100000 ? 'Large Cap' : stock.marketCap >= 20000 ? 'Mid Cap' : 'Small Cap';
  const allMatched = result.exact && result.filterCount > 0;

  return (
    <div className="wm-page">
      <div className="shell shell--wide">
        <div className="wm-panel">
          <header className="wm-head">
            <h1>How this stock measured up</h1>
            <button className="close-btn" aria-label="Back to results"
              onClick={() => dispatch({ type: 'go', route: { name: 'results' } })}>
              <IconClose />
            </button>
          </header>

          <section className="wm-stock">
            <CompanyLogo stock={stock} size={54} />
            <div className="wm-stock__id">
              <h2>{stock.name}</h2>
              <span className="small muted">{sizeTag} · {stock.sector}</span>
            </div>
            <div className="wm-stock__price">
              <b className="mono-num">{formatPrice(stock.price)}</b>
              <span className={`mono-num small ${stock.changePct1D >= 0 ? 'pos' : 'neg'}`}>
                {stock.change1D >= 0 ? '+' : '−'} ₹{Math.abs(stock.change1D).toFixed(2)} ({stock.changePct1D.toFixed(2)}%)
              </span>
            </div>
            <span className={`wm-badge${allMatched ? '' : ' is-partial'}`}>
              {result.matchedCount}/{result.filterCount} of your filters matched
            </span>
          </section>

          {!options.length ? (
            <p className="muted" style={{ padding: '24px 4px' }}>
              There are no filters in your screen right now, so there is nothing to explain.
            </p>
          ) : null}

          {(['matched', 'partial', 'missed'] as const).map((group) => {
            const rows = result.conditions.filter((c) => statusOf(c) === group);
            if (!rows.length) return null;
            return (
              <div className="wm-group" key={group}>
                <h3 className={`wm-group__head is-${group}`}>
                  {group === 'matched' ? <IconCheckCircle size={19} />
                    : group === 'partial' ? <IconMinusCircle size={19} /> : <IconCrossCircle size={19} />}
                  {group === 'matched' ? 'Matched' : group === 'partial' ? 'Partly matched' : 'Did not match'}
                </h3>

                <div className="wm-rows">
                  {rows.map((c) => {
                    const primary = primaryIndicatorFor(c.option);
                    return (
                      <article className="wm-row" key={c.option.id}>
                        <span className={`wm-row__filter cat-${c.categoryId}`}>
                          <span className="wm-row__icon"><OptionIcon name={c.option.icon} size={18} /></span>
                          <span className="wm-row__filter-body">
                            <span className="wm-row__cat">{CATEGORIES.find((x) => x.id === c.categoryId)?.label}</span>
                            <span className="wm-row__name">{c.option.chip}</span>
                          </span>
                        </span>

                        <p className="wm-row__why">{explain(c).line}</p>

                        <div className="wm-row__ind">
                          <p className="small muted">{learningFor(primary).means}</p>
                          <button className="link-btn small" onClick={() => openIndicator(primary)}>
                            Learn more <IconChevronRight size={13} />
                          </button>
                        </div>
                      </article>
                    );
                  })}
                </div>
              </div>
            );
          })}

          <div className="wm-foot">
            <Button variant="outline" onClick={() => dispatch({ type: 'go', route: { name: 'results' } })}>
              <IconChevronLeft size={15} /> Back to results
            </Button>
            <Button variant="primary" disabled={!indicators.length}
              onClick={() => openIndicator(indicators[0])}>
              Learn an indicator <IconArrowRight size={15} />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}