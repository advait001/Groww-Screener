import type { Rule, Option, IndicatorId, CategoryId } from '../data/config';
import { CATEGORIES, OPTION_BY_ID } from '../data/config';
import type { Stock, UniverseContext } from '../data/stocks';
import { isLender } from '../data/stocks';
import { formatIndicator, INDICATORS } from '../data/indicators';

export type RuleStatus = 'pass' | 'fail' | 'no-data' | 'not-applicable';

export interface RuleOutcome {
  /** the rule as configured */
  rule: Rule;
  /** the rule actually run, after any sector substitution */
  applied: Rule;
  status: RuleStatus;
  value: number | null;
  valueText: string;
  /** requirement with any peer or list-relative numbers filled in */
  requirementText: string;
  note?: string;
}

export function getIndicatorValue(stock: Stock, id: IndicatorId): number | null {
  const v = (stock as unknown as Record<string, unknown>)[id];
  if (typeof v === 'boolean') return v ? 1 : 0;
  return typeof v === 'number' && Number.isFinite(v) ? v : null;
}

export function evaluateRule(stock: Stock, rule: Rule, ctx: UniverseContext): RuleOutcome {
  let applied = rule;
  let note: string | undefined;

  if (isLender(stock) && rule.lenderPolicy) {
    if (rule.lenderPolicy === 'skip') {
      return {
        rule, applied: rule, status: 'not-applicable', value: null, valueText: 'Not applicable',
        requirementText: rule.requirement,
        note: 'Banks and lenders are structured differently, so this check was not used here.',
      };
    }
    applied = rule.substitute ?? rule;
    note = 'Banks and lenders borrow as part of the business, so Groww checked their capital buffer instead of debt.';
  }

  const value = getIndicatorValue(stock, applied.indicator);
  const valueText = formatIndicator(applied.indicator, value);

  // Not enough listed history for the window this rule needs.
  if (applied.requiresHistoryYears && stock.listedYears < applied.requiresHistoryYears) {
    return {
      rule, applied, status: 'no-data', value, valueText: 'No data',
      requirementText: applied.requirement,
      note: `Listed ${stock.listedYears} years ago, so there is no ${applied.requiresHistoryYears}-year history to check. Missing data is never treated as a pass.`,
    };
  }

  if (value === null) {
    const extra = applied.indicator === 'pe'
      ? 'P/E cannot be calculated for a company that is not making a profit.'
      : 'This figure is not available for this company. Missing data is never treated as a pass.';
    return { rule, applied, status: 'no-data', value: null, valueText: 'No data', requirementText: applied.requirement, note: note ? `${note} ${extra}` : extra };
  }

  let pass = false;
  let requirementText = applied.requirement;
  const scope = applied.scope ?? 'sector';

  switch (applied.comparison) {
    case 'gte':
      pass = value >= (applied.value as number);
      break;
    case 'lte':
      pass = value <= (applied.value as number);
      break;
    case 'between':
      pass = value >= (applied.value as number) && value <= (applied.value2 as number);
      break;
    case 'is_true':
      pass = value === 1;
      break;
    case 'is_false':
      pass = value === 0;
      break;
    case 'percentile_gte': {
      // top slice of the peer group, e.g. 70 means the best 30%
      const r = ctx.rank(applied.indicator, value, scope, stock.sector);
      if (r === null) return { rule, applied, status: 'no-data', value, valueText, requirementText, note: 'Not enough peers to rank this company.' };
      pass = r >= (applied.value as number);
      requirementText = `${applied.requirement} — this one ranks ${r} out of 100 against ${scope === 'sector' ? stock.sector : 'the whole list'}`;
      break;
    }
    case 'percentile_lte': {
      const r = ctx.rank(applied.indicator, value, scope, stock.sector);
      if (r === null) return { rule, applied, status: 'no-data', value, valueText, requirementText, note: 'Not enough peers to rank this company.' };
      pass = r <= (applied.value as number);
      requirementText = `${applied.requirement} — this one ranks ${r} out of 100 against ${scope === 'sector' ? stock.sector : 'the whole list'}`;
      break;
    }
    case 'median_ratio_lte': {
      const med = ctx.median(applied.indicator, scope === 'sector' ? stock.sector : undefined);
      if (med === null || med <= 0) return { rule, applied, status: 'no-data', value, valueText, requirementText, note: 'No peer group available for this sector.' };
      const limit = med * (applied.value as number);
      pass = value > 0 && value <= limit;
      requirementText = `${applied.requirement} — peers sit at ${med.toFixed(1)}, so the limit here is ${limit.toFixed(1)}`;
      break;
    }
    case 'median_ratio_gte': {
      const med = ctx.median(applied.indicator, scope === 'sector' ? stock.sector : undefined);
      if (med === null) return { rule, applied, status: 'no-data', value, valueText, requirementText, note: 'No peer group available for this sector.' };
      const floor = med * (applied.value as number);
      pass = value >= floor;
      requirementText = `${applied.requirement} — peers sit at ${med.toFixed(1)}, so the floor here is ${floor.toFixed(1)}`;
      break;
    }
  }

  return { rule, applied, status: pass ? 'pass' : 'fail', value, valueText, requirementText, note };
}

export interface ConditionResult {
  option: Option;
  categoryId: CategoryId;
  categoryLabel: string;
  outcomes: RuleOutcome[];
  /** true when every applicable rule passed */
  matched: boolean;
  /** an option such as "no preference" applies no filter at all */
  noFilter: boolean;
  passCount: number;
  applicableCount: number;
}

export function evaluateCondition(stock: Stock, option: Option, ctx: UniverseContext): ConditionResult {
  const categoryLabel = CATEGORIES.find((c) => c.id === option.categoryId)?.label ?? option.categoryId;
  const outcomes = option.rules.map((r) => evaluateRule(stock, r, ctx));
  const applicable = outcomes.filter((o) => o.status !== 'not-applicable');
  const passCount = applicable.filter((o) => o.status === 'pass').length;
  return {
    option,
    categoryId: option.categoryId,
    categoryLabel,
    outcomes,
    noFilter: option.rules.length === 0,
    matched: option.rules.length === 0 ? true : applicable.length > 0 && passCount === applicable.length,
    passCount,
    applicableCount: applicable.length,
  };
}

/** The indicators a set of selections actually uses, in the order they appear. */
export function indicatorsUsed(optionIds: string[]): IndicatorId[] {
  const seen: IndicatorId[] = [];
  for (const id of optionIds) {
    const option = OPTION_BY_ID[id];
    if (!option) continue;
    for (const rule of option.rules) {
      for (const candidate of [rule.indicator, rule.substitute?.indicator]) {
        if (candidate && INDICATORS[candidate] && !seen.includes(candidate)) seen.push(candidate);
      }
    }
  }
  return seen;
}
