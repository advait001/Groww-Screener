import type { CategoryId } from '../data/config';
import { OPTION_BY_ID, SUMMARY_PHRASES } from '../data/config';
import type { Selections } from './screener';

export type Segment =
  | { kind: 'text'; text: string }
  | { kind: 'chip'; text: string; optionId: string; categoryId: CategoryId };

/** categories in the order they read well inside the sentence */
/** the order preferences read in a sentence; horizon always comes last */
const CLAUSE_ORDER: CategoryId[] = [
  'growth', 'profitability', 'stability', 'balance', 'cashflow', 'valuation',
  'momentum', 'performance', 'dividends', 'size', 'liquidity', 'composite',
];

export const SENTENCE_OPENER = "I'm looking for a company that";

export function composeSentence(sel: Selections): Segment[] {
  const main = CLAUSE_ORDER.map((c) => sel[c]).filter(Boolean) as string[];
  const horizonId = sel.horizon;
  const segments: Segment[] = [{ kind: 'text', text: SENTENCE_OPENER }];

  main.forEach((optionId, i) => {
    const option = OPTION_BY_ID[optionId];
    if (!option) return;
    if (i > 0) segments.push({ kind: 'text', text: i === main.length - 1 ? 'and' : ',' });
    segments.push({ kind: 'chip', text: option.clause, optionId, categoryId: option.categoryId });
  });

  if (horizonId && OPTION_BY_ID[horizonId]) {
    const option = OPTION_BY_ID[horizonId];
    segments.push({ kind: 'text', text: main.length ? '—' : 'I can hold' });
    segments.push({ kind: 'chip', text: option.clause, optionId: horizonId, categoryId: 'horizon' });
  }

  return segments;
}

/** Flat text version, for headings and saved-screen names. */
export function sentenceText(sel: Selections): string {
  const segs = composeSentence(sel);
  if (segs.length <= 1) return '';
  return segs
    .map((s) => s.text)
    .join(' ')
    .replace(/\s+,/g, ',')
    .replace(/\s+—/g, ' —')
    .trim() + '.';
}

/**
 * One readable line describing the whole screen, built from the chosen
 * preferences: "Companies that are growing steadily, relatively stable and
 * reasonably valued — to hold for the long term."
 */
export function plainSummary(sel: Selections): string {
  const main = CLAUSE_ORDER
    .map((c) => sel[c])
    .filter(Boolean)
    .map((id) => OPTION_BY_ID[id as string])
    .filter((o) => o && o.rules.length)
    .map((o) => SUMMARY_PHRASES[o.id] ?? o.chip.toLowerCase());

  const horizon = sel.horizon ? OPTION_BY_ID[sel.horizon] : undefined;
  const tail = horizon && horizon.rules.length ? ` — ${horizon.clause}` : '';

  if (!main.length) return horizon && horizon.rules.length ? `Companies you would hold ${horizon.clause}.` : '';
  const joined = main.length === 1
    ? main[0]
    : `${main.slice(0, -1).join(', ')} and ${main[main.length - 1]}`;
  return `Companies that are ${joined}${tail}.`;
}

/**
 * A readable name for a saved screen: the first two choices, then a count.
 * "Growing steadily + Relatively stable +4 more".
 */
export function screenName(sel: Selections): string {
  const chips = [...CLAUSE_ORDER, 'horizon' as CategoryId]
    .map((c) => sel[c])
    .filter(Boolean)
    .map((id) => OPTION_BY_ID[id as string])
    .filter((o) => o && o.rules.length)
    .map((o) => o.chip);
  if (!chips.length) return 'Empty screen';
  const head = chips.slice(0, 2).join(' + ');
  return chips.length > 2 ? `${head} +${chips.length - 2} more` : head;
}

/** Short label, e.g. "Growing steadily + Relatively stable + Long term". */
export function shortLabel(sel: Selections): string {
  const parts = [...CLAUSE_ORDER, 'horizon' as CategoryId]
    .map((c) => sel[c])
    .filter(Boolean)
    .map((id) => OPTION_BY_ID[id as string]?.chip)
    .filter(Boolean);
  return parts.join(' + ');
}
