import type { CategoryId, Option } from '../data/config';
import { CATEGORY_ORDER, CONFLICTS, OPTION_BY_ID, OPTIONS, optionsForCategory, CATEGORIES } from '../data/config';
import type { Stock, UniverseContext } from '../data/stocks';
import { STOCKS, buildUniverseContext } from '../data/stocks';
import { evaluateCondition, type ConditionResult } from './rules';

export type Selections = Partial<Record<CategoryId, string>>;

export const UNIVERSE: UniverseContext = buildUniverseContext(STOCKS);

export const selectedOptions = (sel: Selections): Option[] =>
  CATEGORY_ORDER.map((c) => sel[c]).filter(Boolean).map((id) => OPTION_BY_ID[id as string]).filter(Boolean);

/** Options that actually apply a filter (so "no preference" does not count). */
export const filteringOptions = (sel: Selections): Option[] => selectedOptions(sel).filter((o) => o.rules.length > 0);

export interface StockResult {
  stock: Stock;
  conditions: ConditionResult[];
  matchedCount: number;
  filterCount: number;
  exact: boolean;
  /** for a close match, the single condition that did not match */
  missed?: ConditionResult;
}

export interface ScreenRun {
  exact: StockResult[];
  close: StockResult[];
  filterCount: number;
  universeSize: number;
  selections: Selections;
}

export function evaluateStock(stock: Stock, sel: Selections, ctx = UNIVERSE): StockResult {
  const options = filteringOptions(sel);
  const conditions = options.map((o) => evaluateCondition(stock, o, ctx));
  const matchedCount = conditions.filter((c) => c.matched).length;
  const missedList = conditions.filter((c) => !c.matched);
  return {
    stock,
    conditions,
    matchedCount,
    filterCount: options.length,
    exact: missedList.length === 0,
    missed: missedList.length === 1 ? missedList[0] : undefined,
  };
}

export function runScreener(sel: Selections, stocks: Stock[] = STOCKS, ctx = UNIVERSE): ScreenRun {
  const filterCount = filteringOptions(sel).length;
  const evaluated = stocks.map((s) => evaluateStock(s, sel, ctx));
  return {
    exact: evaluated.filter((r) => r.exact),
    close: filterCount >= 2 ? evaluated.filter((r) => !r.exact && r.missed) : [],
    filterCount,
    universeSize: stocks.length,
    selections: sel,
  };
}

export const countMatches = (sel: Selections, stocks: Stock[] = STOCKS, ctx = UNIVERSE): number =>
  stocks.reduce((n, s) => n + (evaluateStock(s, sel, ctx).exact ? 1 : 0), 0);

/* ---------------------------------------------------------------- sorting */

export type SortKey = 'relevance' | 'marketCap' | 'return1Y' | 'valuation' | 'growth';

export const SORT_LABELS: Record<SortKey, string> = {
  relevance: 'Best matches first',
  marketCap: 'Biggest companies',
  return1Y: 'Best last year',
  valuation: 'Cheapest for what you get',
  growth: 'Fastest growing profit',
};

export function sortResults(rows: StockResult[], key: SortKey, ctx = UNIVERSE): StockResult[] {
  const out = [...rows];
  const peerRatio = (s: Stock) => {
    const median = ctx.median('pe', s.sector);
    if (!median || s.pe === null) return Number.POSITIVE_INFINITY;
    return s.pe / median;
  };
  out.sort((a, b) => {
    switch (key) {
      case 'marketCap': return b.stock.marketCap - a.stock.marketCap;
      case 'return1Y': return b.stock.return1Y - a.stock.return1Y;
      case 'valuation': return peerRatio(a.stock) - peerRatio(b.stock);
      case 'growth': return (b.stock.patCagr3Y ?? -999) - (a.stock.patCagr3Y ?? -999);
      case 'relevance':
      default:
        return (b.matchedCount - a.matchedCount) || (b.stock.marketCap - a.stock.marketCap);
    }
  });
  return out;
}

/* ------------------------------------------------------------ suggestions */

export interface Relaxation {
  categoryId: CategoryId;
  categoryLabel: string;
  optionLabel: string;
  /** how many stocks would match if this condition were dropped */
  resultingCount: number;
  gain: number;
}

/** What dropping each active condition would do. Nothing is changed for the user. */
export function relaxations(sel: Selections, stocks: Stock[] = STOCKS, ctx = UNIVERSE): Relaxation[] {
  const current = countMatches(sel, stocks, ctx);
  const out: Relaxation[] = [];
  for (const option of filteringOptions(sel)) {
    const next: Selections = { ...sel };
    delete next[option.categoryId];
    const resultingCount = countMatches(next, stocks, ctx);
    out.push({
      categoryId: option.categoryId,
      categoryLabel: CATEGORIES.find((c) => c.id === option.categoryId)?.label ?? option.categoryId,
      optionLabel: option.label,
      resultingCount,
      gain: resultingCount - current,
    });
  }
  return out.sort((a, b) => b.gain - a.gain);
}

export interface Narrowing {
  categoryId: CategoryId;
  categoryLabel: string;
  optionId: string;
  optionLabel: string;
  resultingCount: number;
}

/** Conditions the user has not used yet, with the count each would produce. */
export function narrowings(sel: Selections, stocks: Stock[] = STOCKS, ctx = UNIVERSE): Narrowing[] {
  const current = countMatches(sel, stocks, ctx);
  const out: Narrowing[] = [];
  for (const categoryId of CATEGORY_ORDER) {
    if (sel[categoryId]) continue;
    let best: Narrowing | null = null;
    for (const option of optionsForCategory(categoryId)) {
      if (!option.rules.length) continue;
      const resultingCount = countMatches({ ...sel, [categoryId]: option.id }, stocks, ctx);
      if (resultingCount === 0 || resultingCount >= current) continue;
      if (!best || resultingCount > best.resultingCount) {
        best = {
          categoryId,
          categoryLabel: CATEGORIES.find((c) => c.id === categoryId)?.label ?? categoryId,
          optionId: option.id,
          optionLabel: option.label,
          resultingCount,
        };
      }
    }
    if (best) out.push(best);
  }
  return out.sort((a, b) => b.resultingCount - a.resultingCount).slice(0, 3);
}

export interface ConflictNote {
  message: string;
  optionLabels: [string, string];
  optionIds: [string, string];
  /** the category of the second option, offered as the one to change */
  changeCategoryId: CategoryId;
  changeCategoryLabel: string;
}

export function conflicts(sel: Selections): ConflictNote[] {
  const active = new Set(selectedOptions(sel).map((o) => o.id));
  return CONFLICTS.filter((c) => c.options.every((id) => active.has(id))).map((c) => {
    const second = OPTION_BY_ID[c.options[1]];
    return {
      message: c.message,
      optionLabels: [OPTION_BY_ID[c.options[0]].label, second.label],
      optionIds: [c.options[0], c.options[1]],
      changeCategoryId: second.categoryId,
      changeCategoryLabel: CATEGORIES.find((x) => x.id === second.categoryId)?.label ?? second.categoryId,
    };
  });
}

/* ------------------------------------------ result column helper values */

export function peerValuationText(stock: Stock, ctx = UNIVERSE): string {
  const median = ctx.median('pe', stock.sector);
  if (stock.pe === null) return 'No profit to compare';
  if (!median) return `${stock.pe.toFixed(1)}x earnings`;
  const gap = ((stock.pe / median - 1) * 100);
  const word = Math.abs(gap) < 5 ? 'about the same as' : gap < 0 ? 'cheaper than' : 'dearer than';
  return `${stock.pe.toFixed(1)}x · ${word} similar`;
}

export function momentumText(stock: Stock): string {
  if (stock.rsi <= 40) return 'Weak, RSI ' + stock.rsi.toFixed(0);
  if (stock.priceVs200DMA >= 10 && stock.rsi >= 55) return 'Strong trend';
  if (stock.priceVs50DMA >= 0) return 'Improving';
  return 'Softening';
}

export function growthText(stock: Stock): string {
  if (stock.patCagr3Y === null) return 'No 3Y profit data';
  return `${stock.patCagr3Y > 0 ? '+' : ''}${stock.patCagr3Y.toFixed(1)}% profit, 3Y`;
}

export const ALL_OPTION_IDS = OPTIONS.map((o) => o.id);
