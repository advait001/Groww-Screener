/**
 * The goal planner.
 *
 * You say what you are saving for, how much, by when, and how much bouncing
 * around you can live with. This works out whether a monthly amount gets you
 * there, and which funds to split it across.
 *
 * Two rules keep it honest and are worth stating up front:
 *
 *   - Nothing is promised. Every projection carries a low / base / high band
 *     built from the categories in the mix, and the screens always show the
 *     low figure next to the base one.
 *   - When the goal is out of reach, this says so and offers the four real
 *     ways out (pay more, wait longer, take more risk, want less) with the
 *     exact number for each, rather than quietly rounding the answer up.
 *
 * The fund picking is a filter, not a recommendation: funds that fail the
 * quality bar are dropped, the rest are ranked on published figures, and the
 * best surviving fund in each category is taken. Same shape as the stock
 * screener — the user can see every rule that was applied.
 */
import {
  ALLOCATIONS, FUND_CATEGORIES, FUNDS,
  type Fund, type HorizonBand, type RiskId,
} from '../data/funds';

export interface RiskOption { id: RiskId; label: string; blurb: string; }

export const RISKS: RiskOption[] = [
  { id: 'low', label: 'Steady', blurb: 'Mostly safer funds. Grows slowly, but barely wobbles.' },
  { id: 'medium', label: 'Balanced', blurb: 'A mix of both. Some ups and downs along the way.' },
  { id: 'high', label: 'Bold', blurb: 'Mostly share funds. Can grow faster, can drop harder.' },
];

export const riskById = (id: RiskId) => RISKS.find((r) => r.id === id)!;

export const LIMITS = {
  goalMin: 10_000, goalMax: 1_000_000_000,
  yearsMin: 1, yearsMax: 40,
  monthlyMin: 1_000, monthlyMax: 1_000_000,
};

export interface GoalType {
  id: string; label: string; amount: number | null; years: number | null; name: string | null;
}

export const GOAL_TYPES: GoalType[] = [
  { id: 'home', label: 'A home', amount: 2_500_000, years: 7, name: 'home' },
  { id: 'car', label: 'A car', amount: 1_000_000, years: 4, name: 'car' },
  { id: 'education', label: 'Studies', amount: 2_500_000, years: 10, name: 'education' },
  { id: 'retirement', label: 'Retiring', amount: 20_000_000, years: 25, name: 'retirement' },
  { id: 'travel', label: 'A trip', amount: 300_000, years: 2, name: 'travel' },
  { id: 'other', label: 'Something else', amount: null, years: null, name: null },
];

export const goalTypeById = (id: string | null) => GOAL_TYPES.find((t) => t.id === id);

export const GOAL_CHIPS = [500_000, 1_000_000, 2_500_000, 5_000_000, 10_000_000];
export const YEAR_CHIPS = [3, 5, 10, 15, 20];
export const MONTHLY_CHIPS = [2_000, 5_000, 10_000, 25_000];

/* ------------------------------------------------------------------ maths */

const monthlyRate = (annual: number) => Math.pow(1 + annual, 1 / 12) - 1;

/** What a monthly investment grows to, paid at the start of each month. */
export function futureValue(monthly: number, months: number, annual: number): number {
  if (months <= 0) return 0;
  const r = monthlyRate(annual);
  return monthly * ((Math.pow(1 + r, months) - 1) / r) * (1 + r);
}

/** The monthly amount that reaches `goal` in `months`. */
export function monthlyNeeded(goal: number, months: number, annual: number): number {
  const r = monthlyRate(annual);
  return goal / (((Math.pow(1 + r, months) - 1) / r) * (1 + r));
}

/** How many months `monthly` takes to reach `goal`. */
export function monthsNeeded(goal: number, monthly: number, annual: number): number {
  if (monthly <= 0) return Infinity;
  const r = monthlyRate(annual);
  return Math.log(1 + (goal * r) / (monthly * (1 + r))) / Math.log(1 + r);
}

export const horizonBand = (years: number): HorizonBand =>
  (years <= 3 ? 'short' : years <= 7 ? 'medium' : 'long');

export const HORIZON_TEXT: Record<HorizonBand, string> = {
  short: 'under 3 years',
  medium: '4 to 7 years',
  long: '8 years or more',
};

/* ------------------------------------------------------- the mix and rate */

/** The categories for a risk and horizon, heaviest first. */
export function mixWeights(riskId: RiskId, years: number): [string, number][] {
  return Object.entries(ALLOCATIONS[riskId][horizonBand(years)])
    .sort((a, b) => b[1] - a[1]);
}

/** The blended low / base / high annual return of that mix. */
export function mixRates(riskId: RiskId, years: number) {
  const w = mixWeights(riskId, years);
  const total = w.reduce((a, [, x]) => a + x, 0);
  const blend = (i: 2 | 3 | 4) =>
    w.reduce((a, [cat, x]) => a + FUND_CATEGORIES[cat][i] * x, 0) / total;
  return { low: blend(2), base: blend(3), high: blend(4) };
}

/* ------------------------------------------------------------ fund picking */

/** The quality bar. A fund failing any of these never reaches the user. */
export const FUND_RULES = { minAum: 500, maxExp: 0.75, minSharpe: 0 };

let rankedCache: Record<string, Fund[]> | null = null;

/** Surviving funds per category, best first. */
export function rankedFunds(): Record<string, Fund[]> {
  if (rankedCache) return rankedCache;
  const by: Record<string, Fund[]> = {};
  for (const fund of FUNDS) {
    if (fund.aum < FUND_RULES.minAum) continue;
    if (fund.exp > FUND_RULES.maxExp) continue;
    if (fund.sharpe < FUND_RULES.minSharpe) continue;
    (by[fund.cat] = by[fund.cat] || []).push(fund);
  }
  for (const k in by) {
    by[k].sort((a, b) => b.sharpe - a.sharpe || a.exp - b.exp || b.aum - a.aum);
  }
  rankedCache = by;
  return by;
}

export const passedCount = () =>
  Object.values(rankedFunds()).reduce((a, l) => a + l.length, 0);

export const PALETTE = ['#00d09c', '#5b8def', '#f5a524', '#a16ae8', '#e5484d', '#d6409f', '#12a594'];

export const MIX_COUNT = 3;

export interface PlanSlice {
  fund: Fund;
  cat: string;
  pct: number;
  type: string;
  rates: { low: number; base: number; high: number };
  bench: string;
  color: string;
}

/**
 * One fund per category in the mix. `mixIndex` walks further down each
 * ranked list, so the user can flip through alternatives that still pass
 * every rule. No two slices come from the same fund house: concentrating a
 * plan in one AMC is a risk the user did not ask for.
 */
export function pickFunds(riskId: RiskId, years: number, mixIndex: number): PlanSlice[] {
  const ranked = rankedFunds();
  const usedAmc = new Set<string>();
  return mixWeights(riskId, years).map(([cat, pct], i) => {
    const pool = ranked[cat] || [];
    let fund: Fund | null = null;
    for (let j = mixIndex; j < pool.length; j++) {
      if (!usedAmc.has(pool[j].amc)) { fund = pool[j]; break; }
    }
    if (!fund) fund = pool[Math.min(mixIndex, pool.length - 1)];
    usedAmc.add(fund.amc);
    const c = FUND_CATEGORIES[cat];
    return {
      fund, cat, pct, type: c[0],
      rates: { low: c[2], base: c[3], high: c[4] },
      bench: c[5], color: PALETTE[i % PALETTE.length],
    };
  });
}

/** Split a total into whole rupees matching the weights, without losing a rupee. */
export function largestRemainder(values: number[], total: number): number[] {
  const floors = values.map(Math.floor);
  let rest = total - floors.reduce((a, b) => a + b, 0);
  const order = values
    .map((v, i) => [v - Math.floor(v), i] as [number, number])
    .sort((a, b) => b[0] - a[0]);
  for (let k = 0; rest > 0 && order.length; k++, rest--) {
    floors[order[k % order.length][1]]++;
  }
  return floors;
}

/* -------------------------------------------------------------- evaluating */

const roundUp = (n: number, step: number) => Math.ceil(n / step) * step;
const roundDown = (n: number, step: number) => Math.floor(n / step) * step;
const monthlyStep = (n: number) => (n < 100_000 ? 100 : 1_000);
const goalStep = (n: number) => (n < 100_000 ? 1_000 : n < 10_000_000 ? 10_000 : 100_000);

export type SuggestionKind = 'monthly' | 'years' | 'risk' | 'goal';

export interface Suggestion {
  kind: SuggestionKind;
  value: number | RiskId;
  title: string;
  sub: string;
}

export interface GoalInput {
  goal: number | null;
  years: number | null;
  monthly: number | null;
  risk: RiskId | null;
}

export interface GoalResult {
  complete: boolean;
  filled: { goal: boolean; years: boolean; monthly: boolean; risk: boolean };
  errors: Partial<Record<'goal' | 'years' | 'monthly', string>>;
  ready: boolean;
  months?: number;
  rates?: { low: number; base: number; high: number };
  rate?: number;
  projected?: number;
  low?: number;
  high?: number;
  invested?: number;
  feasible?: boolean;
  monthsToGoal?: number;
  safe?: boolean;
  shortfall?: number;
  suggestions?: Suggestion[];
}

const inr = (n: number) => '₹' + Math.round(n).toLocaleString('en-IN');
const pctText1 = (rate: number) => String(Number((rate * 100).toFixed(1))) + '%';

export function evaluate({ goal, years, monthly, risk }: GoalInput): GoalResult {
  const errors: GoalResult['errors'] = {};
  if (goal != null && goal < LIMITS.goalMin) errors.goal = 'Enter at least ₹10,000.';
  if (goal != null && goal > LIMITS.goalMax) errors.goal = 'Keep it under ₹100 crore.';
  if (years != null && (years < LIMITS.yearsMin || years > LIMITS.yearsMax)) {
    errors.years = 'Pick between 1 and 40 years.';
  }
  if (monthly != null && monthly < LIMITS.monthlyMin) {
    errors.monthly = 'At least ₹1,000 a month, so each fund gets ₹100 or more.';
  }
  if (monthly != null && monthly > LIMITS.monthlyMax) errors.monthly = 'Up to ₹10 lakh a month.';

  const filled = { goal: goal != null, years: years != null, monthly: monthly != null, risk: !!risk };
  const complete = filled.goal && filled.years && filled.monthly && filled.risk;
  if (!complete || Object.keys(errors).length) return { complete, filled, errors, ready: false };

  const months = years! * 12;
  const rates = mixRates(risk!, years!);
  const projected = futureValue(monthly!, months, rates.base);

  const res: GoalResult = {
    complete, filled, errors, ready: true,
    months, rates, rate: rates.base,
    projected,
    low: futureValue(monthly!, months, rates.low),
    high: futureValue(monthly!, months, rates.high),
    invested: monthly! * months,
    feasible: projected >= goal!,
  };

  if (res.feasible) {
    res.monthsToGoal = Math.max(1, Math.ceil(monthsNeeded(goal!, monthly!, rates.base)));
    // "safe" only when even the pessimistic rate gets there
    res.safe = res.low! >= goal!;
    return res;
  }

  res.shortfall = goal! - projected;
  const s: Suggestion[] = [];

  const needMonthly = monthlyNeeded(goal!, months, rates.base);
  const newMonthly = roundUp(needMonthly, monthlyStep(needMonthly));
  if (newMonthly <= LIMITS.monthlyMax) {
    s.push({
      kind: 'monthly', value: newMonthly,
      title: `Put in ${inr(newMonthly)} a month`,
      sub: `${inr(newMonthly - monthly!)} more each month, same ${years} years`,
    });
  }

  let newYears: number | null = null;
  for (let y = years! + 1; y <= LIMITS.yearsMax; y++) {
    if (futureValue(monthly!, y * 12, mixRates(risk!, y).base) >= goal!) { newYears = y; break; }
  }
  if (newYears) {
    const extra = newYears - years!;
    s.push({
      kind: 'years', value: newYears,
      title: `Keep going for ${newYears} years`,
      sub: `${extra} more year${extra === 1 ? '' : 's'}, same ${inr(monthly!)} a month`,
    });
  }

  const order = RISKS.map((r) => r.id);
  const higher = RISKS.find((r) =>
    order.indexOf(r.id) > order.indexOf(risk!) &&
    futureValue(monthly!, months, mixRates(r.id, years!).base) >= goal!);
  if (higher) {
    s.push({
      kind: 'risk', value: higher.id,
      title: `Try the ${higher.label.toLowerCase()} mix`,
      sub: `More in share funds: about ${pctText1(mixRates(higher.id, years!).base)} a year, with bigger ups and downs`,
    });
  }

  const reachable = roundDown(projected, goalStep(projected));
  if (reachable >= LIMITS.goalMin) {
    s.push({
      kind: 'goal', value: reachable,
      title: `Aim for ${inrShort(reachable)} instead`,
      sub: `What ${inr(monthly!)} a month for ${years} years could reach`,
    });
  }

  res.suggestions = s;
  return res;
}

/* ------------------------------------------------------------- formatting */

export const trimNum = (x: number, d = 2) => String(Number(x.toFixed(d)));

export { inr };

export function inrShort(n: number): string {
  if (n >= 10_000_000) return '₹' + trimNum(n / 10_000_000) + ' Cr';
  if (n >= 100_000) return '₹' + trimNum(n / 100_000) + ' L';
  return inr(n);
}

export function inWords(n: number): string {
  if (n >= 10_000_000) return '₹' + trimNum(n / 10_000_000) + ' crore';
  if (n >= 100_000) return '₹' + trimNum(n / 100_000) + ' lakh';
  if (n >= 1_000) return '₹' + trimNum(n / 1_000) + ' thousand';
  return inr(n);
}

export function durationText(months: number): string {
  const y = Math.floor(months / 12);
  const m = months % 12;
  const ys = y ? `${y} year${y === 1 ? '' : 's'}` : '';
  const ms = m ? `${m} month${m === 1 ? '' : 's'}` : '';
  return [ys, ms].filter(Boolean).join(' ') || 'under a month';
}

export const pctText = (rate: number) => Math.round(rate * 100) + '%';

export const parseDigits = (str: string): number | null => {
  const d = String(str).replace(/[^0-9]/g, '').slice(0, 12);
  return d ? Number(d) : null;
};

export const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

export function nextDebitDate(): string {
  const now = new Date();
  const d = new Date(now.getFullYear(), now.getMonth() + (now.getDate() >= 5 ? 1 : 0), 5);
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

export const amcShort = (amc: string) => amc.replace(/ Mutual Fund$/, '');
