import type { CategoryId } from './config';

export type ProfileFieldId = 'goal' | 'horizon' | 'amount' | 'behaviour' | 'experience';

export interface ProfileChoice {
  id: string;
  label: string;
  /** shown under the label on the option row */
  note?: string;
}

export interface ProfileQuestion {
  id: ProfileFieldId;
  title: string;
  help: string;
  kind: 'single' | 'amount';
  choices?: ProfileChoice[];
  presets?: number[];
}

export const PROFILE_QUESTIONS: ProfileQuestion[] = [
  {
    id: 'goal',
    title: 'What are you investing for?',
    help: 'This shapes the examples you see. It does not pick any stock for you.',
    kind: 'single',
    choices: [
      { id: 'wealth', label: 'Building wealth over many years' },
      { id: 'savings', label: 'Growing my savings' },
      { id: 'income', label: 'Creating another source of income' },
      { id: 'shortterm', label: 'Exploring shorter-term opportunities' },
      { id: 'learn', label: 'Learning how investing works' },
      { id: 'exploring', label: 'Just having a look around' },
    ],
  },
  {
    id: 'horizon',
    title: 'How long could you stay invested?',
    help: 'Time affects which periods the screener looks at, so this one is worth answering.',
    kind: 'single',
    choices: [
      { id: 'months', label: 'A few months' },
      { id: '1to3', label: '1 to 3 years' },
      { id: '3to5', label: '3 to 5 years' },
      { id: '5plus', label: '5 years or more' },
      { id: 'unsure', label: "I'm not sure yet" },
    ],
  },
  {
    id: 'amount',
    title: 'Roughly how much are you thinking of investing?',
    help: 'Used only to show how many shares an amount buys. It is not invested anywhere and does not change which stocks match.',
    kind: 'amount',
    presets: [5000, 25000, 50000, 100000],
  },
  {
    id: 'behaviour',
    title: 'Say you invest ₹10,000 and a few weeks later it is worth ₹8,500. What would you most likely do?',
    help: 'A scenario is easier to answer honestly than a question about risk tolerance.',
    kind: 'single',
    choices: [
      { id: 'exit', label: 'Feel uncomfortable and think about getting out' },
      { id: 'wait', label: 'Wait and watch for a while' },
      { id: 'hold', label: 'Stay invested and leave it alone' },
      { id: 'buy', label: 'Consider putting in a bit more' },
      { id: 'unsure', label: "I really don't know" },
    ],
  },
  {
    id: 'experience',
    title: 'How familiar are you with stock investing?',
    help: 'This sets how much explaining the screener does as you go.',
    kind: 'single',
    choices: [
      { id: 'new', label: 'Completely new to it' },
      { id: 'basics', label: 'I know the basics' },
      { id: 'occasional', label: 'I invest now and then' },
      { id: 'confident', label: 'I already read financial indicators' },
    ],
  },
];

export interface Profile {
  goal?: string;
  horizon?: string;
  amount?: number;
  behaviour?: string;
  experience?: string;
}

/* ------------------------------------------------- reading the profile back */

const GOAL_SUMMARY: Record<string, string> = {
  wealth: 'Long-term wealth',
  savings: 'Growing savings',
  income: 'Extra income',
  shortterm: 'Shorter-term ideas',
  learn: 'Learning',
  exploring: 'Exploring',
};

const HORIZON_SUMMARY: Record<string, string> = {
  months: 'A few months',
  '1to3': '1 to 3 years',
  '3to5': '3 to 5 years',
  '5plus': '5 years or more',
  unsure: 'Not decided',
};

const BEHAVIOUR_SUMMARY: Record<string, string> = {
  exit: 'Prefers calmer holdings',
  wait: 'Can sit through a dip',
  hold: 'Comfortable through a dip',
  buy: 'Comfortable adding in a dip',
  unsure: 'Still finding out',
};

const EXPERIENCE_SUMMARY: Record<string, string> = {
  new: 'New to stocks',
  basics: 'Knows the basics',
  occasional: 'Invests occasionally',
  confident: 'Reads indicators already',
};

export interface ProfileSummaryRow {
  label: string;
  value: string;
  fieldId: ProfileFieldId;
}

export function profileSummary(p: Profile): ProfileSummaryRow[] {
  const rows: ProfileSummaryRow[] = [];
  if (p.goal) rows.push({ label: 'Goal', value: GOAL_SUMMARY[p.goal] ?? p.goal, fieldId: 'goal' });
  if (p.horizon) rows.push({ label: 'Time you can stay invested', value: HORIZON_SUMMARY[p.horizon] ?? p.horizon, fieldId: 'horizon' });
  if (p.amount) rows.push({ label: 'Amount in mind', value: `₹${p.amount.toLocaleString('en-IN')}`, fieldId: 'amount' });
  if (p.behaviour) rows.push({ label: 'If the price dips', value: BEHAVIOUR_SUMMARY[p.behaviour] ?? p.behaviour, fieldId: 'behaviour' });
  if (p.experience) rows.push({ label: 'Experience', value: EXPERIENCE_SUMMARY[p.experience] ?? p.experience, fieldId: 'experience' });
  return rows;
}

/**
 * Options worth pointing at, given the profile. These are suggestions only:
 * nothing is selected for the user.
 */
export function suggestedOptionIds(p: Profile): Partial<Record<CategoryId, string>> {
  const out: Partial<Record<CategoryId, string>> = {};
  if (p.horizon === 'months') out.horizon = 'horizon-short';
  if (p.horizon === '1to3') out.horizon = 'horizon-medium';
  if (p.horizon === '3to5' || p.horizon === '5plus') out.horizon = 'horizon-long';
  if (p.behaviour === 'exit') out.stability = 'stability-stable';
  if (p.behaviour === 'wait') out.stability = 'stability-low-beta';
  if (p.behaviour === 'buy') out.stability = 'momentum-strong';
  if (p.goal === 'wealth') out.growth = 'growth-steady';
  if (p.goal === 'shortterm') out.momentum = 'momentum-improving';
  return out;
}

/** Beginners get explanations opened by default; confident users get the technical names. */
export function explanationDepth(p: Profile): 'full' | 'standard' | 'technical' {
  if (p.experience === 'new') return 'full';
  if (p.experience === 'confident') return 'technical';
  return 'standard';
}
