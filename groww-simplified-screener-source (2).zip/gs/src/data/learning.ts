/**
 * The learning layer. It adds beginner-facing teaching content on top of the
 * indicators the rule engine already uses — it never defines a second mapping.
 * "Good to know" is read straight from the indicator metadata so the caveat a
 * user reads here is the same one the lesson modal shows.
 */

import type { IconName, IndicatorId, Option } from './config';
import { INDICATORS } from './indicators';

export type LearnVisualKind =
  | 'growthBars' | 'consistency' | 'levelBar' | 'debtLevel' | 'coverage'
  | 'cashFlow' | 'peerBars' | 'volatilityPaths' | 'returns' | 'gauge' | 'trendLine';

export interface LearnStep {
  title: string;
  desc: string;
  icon: 'bars' | 'compare' | 'trendUp' | 'shield' | 'coins' | 'scales' | 'target' | 'pulse';
}

export interface LearningModule {
  /** short title used on the learning cards */
  title: string;
  /** one line for the overview card: "Checks if ..." */
  checks: string;
  /** one line for "What it means" */
  means: string;
  /** the hedged takeaway shown beside the visual */
  insight: string;
  visual: LearnVisualKind;
  steps: [LearnStep, LearnStep, LearnStep];
  /** suggested further reading when the current screen has nothing else to show */
  related?: IndicatorId[];
}

const s = (icon: LearnStep['icon'], title: string, desc: string): LearnStep => ({ icon, title, desc });

export const LEARNING: Partial<Record<IndicatorId, LearningModule>> = {
  revenueCagr3Y: {
    title: 'Revenue Growth',
    checks: "Checks if the company's revenue is increasing.",
    means: "It shows whether a company's sales are increasing over time.",
    insight: 'Higher revenue over time can mean the business is growing.',
    visual: 'growthBars',
    steps: [
      s('bars', "Look at this year's sales", 'The latest reported revenue figure.'),
      s('compare', 'Compare with earlier years', 'Revenue from three years ago.'),
      s('trendUp', 'See if the trend holds', 'Growth should be positive and repeatable.'),
    ],
    related: ['patCagr3Y', 'profitConsistency'],
  },
  patCagr3Y: {
    title: 'Profit Growth',
    checks: 'Checks if profits are increasing over time.',
    means: 'It shows whether what the company keeps after costs is getting bigger.',
    insight: 'Profit rising faster than sales can suggest costs are under control.',
    visual: 'growthBars',
    steps: [
      s('bars', 'Take the latest profit', 'Net profit for the most recent year.'),
      s('compare', 'Compare across three years', 'The same figure three years earlier.'),
      s('trendUp', 'Check the yearly pace', 'The average yearly rate it grew at.'),
    ],
    related: ['revenueCagr3Y', 'profitConsistency'],
  },
  profitConsistency: {
    title: 'Earnings Consistency',
    checks: 'Checks how often profit actually grew.',
    means: 'It counts the years in the last four where profit was higher than before.',
    insight: 'Growth that repeats can matter more than one unusually strong year.',
    visual: 'consistency',
    steps: [
      s('bars', 'Line up four years', 'Profit for each of the last four years.'),
      s('compare', 'Compare each with the year before', 'Higher or lower, one year at a time.'),
      s('target', 'Count the ups', 'Three or four out of four is consistent.'),
    ],
    related: ['patCagr3Y', 'cfoPositive'],
  },
  roe: {
    title: 'Return on Equity',
    checks: 'Checks how well the company uses shareholder money.',
    means: 'It shows the profit earned on every rupee shareholders have put in.',
    insight: 'A steady, healthy figure can point to an efficient business.',
    visual: 'levelBar',
    steps: [
      s('coins', 'Start with net profit', 'What the company earned for the year.'),
      s('scales', 'Divide by shareholder money', 'The capital shareholders have in the business.'),
      s('compare', 'Compare within the industry', 'Normal levels differ a lot by sector.'),
    ],
    related: ['roce', 'patCagr3Y'],
  },
  roce: {
    title: 'Return on Capital',
    checks: 'Checks the return on all money used by the business.',
    means: 'It looks at profit against every rupee in the business, borrowed or owned.',
    insight: 'A return comfortably above borrowing costs can suggest capital is well used.',
    visual: 'levelBar',
    steps: [
      s('coins', 'Take operating profit', 'Profit before interest and tax.'),
      s('scales', 'Divide by capital employed', 'Debt plus equity used in the business.'),
      s('compare', 'Compare with borrowing costs', 'Earning less than it pays is a warning.'),
    ],
    related: ['roe', 'interestCoverage'],
  },
  debtToEquity: {
    title: 'Debt Level',
    checks: 'Checks if the company has manageable debt.',
    means: 'It compares what the company has borrowed with what shareholders have put in.',
    insight: 'Lower debt can mean more stability, though it is only one part of risk.',
    visual: 'debtLevel',
    steps: [
      s('coins', 'Add up borrowings', 'All the money the company owes lenders.'),
      s('scales', 'Set it against shareholder money', 'The capital shareholders have invested.'),
      s('shield', 'See how heavy it is', 'Under half is light for most industries.'),
    ],
    related: ['interestCoverage', 'cfoPositive'],
  },
  interestCoverage: {
    title: 'Interest Cover',
    checks: 'Checks if profit comfortably covers interest.',
    means: 'It shows how many times over the profit could pay the interest bill.',
    insight: 'A wider margin leaves more room if profits dip for a year.',
    visual: 'coverage',
    steps: [
      s('coins', 'Take operating profit', 'Profit before interest is paid.'),
      s('scales', 'Divide by the interest bill', 'What the company owes lenders this year.'),
      s('shield', 'Read the multiple', 'Below about two leaves very little room.'),
    ],
    related: ['debtToEquity', 'cfoPositive'],
  },
  capitalAdequacy: {
    title: 'Capital Buffer',
    checks: "Checks a lender's cushion against its loans.",
    means: 'For a bank, it shows how much of its own capital sits behind the loans it makes.',
    insight: 'Regulators set a floor, and a buffer above it gives room to absorb losses.',
    visual: 'levelBar',
    steps: [
      s('coins', "Take the lender's own capital", 'The money that absorbs losses first.'),
      s('scales', 'Weigh the loans by risk', 'Riskier lending counts for more.'),
      s('shield', 'Compare with the minimum', 'Comfortably above the floor is the expectation.'),
    ],
    related: ['roe', 'profitConsistency'],
  },
  cfoPositive: {
    title: 'Cash Flow',
    checks: 'Checks if day-to-day business brings in cash.',
    means: 'It looks at whether operations produce more cash than they consume.',
    insight: 'Profit is an accounting figure; cash is what actually arrives.',
    visual: 'cashFlow',
    steps: [
      s('coins', 'Count cash in', 'Money customers actually paid.'),
      s('compare', 'Subtract cash out', 'Suppliers, salaries and running costs.'),
      s('target', 'Check the balance', 'Positive is the normal expectation.'),
    ],
    related: ['patCagr3Y', 'interestCoverage'],
  },
  pe: {
    title: 'P/E vs peers',
    checks: 'Checks if the stock is reasonably valued.',
    means: 'It compares the price with what similar companies cost for the same earnings.',
    insight: 'Helps find companies that may not be overpriced next to their peers.',
    visual: 'peerBars',
    steps: [
      s('coins', 'Take the share price', 'What one share costs today.'),
      s('scales', 'Divide by earnings per share', 'Profit spread across all shares.'),
      s('compare', 'Compare with the sector', 'The same number means different things by industry.'),
    ],
    related: ['pb', 'peg'],
  },
  pb: {
    title: 'Price vs Book',
    checks: 'Checks the price against what the company owns.',
    means: 'It compares the share price with the accounting value of the business.',
    insight: 'Most useful for banks and asset-heavy companies.',
    visual: 'peerBars',
    steps: [
      s('coins', 'Take the share price', 'What one share costs today.'),
      s('scales', 'Divide by book value', 'Assets less what the company owes.'),
      s('compare', 'Compare with similar companies', 'Different industries sit at different levels.'),
    ],
    related: ['pe', 'roe'],
  },
  peg: {
    title: 'Price vs Growth',
    checks: 'Checks whether a high price is backed by growth.',
    means: 'It sets the P/E against how fast profits are growing.',
    insight: 'A lower figure means less is being paid for each unit of growth.',
    visual: 'levelBar',
    steps: [
      s('scales', 'Start with the P/E', 'What is being paid for earnings today.'),
      s('compare', 'Divide by the growth rate', 'How fast profit has been rising.'),
      s('target', 'Read the balance', 'It assumes the growth continues, which is not certain.'),
    ],
    related: ['pe', 'patCagr3Y'],
  },
  beta: {
    title: 'Market Sensitivity',
    checks: 'Checks how closely the share follows the market.',
    means: 'It shows whether the share has moved more or less than the wider market.',
    insight: 'It describes past movement, not how risky the business is.',
    visual: 'volatilityPaths',
    steps: [
      s('pulse', 'Track daily moves', 'The share and the index, side by side.'),
      s('compare', 'Compare the two', 'How much the share moves per market move.'),
      s('target', 'Read the number', 'Around 1 means it moved in line.'),
    ],
    related: ['volatility', 'maxDrawdown1Y'],
  },
  volatility: {
    title: 'Price Swings',
    checks: 'Checks how much the price bounces around.',
    means: 'It measures how widely the price moved over the past year.',
    insight: 'Bigger swings cut both ways, and a calm year can be followed by a rough one.',
    visual: 'volatilityPaths',
    steps: [
      s('pulse', 'Look at daily moves', 'How much the price changed each day.'),
      s('bars', 'Measure the spread', 'How far those moves sit from the average.'),
      s('compare', 'Compare with other companies', 'This screen ranks it against the whole list.'),
    ],
    related: ['maxDrawdown1Y', 'beta'],
  },
  maxDrawdown1Y: {
    title: 'Worst Fall',
    checks: 'Checks the deepest drop over the past year.',
    means: 'It shows the largest fall from a high point to the low that followed.',
    insight: 'Two shares can end a year the same and feel completely different along the way.',
    visual: 'returns',
    steps: [
      s('pulse', 'Track the price all year', 'Every high and low along the way.'),
      s('compare', 'Find the biggest drop', 'From a peak down to the following trough.'),
      s('shield', 'Read it with returns', 'It describes the journey, not the destination.'),
    ],
    related: ['volatility', 'return1Y'],
  },
  rsi: {
    title: 'Recent Momentum',
    checks: 'Checks how one-sided recent price moves have been.',
    means: 'It scores recent gains against recent losses on a 0 to 100 scale.',
    insight: 'A low reading describes a steep fall. It does not mean a rebound is due.',
    visual: 'gauge',
    steps: [
      s('bars', 'Add up recent gains', 'Days the price closed higher.'),
      s('compare', 'Set them against recent losses', 'Days the price closed lower.'),
      s('target', 'Place it on the scale', 'Below 30 is called oversold, above 70 overbought.'),
    ],
    related: ['priceVs50DMA', 'priceVs200DMA'],
  },
  priceVs50DMA: {
    title: 'Price Trend',
    checks: "Checks if the stock's price is moving in a positive trend.",
    means: "It compares today's price with its average over recent weeks.",
    insight: 'A rising trend can indicate stronger recent interest, and it can reverse quickly.',
    visual: 'trendLine',
    steps: [
      s('bars', 'Average the last 50 days', 'A smooth line through the daily noise.'),
      s('compare', "Compare today's price with it", 'Above the line, or below it.'),
      s('trendUp', 'Read the direction', 'Above usually describes an improving trend.'),
    ],
    related: ['priceVs200DMA', 'rsi'],
  },
  priceVs200DMA: {
    title: 'Long-term Trend',
    checks: 'Checks the price against its longer average.',
    means: 'It compares the price with its average over roughly the last year of trading.',
    insight: 'It reacts slowly, so it can stay positive well after a trend has turned.',
    visual: 'trendLine',
    steps: [
      s('bars', 'Average about 200 days', 'Roughly a year of trading.'),
      s('compare', 'Compare the price with it', 'Well above, near, or below.'),
      s('trendUp', 'Read the longer trend', 'It describes months, not days.'),
    ],
    related: ['priceVs50DMA', 'return1Y'],
  },
  return1Y: {
    title: '1-Year Return',
    checks: 'Checks how the share has done over a year.',
    means: 'It shows the price change over the past twelve months.',
    insight: 'One year captures a mood as much as a business. Past returns do not predict future ones.',
    visual: 'returns',
    steps: [
      s('bars', 'Take the price a year ago', 'The starting point.'),
      s('compare', "Compare with today's price", 'The change between the two.'),
      s('target', 'Read it with the drop along the way', 'The same return can feel very different.'),
    ],
    related: ['return3Y', 'maxDrawdown1Y'],
  },
  return3Y: {
    title: '3-Year Return',
    checks: 'Checks the return over a longer window.',
    means: 'It shows the average yearly price change over three years.',
    insight: 'A longer window smooths out one unusual year, but still covers only part of a cycle.',
    visual: 'returns',
    steps: [
      s('bars', 'Take the price three years ago', 'The starting point.'),
      s('compare', 'Compare with today', 'The total change over the period.'),
      s('target', 'Spread it across the years', 'That gives the average yearly rate.'),
    ],
    related: ['return1Y', 'patCagr3Y'],
  },
  marketCap: {
    title: 'Company Size',
    checks: 'Checks how large the company is.',
    means: 'It is the share price multiplied by the number of shares.',
    insight: 'Size is not safety. Large companies fall too.',
    visual: 'levelBar',
    steps: [
      s('coins', 'Take the share price', 'What one share costs.'),
      s('compare', 'Multiply by shares outstanding', 'Every share the company has issued.'),
      s('scales', 'Place it on the scale', 'Large, mid or small, by convention.'),
    ],
    related: ['avgDailyValue', 'listedYears'],
  },
  avgDailyValue: {
    title: 'Trading Activity',
    checks: 'Checks how easily the share can be bought or sold.',
    means: 'It shows how much of the share changes hands on a typical day.',
    insight: 'Activity can dry up exactly when you most want to sell.',
    visual: 'levelBar',
    steps: [
      s('bars', 'Count shares traded', 'Volume on a normal day.'),
      s('coins', 'Multiply by the price', 'That gives the value traded.'),
      s('compare', 'Average across recent sessions', 'One busy day does not count.'),
    ],
    related: ['marketCap', 'volatility'],
  },
  listedYears: {
    title: 'Listing History',
    checks: 'Checks how long the company has been listed.',
    means: 'It sets a limit on how much history any other check can use.',
    insight: 'A long listing says nothing about how the business is run today.',
    visual: 'levelBar',
    steps: [
      s('target', 'Find the listing date', 'When the shares first traded.'),
      s('compare', 'Count the years since', 'How much public history exists.'),
      s('shield', 'Match it to the window', 'A three-year check needs three years of data.'),
    ],
    related: ['marketCap', 'profitConsistency'],
  },
};

const ICONS: Record<IndicatorId, IconName> = {
  revenueCagr3Y: 'bars', patCagr3Y: 'trendUp', profitConsistency: 'target',
  roe: 'scales', roce: 'scales', debtToEquity: 'shield', interestCoverage: 'coins',
  capitalAdequacy: 'shield', cfoPositive: 'coins',
  pe: 'tag', pb: 'compare', peg: 'premium',
  beta: 'pulse', volatility: 'swing', maxDrawdown1Y: 'guard',
  rsi: 'pulse', priceVs50DMA: 'trendUp', priceVs200DMA: 'trendStrong',
  return1Y: 'spark', return3Y: 'steady',
  marketCap: 'pillar', avgDailyValue: 'coins', listedYears: 'clockLong',
};

const FALLBACK_VISUAL: Record<string, LearnVisualKind> = {
  pct: 'levelBar', x: 'levelBar', bool: 'cashFlow',
};

/**
 * Indicators without a hand-written lesson still teach themselves: the content
 * is read from the indicator metadata, so there is one source of truth for what
 * a number means and where it misleads.
 */
export function learningFor(id: IndicatorId): LearningModule {
  const written = LEARNING[id];
  if (written) return written;
  const meta = INDICATORS[id];
  return {
    title: meta.name,
    checks: meta.what,
    means: meta.what,
    insight: meta.read,
    visual: FALLBACK_VISUAL.pct,
    steps: [
      { title: 'Take the figure', desc: `${meta.name} is read from the company's latest reported data.`, icon: 'bars' },
      { title: 'Apply the rule', desc: 'The screen compares it with the threshold or the peer group your filter uses.', icon: 'compare' },
      { title: 'Read it in context', desc: meta.read, icon: 'target' },
    ],
    related: [],
  };
}

export const iconForIndicator = (id: IndicatorId): IconName => ICONS[id] ?? 'bars';

export const learnTitle = (id: IndicatorId) => LEARNING[id]?.title ?? INDICATORS[id].name;
/** the honest caveat, taken from the indicator metadata rather than rewritten */
export const goodToKnow = (id: IndicatorId) => INDICATORS[id].limitation;

/** every indicator a preference relies on, in rule order, substitutions included */
export function indicatorsForOption(option: Option): IndicatorId[] {
  const out: IndicatorId[] = [];
  for (const rule of option.rules) {
    for (const id of [rule.indicator, rule.substitute?.indicator]) {
      if (id && !out.includes(id)) out.push(id);
    }
  }
  return out;
}

/** the one shown first on the overview; the rest sit behind "+n more" */
export const primaryIndicatorFor = (option: Option) => indicatorsForOption(option)[0];
