import type { CategoryId, IconName } from './config';
import type { Selections } from '../engine/screener';

/**
 * Ready-made starting points. Each one is just a set of the same preferences a
 * user could pick by hand, so the rule engine, the explanations and the counts
 * all work exactly as they do for a hand-built screen. The card shows only the
 * name and the theme; the filters inside are revealed when it is opened.
 */
export interface ScreenTemplate {
  id: string;
  name: string;
  /** one or two words, shown under the name */
  theme: string;
  /** the fuller line, shown once the card is opened */
  description: string;
  icon: IconName;
  /** which category colour the card's mark takes */
  accent: CategoryId;
  selections: Selections;
}

export const TEMPLATES: ScreenTemplate[] = [
  {
    id: 'quality-compounders', name: 'Slow and steady winners', theme: 'Calm · long wait',
    description: 'Solid companies that grow a bit every year and do not jump around.',
    icon: 'target', accent: 'growth',
    selections: { growth: 'growth-steady', stability: 'stability-stable', horizon: 'horizon-long' },
  },
  {
    id: 'steady-performers', name: 'Reliable all-rounders', theme: 'Good track record',
    description: 'They have made money year after year and their profit is real cash.',
    icon: 'steady', accent: 'performance',
    selections: { performance: 'performance-steady', stability: 'stability-stable', cashflow: 'cash-backed' },
  },
  {
    id: 'value-opportunities', name: 'Bargain hunting', theme: 'Cheap for what you get',
    description: 'Cheaper than similar companies, but still earning properly.',
    icon: 'tag', accent: 'valuation',
    selections: { valuation: 'valuation-discount', balance: 'balance-manageable', profitability: 'profit-roe' },
  },
  {
    id: 'high-growth', name: 'Growing really fast', theme: 'Fast growers',
    description: 'Companies shooting up, whose share price is climbing too.',
    icon: 'rocket', accent: 'growth',
    selections: { growth: 'growth-fast', momentum: 'momentum-positive' },
  },
  {
    id: 'dividend-income', name: 'Companies that pay you', theme: 'Money in your pocket',
    description: 'Big companies that hand money back to you every year.',
    icon: 'premium', accent: 'dividends',
    selections: { dividends: 'dividend-steady', cashflow: 'cash-fcf', size: 'size-large' },
  },
  {
    id: 'cash-machines', name: 'Great at making cash', theme: 'Real money makers',
    description: 'Their profit turns into actual cash, and their debt is under control.',
    icon: 'wave', accent: 'cashflow',
    selections: { cashflow: 'cash-strong', profitability: 'profit-quality', balance: 'balance-manageable' },
  },
  {
    id: 'low-debt-defensives', name: 'Safe and boring', theme: 'Plays it safe',
    description: 'Hardly any borrowing, a calm price, and no losses last year.',
    icon: 'shield', accent: 'balance',
    selections: { balance: 'balance-low-debt', stability: 'stability-low-vol', performance: 'performance-positive' },
  },
  {
    id: 'turnaround-watch', name: 'Companies bouncing back', theme: 'On the mend',
    description: 'They had a rough few years and are starting to turn around.',
    icon: 'recovery', accent: 'momentum',
    selections: { growth: 'growth-recovery', performance: 'performance-recovery' },
  },
  {
    id: 'blue-chip-basics', name: 'The big famous ones', theme: 'The giants',
    description: 'The biggest, calmest companies that are easy to buy and sell.',
    icon: 'pillar', accent: 'size',
    selections: { size: 'size-large', liquidity: 'liquidity-high', stability: 'stability-stable' },
  },
  {
    id: 'growth-at-a-price', name: 'Fast growers that are not pricey', theme: 'Growth, fair price',
    description: 'They are growing quickly without costing a fortune.',
    icon: 'scales', accent: 'valuation',
    selections: { valuation: 'valuation-growth-value', profitability: 'profit-roe' },
  },
  {
    id: 'momentum-leaders', name: 'On a winning streak', theme: 'Climbing fast',
    description: 'Their price has been climbing and beating almost everyone else.',
    icon: 'trendStrong', accent: 'momentum',
    selections: { momentum: 'momentum-strong', performance: 'performance-strong', liquidity: 'liquidity-active' },
  },
  {
    id: 'small-cap-explorers', name: 'Small but speedy', theme: 'Little and fast',
    description: 'Smaller companies that are growing quickly.',
    icon: 'sprout', accent: 'size',
    selections: { size: 'size-small', growth: 'growth-fast', liquidity: 'liquidity-active' },
  },
];
