/**
 * The screener is configuration driven: every plain-English tag the user can
 * pick lives here together with the financial rules it compiles into, in the
 * shape the product spec describes — tag, simple meaning, UI tier, rules,
 * sector policy and guardrail. Adding a tag means adding an object here.
 */

export type IndicatorId =
  // growth
  | 'revenueCagr3Y' | 'revenueCagr5Y' | 'revenueYoY' | 'patCagr3Y' | 'patYoY' | 'epsCagr3Y'
  | 'profitConsistency' | 'revenueUpYears'
  // profitability
  | 'ebitdaMargin' | 'netMargin' | 'marginTrendBps' | 'roe' | 'roce' | 'roa'
  // balance sheet
  | 'debtToEquity' | 'netDebtEbitda' | 'interestCoverage' | 'currentRatio' | 'capitalAdequacy'
  // cash flow
  | 'cfoPositive' | 'cfoPatRatio' | 'fcfPositive' | 'capexRevenue' | 'cfoUpYears'
  // valuation
  | 'pe' | 'pb' | 'evEbitda' | 'evSales' | 'peg' | 'earningsYield'
  // performance and risk
  | 'return1M' | 'return3M' | 'return6M' | 'return1Y' | 'return3Y' | 'return5Y'
  | 'volatility' | 'beta' | 'maxDrawdown1Y' | 'downsideDeviation'
  // momentum
  | 'rsi' | 'priceVs20DMA' | 'priceVs50DMA' | 'priceVs200DMA' | 'ma50Slope' | 'distance52wHigh' | 'volumeRatio'
  // size, liquidity, income, ownership
  | 'marketCap' | 'avgDailyValue' | 'freeFloatPct' | 'listedYears'
  | 'dividendYield' | 'payoutRatio' | 'dpsCagr5Y' | 'dividendStreak'
  | 'promoterHolding' | 'promoterPledge' | 'fiiHolding';

export type Comparison =
  | 'gte' | 'lte' | 'between' | 'is_true' | 'is_false'
  | 'percentile_gte' | 'percentile_lte'
  | 'median_ratio_lte' | 'median_ratio_gte';

export type Basis =
  | 'Fixed threshold'
  | 'Compared with companies in the same sector'
  | 'Compared with every company in the list'
  | 'History check';

export interface Rule {
  id: string;
  indicator: IndicatorId;
  comparison: Comparison;
  value?: number;
  value2?: number;
  /** peer group for percentile and median comparisons */
  scope?: 'sector' | 'universe';
  /** human wording of what the rule wants */
  requirement: string;
  basis: Basis;
  /** one line on why this rule belongs to this preference */
  why: string;
  /** lenders (banks and NBFCs) are structurally different */
  lenderPolicy?: 'skip' | 'substitute';
  substitute?: Rule;
  /** rule needs at least this much listed history to be meaningful */
  requiresHistoryYears?: number;
}

export type CategoryId =
  | 'growth' | 'profitability' | 'stability' | 'balance' | 'cashflow' | 'valuation'
  | 'momentum' | 'performance' | 'dividends' | 'size' | 'liquidity' | 'composite' | 'horizon';

export type IconName =
  | 'sprout' | 'rocket' | 'recovery' | 'pillar' | 'coins'
  | 'shield' | 'wave' | 'swing' | 'open' | 'target'
  | 'tag' | 'scales' | 'premium' | 'compare'
  | 'trendUp' | 'trendStrong' | 'trendDown'
  | 'steady' | 'spark' | 'guard'
  | 'clockShort' | 'clockMid' | 'clockLong'
  | 'bars' | 'trophy' | 'calendar' | 'pulse';

export interface Option {
  id: string;
  categoryId: CategoryId;
  label: string;
  /** one line under the label */
  blurb: string;
  /** how it reads inside a full sentence */
  clause: string;
  /** short form used on chips */
  chip: string;
  /** plain explanation, no jargon */
  summary: string;
  icon: IconName;
  rules: Rule[];
  /** expanded tier: hidden behind "see more" in the picker */
  more?: boolean;
  caveat?: string;
}

export interface Category {
  id: CategoryId;
  label: string;
  icon: IconName;
  question: string;
  panelBlurb: string;
  blurb: string;
  optional: true;
}

export const CATEGORIES: Category[] = [
  { id: 'growth', label: 'Getting bigger', icon: 'bars',
    question: 'Should the company be getting bigger?',
    panelBlurb: 'Companies that sell more and earn more than they used to.',
    blurb: 'Whether it sells and earns more than it used to.', optional: true },
  { id: 'profitability', label: 'Making money', icon: 'coins',
    question: 'How well should it make money?',
    panelBlurb: 'How much the company keeps out of everything it sells.',
    blurb: 'How much it keeps out of what it sells.', optional: true },
  { id: 'stability', label: 'Staying calm', icon: 'shield',
    question: 'How bumpy a ride are you okay with?',
    panelBlurb: 'Companies whose price and profit move less than most.',
    blurb: 'How much the price and the profit jump around.', optional: true },
  { id: 'balance', label: 'Money it owes', icon: 'pillar',
    question: 'How much borrowing is okay?',
    panelBlurb: 'How much the company has borrowed, and whether it can repay it.',
    blurb: 'What it owes and whether it can pay it back.', optional: true },
  { id: 'cashflow', label: 'Real cash', icon: 'wave',
    question: 'Should the profit be real cash?',
    panelBlurb: 'Whether the profit it reports actually turns up as money.',
    blurb: 'Whether its profit arrives as actual money.', optional: true },
  { id: 'valuation', label: 'What it costs', icon: 'tag',
    question: 'How should the price compare with others?',
    panelBlurb: 'What you pay for it next to companies that do the same thing.',
    blurb: 'What you pay, next to companies like it.', optional: true },
  { id: 'momentum', label: 'Recent price', icon: 'pulse',
    question: 'What should the price have been doing?',
    panelBlurb: 'Which way the share price has been heading lately.',
    blurb: 'Which way the price has been moving.', optional: true },
  { id: 'performance', label: 'Past results', icon: 'trophy',
    question: 'What track record are you after?',
    panelBlurb: 'How the share has done over the past year and the past three.',
    blurb: 'How it has done over one year and three.', optional: true },
  { id: 'dividends', label: 'Money paid to you', icon: 'premium',
    question: 'Do you want to be paid along the way?',
    panelBlurb: 'Companies that hand some of their profit back to owners.',
    blurb: 'Whether it hands money back to you.', optional: true },
  { id: 'size', label: 'How big it is', icon: 'scales',
    question: 'How big should the company be?',
    panelBlurb: 'Big, medium or small, by what the whole company is worth.',
    blurb: 'How big the company is.', optional: true },
  { id: 'liquidity', label: 'Easy to trade', icon: 'swing',
    question: 'How easily should it trade?',
    panelBlurb: 'How many of its shares change hands on a normal day.',
    blurb: 'How easy it is to buy or sell.', optional: true },
  { id: 'composite', label: 'Ready-made', icon: 'target',
    question: 'Want several checks in one go?',
    panelBlurb: 'Each of these bundles a few checks into one pick.',
    blurb: 'Bundles of checks in a single pick.', optional: true },
  { id: 'horizon', label: 'How long you’ll wait', icon: 'calendar',
    question: 'How long will you leave the money alone?',
    panelBlurb: 'Roughly how long you plan to hold on for.',
    blurb: 'How long you plan to stay invested.', optional: true },
];

/* ------------------------------------------------------- shared rules */

const leverageStable: Rule = {
  id: 'de-half', indicator: 'debtToEquity', comparison: 'lte', value: 0.5,
  requirement: 'debt no more than half of shareholder capital', basis: 'Fixed threshold',
  why: 'Lower borrowing means fewer fixed obligations to meet when business slows.',
  lenderPolicy: 'substitute',
  substitute: {
    id: 'car-14', indicator: 'capitalAdequacy', comparison: 'gte', value: 14,
    requirement: 'capital adequacy of 14% or more', basis: 'Fixed threshold',
    why: 'Banks and lenders borrow by design, so the capital buffer stands in for debt-to-equity.',
  },
};

const consistency3: Rule = {
  id: 'cons-3', indicator: 'profitConsistency', comparison: 'gte', value: 3,
  requirement: 'profit up in at least 3 of the last 5 years', basis: 'History check',
  why: 'Looks for results that repeat rather than one unusually strong year.',
  requiresHistoryYears: 3,
};

const cashBacked: Rule = {
  id: 'cfo-pat-08', indicator: 'cfoPatRatio', comparison: 'gte', value: 0.8,
  requirement: 'cash from operations at least 0.8x reported profit', basis: 'Fixed threshold',
  why: 'Checks that reported profit is actually arriving as cash.',
};

const noFilter = (id: string, categoryId: CategoryId, label: string, chip: string): Option => ({
  id, categoryId, label, chip, more: true,
  blurb: 'Skip this group — I do not mind.',
  clause: 'can be anything here',
  summary: 'Applies no filter. Useful when you have no view on this area.',
  icon: 'open', rules: [],
});

export const OPTIONS: Option[] = [
  /* ---------------------------------------------------------------- growth */
  { id: 'growth-steady', categoryId: 'growth', label: 'Grows a little every year',
    blurb: 'Sales and profit go up most years.',
    clause: 'grows steadily', chip: 'Grows every year', icon: 'sprout',
    summary: 'Sales and profits have been rising at a moderate pace, year after year.',
    rules: [
      { id: 'rev-8', indicator: 'revenueCagr3Y', comparison: 'gte', value: 8,
        requirement: '8% a year or more over 3 years', basis: 'Fixed threshold',
        why: 'Sales growth shows the business is selling more, not only cutting costs.', requiresHistoryYears: 3 },
      { id: 'pat-8', indicator: 'patCagr3Y', comparison: 'gte', value: 8,
        requirement: '8% a year or more over 3 years', basis: 'Fixed threshold',
        why: 'Profit growth checks that higher sales reach the bottom line.', requiresHistoryYears: 3 },
      consistency3,
    ] },
  { id: 'growth-fast', categoryId: 'growth', label: 'Growing really fast',
    blurb: 'Sales and profit are shooting up.',
    clause: 'is growing fast', chip: 'Growing fast', icon: 'rocket',
    summary: 'Sales and profits have both been rising quickly.',
    caveat: 'Fast growth is often priced in already, and it is harder to sustain than to achieve once.',
    rules: [
      { id: 'rev-15', indicator: 'revenueCagr3Y', comparison: 'gte', value: 15,
        requirement: '15% a year or more over 3 years', basis: 'Fixed threshold',
        why: 'A higher bar than steady growth, so only quicker-growing businesses pass.', requiresHistoryYears: 3 },
      { id: 'pat-15', indicator: 'patCagr3Y', comparison: 'gte', value: 15,
        requirement: '15% a year or more over 3 years', basis: 'Fixed threshold',
        why: 'Keeps the focus on profit, not only sales.', requiresHistoryYears: 3 },
    ] },
  { id: 'growth-sales', categoryId: 'growth', label: 'Selling more than before',
    blurb: 'It sold more this year than last year.',
    clause: 'is growing its sales', chip: 'Selling more', icon: 'bars',
    summary: 'The latest year shows revenue clearly higher than the year before.',
    rules: [
      { id: 'rev-yoy-10', indicator: 'revenueYoY', comparison: 'gte', value: 10,
        requirement: 'sales up 10% or more in the latest year', basis: 'Fixed threshold',
        why: 'A recent read on demand rather than a three-year average.' },
    ] },
  { id: 'growth-profit', categoryId: 'growth', label: 'Earning more than before',
    blurb: 'It kept more profit than last year.',
    clause: 'is growing its profit', chip: 'Earning more', icon: 'trendUp',
    summary: 'Profit in the latest year is meaningfully above the year before.',
    rules: [
      { id: 'pat-yoy-12', indicator: 'patYoY', comparison: 'gte', value: 12,
        requirement: 'profit up 12% or more in the latest year', basis: 'Fixed threshold',
        why: 'Profit is what shareholders ultimately own a share of.' },
    ] },
  { id: 'growth-consistent', categoryId: 'growth', label: 'Grows year after year',
    blurb: 'Almost every year is better than the one before.',
    clause: 'grows consistently', chip: 'Grows every year', icon: 'steady',
    summary: 'Sales and profit have risen in most of the last five years.',
    rules: [
      { id: 'rev-years-4', indicator: 'revenueUpYears', comparison: 'gte', value: 4,
        requirement: 'sales up in at least 4 of the last 5 years', basis: 'History check',
        why: 'Consistency across years matters more than one strong year.', requiresHistoryYears: 3 },
      consistency3,
    ] },
  { id: 'growth-recovery', categoryId: 'growth', label: 'Getting better after a bad patch', more: true,
    blurb: 'It had a slow few years and is picking up.',
    clause: 'is recovering after a slow patch', chip: 'Getting better', icon: 'recovery',
    summary: 'Growth has been muted, but margins and the recent trend are turning up.',
    caveat: 'A recovery can stall. This screens for a situation, not a forecast.',
    rules: [
      { id: 'pat-muted', indicator: 'patCagr3Y', comparison: 'lte', value: 10,
        requirement: 'profit growth under 10% a year over 3 years', basis: 'Fixed threshold',
        why: 'Defines the slow patch the company is coming out of.', requiresHistoryYears: 3 },
      { id: 'margin-up', indicator: 'marginTrendBps', comparison: 'gte', value: 0,
        requirement: 'margins no longer falling', basis: 'Fixed threshold',
        why: 'Margins usually turn before profit does.' },
      { id: 'ret3m-up', indicator: 'return3M', comparison: 'gte', value: 0,
        requirement: 'price up over the last three months', basis: 'Fixed threshold',
        why: 'A simple check that the recent trend has steadied.' },
    ] },
  noFilter('growth-any', 'growth', "Growth doesn't matter to me", 'Any growth'),

  /* --------------------------------------------------------- profitability */
  { id: 'profit-margins', categoryId: 'profitability', label: 'Keeps a lot from each sale',
    blurb: 'Less of its money goes on costs than its rivals.',
    clause: 'earns high margins', chip: 'Keeps a lot per sale', icon: 'coins',
    summary: 'Operating margin sits in the top slice of its sector.',
    rules: [
      { id: 'ebitda-top30', indicator: 'ebitdaMargin', comparison: 'percentile_gte', value: 70, scope: 'sector',
        requirement: 'operating margin in the top 30% of the sector',
        basis: 'Compared with companies in the same sector',
        why: 'Margins differ hugely by industry, so this ranks against peers instead of a fixed number.' },
    ] },
  { id: 'profit-rising-margins', categoryId: 'profitability', label: 'Keeping more than it used to',
    blurb: 'It gets to keep a bigger slice than before.',
    clause: 'has improving margins', chip: 'Keeping more', icon: 'trendUp',
    summary: 'The operating margin is higher than it was, by a clear step.',
    rules: [
      { id: 'margin-100bps', indicator: 'marginTrendBps', comparison: 'gte', value: 100,
        requirement: 'margin up by at least 1 percentage point', basis: 'Fixed threshold',
        why: 'A visible improvement rather than rounding noise.' },
    ] },
  { id: 'profit-roe', categoryId: 'profitability', label: 'Makes good money from what it has',
    blurb: 'It turns the owners’ money into decent profit.',
    clause: 'earns a strong return on equity', chip: 'Good earner', icon: 'scales',
    summary: 'Return on equity is high in absolute terms and against peers.',
    caveat: 'Heavy borrowing can lift return on equity without the business improving.',
    rules: [
      { id: 'roe-15', indicator: 'roe', comparison: 'gte', value: 15,
        requirement: 'return on equity of 15% or more', basis: 'Fixed threshold',
        why: 'A common bar for a business that earns well on its own capital.' },
      { id: 'roe-peer', indicator: 'roe', comparison: 'percentile_gte', value: 50, scope: 'sector',
        requirement: 'above the sector median', basis: 'Compared with companies in the same sector',
        why: 'Keeps the check honest in sectors where high returns are normal.' },
    ] },
  { id: 'profit-roce', categoryId: 'profitability', label: 'Uses its money wisely',
    blurb: 'Everything it spends is put to good use.',
    clause: 'uses its capital efficiently', chip: 'Uses money well', icon: 'target',
    summary: 'Return on capital employed is high, counting borrowed money too.',
    rules: [
      { id: 'roce-15', indicator: 'roce', comparison: 'gte', value: 15,
        requirement: 'return on capital of 15% or more', basis: 'Fixed threshold',
        why: 'A wider measure than return on equity, since it counts debt-funded capital.',
        lenderPolicy: 'skip' },
    ] },
  { id: 'profit-quality', categoryId: 'profitability', label: 'Its profit is real cash',
    blurb: 'The profit it reports actually shows up as money.',
    clause: 'reports profit that is backed by cash', chip: 'Real cash profit', icon: 'guard',
    summary: 'Cash from operations keeps pace with reported profit.',
    rules: [cashBacked] },
  { id: 'profit-netmargin', categoryId: 'profitability', label: 'Keeps a big slice at the end', more: true,
    blurb: 'After every bill is paid, a lot is left.',
    clause: 'has a high net margin', chip: 'Big final slice', icon: 'coins',
    summary: 'Net margin sits in the top slice of its sector.',
    caveat: 'Net margin can be distorted by one-off items.',
    rules: [
      { id: 'netmargin-top30', indicator: 'netMargin', comparison: 'percentile_gte', value: 70, scope: 'sector',
        requirement: 'net margin in the top 30% of the sector',
        basis: 'Compared with companies in the same sector',
        why: 'Ranks the bottom-line margin against businesses with similar economics.' },
    ] },
  noFilter('profit-any', 'profitability', "Profit doesn't matter to me", 'Any profit'),

  /* ------------------------------------------------------------- stability */
  { id: 'stability-stable', categoryId: 'stability', label: 'Calm and steady',
    blurb: 'The price and the profit both stay fairly still.',
    clause: 'stays relatively stable', chip: 'Calm and steady', icon: 'shield',
    summary: 'Price swings sit in the calmer part of the list and profit has been consistent.',
    caveat: 'Shares that moved less in the past can still move sharply in future. Stability is not safety.',
    rules: [
      { id: 'vol-bottom40', indicator: 'volatility', comparison: 'percentile_lte', value: 40, scope: 'universe',
        requirement: 'price swings in the calmest 40% of the list',
        basis: 'Compared with every company in the list',
        why: 'Ranks movement against the other companies here instead of a fixed number.' },
      consistency3,
    ] },
  { id: 'stability-low-vol', categoryId: 'stability', label: 'Price jumps around less',
    blurb: 'Its price moves less than most of its rivals.',
    clause: 'moves less than its peers', chip: 'Price stays still', icon: 'wave',
    summary: 'Yearly price swings are in the bottom 30% of the sector.',
    rules: [
      { id: 'vol-bottom30', indicator: 'volatility', comparison: 'percentile_lte', value: 30, scope: 'sector',
        requirement: 'price swings in the calmest 30% of the sector',
        basis: 'Compared with companies in the same sector',
        why: 'Volatility is best read against similar businesses.' },
    ] },
  { id: 'stability-low-beta', categoryId: 'stability', label: 'Does its own thing',
    blurb: 'When the whole market drops, it drops less.',
    clause: 'is less sensitive to the market', chip: 'Goes its own way', icon: 'swing',
    summary: 'Historically the share has moved less than the wider market.',
    caveat: 'Beta is measured from the past and shifts over time.',
    rules: [
      { id: 'beta-09', indicator: 'beta', comparison: 'lte', value: 0.9,
        requirement: 'beta of 0.9 or below', basis: 'Fixed threshold',
        why: 'Below 1 means it has moved less than the market on average.' },
    ] },
  { id: 'stability-earnings', categoryId: 'stability', label: 'Profit stays steady',
    blurb: 'Its profit goes up most years instead of bouncing.',
    clause: 'earns steadily year to year', chip: 'Steady profit', icon: 'steady',
    summary: 'Profit has risen in at least four of the last five years.',
    rules: [
      { id: 'cons-4', indicator: 'profitConsistency', comparison: 'gte', value: 4,
        requirement: 'profit up in at least 4 of the last 5 years', basis: 'History check',
        why: 'The simplest measure of earnings that do not swing about.', requiresHistoryYears: 3 },
    ] },
  { id: 'stability-drawdown', categoryId: 'stability', label: 'Never crashed badly',
    blurb: 'Even at its worst it did not fall very far.',
    clause: 'has avoided a deep fall', chip: 'No big crash', icon: 'guard',
    summary: 'The worst peak-to-trough fall in the last year stayed comparatively mild.',
    caveat: 'A shallow past drawdown does not predict the next one.',
    rules: [
      { id: 'dd-top40', indicator: 'maxDrawdown1Y', comparison: 'percentile_gte', value: 60, scope: 'universe',
        requirement: 'a shallower worst fall than most of the list',
        basis: 'Compared with every company in the list',
        why: 'Returns alone hide how uncomfortable the journey was.' },
    ] },
  noFilter('stability-any', 'stability', "Steadiness doesn't matter to me", 'Any steadiness'),

  /* ---------------------------------------------------------- balance sheet */
  { id: 'balance-low-debt', categoryId: 'balance', label: 'Hardly borrows anything',
    blurb: 'It owes very little to anyone.',
    clause: 'carries little debt', chip: 'Barely borrows', icon: 'shield',
    summary: 'Debt is modest against shareholder capital; for lenders, the capital buffer is checked instead.',
    rules: [leverageStable] },
  { id: 'balance-manageable', categoryId: 'balance', label: 'Borrows only what it can repay',
    blurb: 'It has debt, but nothing it cannot handle.',
    clause: 'keeps its debt serviceable', chip: 'Can repay what it owes', icon: 'pillar',
    summary: 'Borrowing is within a few years of earnings and comfortably covered by profit.',
    rules: [
      { id: 'nde-3', indicator: 'netDebtEbitda', comparison: 'lte', value: 3,
        requirement: 'net debt no more than 3x operating profit', basis: 'Fixed threshold',
        why: 'A standard measure of how heavy the borrowing is relative to earnings.',
        lenderPolicy: 'skip' },
      { id: 'cover-3', indicator: 'interestCoverage', comparison: 'gte', value: 3,
        requirement: 'profit covers interest at least 3 times over', basis: 'Fixed threshold',
        why: 'Shows the company earns enough to service what it has borrowed.',
        lenderPolicy: 'skip' },
    ] },
  { id: 'balance-net-cash', categoryId: 'balance', label: 'Has more cash than debt',
    blurb: 'Its piggy bank is bigger than what it owes.',
    clause: 'holds more cash than debt', chip: 'More cash than debt', icon: 'coins',
    summary: 'After netting cash against borrowings, the company owes nothing.',
    caveat: 'Cash can be earmarked for a purpose, or needed to run the business.',
    rules: [
      { id: 'nde-0', indicator: 'netDebtEbitda', comparison: 'lte', value: 0,
        requirement: 'net debt at or below zero', basis: 'Fixed threshold',
        why: 'Net debt below zero means cash is larger than borrowings.',
        lenderPolicy: 'skip' },
    ] },
  { id: 'balance-coverage', categoryId: 'balance', label: 'Pays its interest easily',
    blurb: 'Its profit covers the interest many times over.',
    clause: 'covers its interest comfortably', chip: 'Pays interest easily', icon: 'guard',
    summary: 'Operating profit is several times the interest bill.',
    rules: [
      { id: 'cover-4', indicator: 'interestCoverage', comparison: 'gte', value: 4,
        requirement: 'profit covers interest at least 4 times over', basis: 'Fixed threshold',
        why: 'A wide margin leaves room if profits dip for a year.',
        lenderPolicy: 'skip' },
    ] },
  { id: 'balance-liquidity', categoryId: 'balance', label: 'Can pay this year’s bills', more: true,
    blurb: 'It has enough to cover what is due soon.',
    clause: 'can cover its short-term bills', chip: 'Can pay the bills', icon: 'scales',
    summary: 'Current assets are comfortably larger than current liabilities.',
    caveat: 'Some retail and subscription models run on negative working capital by design.',
    rules: [
      { id: 'current-15', indicator: 'currentRatio', comparison: 'gte', value: 1.5,
        requirement: 'current ratio of 1.5 or more', basis: 'Fixed threshold',
        why: 'A rough check that near-term obligations are covered.',
        lenderPolicy: 'skip' },
    ] },
  noFilter('balance-any', 'balance', "Borrowing doesn't matter to me", 'Any borrowing'),

  /* -------------------------------------------------------------- cash flow */
  { id: 'cash-positive', categoryId: 'cashflow', label: 'Brings in real money',
    blurb: 'The day-to-day business actually collects cash.',
    clause: 'brings in cash from operations', chip: 'Brings in money', icon: 'coins',
    summary: 'The day-to-day business generated cash in the latest year.',
    caveat: 'One year alone is not enough to judge cash quality.',
    rules: [
      { id: 'cfo-pos', indicator: 'cfoPositive', comparison: 'is_true',
        requirement: 'cash from operations above zero', basis: 'Fixed threshold',
        why: 'Profit is an accounting figure; cash is what actually arrives.' },
    ] },
  { id: 'cash-strong', categoryId: 'cashflow', label: 'Collects more cash than it reports',
    blurb: 'More money comes in than the profit figure suggests.',
    clause: 'turns profit into cash', chip: 'Lots of cash in', icon: 'wave',
    summary: 'Cash from operations is at least as large as reported profit.',
    rules: [
      { id: 'cfo-pat-1', indicator: 'cfoPatRatio', comparison: 'gte', value: 1,
        requirement: 'cash from operations at least 1x profit', basis: 'Fixed threshold',
        why: 'Converting more than the reported profit into cash is a good quality sign.' },
    ] },
  { id: 'cash-backed', categoryId: 'cashflow', label: 'Its profit is real cash',
    blurb: 'Most of its profit arrives as actual money.',
    clause: 'reports cash-backed profit', chip: 'Real cash profit', icon: 'guard',
    summary: 'Most of the reported profit shows up as cash from operations.',
    rules: [cashBacked] },
  { id: 'cash-fcf', categoryId: 'cashflow', label: 'Has money left over',
    blurb: 'After spending on itself, cash is still left.',
    clause: 'has cash left after investing', chip: 'Money left over', icon: 'premium',
    summary: 'After spending on the business, cash remains.',
    caveat: 'Fast-growing companies often run negative free cash while investing heavily.',
    rules: [
      { id: 'fcf-pos', indicator: 'fcfPositive', comparison: 'is_true',
        requirement: 'free cash flow above zero', basis: 'Fixed threshold',
        why: 'Free cash is what the business has left once it has paid for its own growth.' },
    ] },
  { id: 'cash-low-capex', categoryId: 'cashflow', label: 'Does not need to spend much', more: true,
    blurb: 'It can keep going without buying lots of new things.',
    clause: 'needs little reinvestment', chip: 'Spends little on itself', icon: 'open',
    summary: 'Capital spending takes a smaller share of revenue than most of the sector.',
    caveat: 'Low capex is not automatically better; it can mean underinvestment.',
    rules: [
      { id: 'capex-bottom40', indicator: 'capexRevenue', comparison: 'percentile_lte', value: 40, scope: 'sector',
        requirement: 'capex share of revenue in the lowest 40% of the sector',
        basis: 'Compared with companies in the same sector',
        why: 'Capital intensity is a sector trait, so this ranks against peers.' },
    ] },
  noFilter('cash-any', 'cashflow', "Cash doesn't matter to me", 'Any cash'),

  /* ------------------------------------------------------------- valuation */
  { id: 'valuation-reasonable', categoryId: 'valuation', label: 'Priced about right',
    blurb: 'It costs about the same as companies like it.',
    clause: 'looks reasonably valued next to its peers', chip: 'Fairly priced', icon: 'scales',
    summary: 'The P/E is near the sector median, and the business earns a decent return.',
    caveat: 'There is no universal number that means fair value. This is a peer comparison, nothing more.',
    rules: [
      { id: 'pe-120', indicator: 'pe', comparison: 'median_ratio_lte', value: 1.2, scope: 'sector',
        requirement: 'P/E within about 1.2x the sector median',
        basis: 'Compared with companies in the same sector',
        why: 'The same P/E means different things in different sectors.' },
      { id: 'roe-10', indicator: 'roe', comparison: 'gte', value: 10,
        requirement: 'return on equity of 10% or more', basis: 'Fixed threshold',
        why: 'A profitability floor, so a low price alone is not read as good value.' },
    ] },
  { id: 'valuation-discount', categoryId: 'valuation', label: 'Cheaper than companies like it',
    blurb: 'You pay less for it than for its rivals.',
    clause: 'trades at a discount to its peers', chip: 'Cheaper than rivals', icon: 'tag',
    summary: 'The P/E sits in the cheapest 30% of the sector.',
    caveat: 'A discount to peers is sometimes deserved. It can reflect real problems.',
    rules: [
      { id: 'pe-bottom30', indicator: 'pe', comparison: 'percentile_lte', value: 30, scope: 'sector',
        requirement: 'P/E in the cheapest 30% of the sector',
        basis: 'Compared with companies in the same sector',
        why: 'Ranks valuation inside the peer group rather than against a universal cut-off.' },
    ] },
  { id: 'valuation-low-pb', categoryId: 'valuation', label: 'Cheap for everything it owns',
    blurb: 'Its price is low next to the stuff it actually owns.',
    clause: 'looks cheap against what it owns', chip: 'Cheap for what it owns', icon: 'compare',
    summary: 'Price-to-book sits in the lowest 30% of the sector.',
    caveat: 'Book value misses most of what matters for brand-led or software businesses.',
    rules: [
      { id: 'pb-bottom30', indicator: 'pb', comparison: 'percentile_lte', value: 30, scope: 'sector',
        requirement: 'price-to-book in the lowest 30% of the sector',
        basis: 'Compared with companies in the same sector',
        why: 'Most useful for banks and asset-heavy businesses.' },
    ] },
  { id: 'valuation-growth-value', categoryId: 'valuation', label: 'Growing fast but not overpriced',
    blurb: 'It grows quickly and still is not expensive.',
    clause: 'offers growth without an extreme price', chip: 'Growth without the price', icon: 'premium',
    summary: 'Profit growth is strong and the price is in proportion to it.',
    caveat: 'Comparing price with growth assumes the growth continues, which is not guaranteed.',
    rules: [
      { id: 'pat-12', indicator: 'patCagr3Y', comparison: 'gte', value: 12,
        requirement: 'profit growth of 12% a year or more', basis: 'Fixed threshold',
        why: 'The premium only makes sense if growth is genuinely strong.', requiresHistoryYears: 3 },
      { id: 'peg-15', indicator: 'peg', comparison: 'lte', value: 1.5,
        requirement: 'P/E no more than 1.5x the growth rate', basis: 'Fixed threshold',
        why: 'Keeps price and growth in some proportion.' },
    ] },
  { id: 'valuation-earnings-yield', categoryId: 'valuation', label: 'Lots of profit for the price', more: true,
    blurb: 'Each rupee you pay buys a big slice of profit.',
    clause: 'offers a high earnings yield', chip: 'Lots of profit per rupee', icon: 'coins',
    summary: 'Earnings per rupee of price sit in the top 30% of the sector.',
    rules: [
      { id: 'ey-top30', indicator: 'earningsYield', comparison: 'percentile_gte', value: 70, scope: 'sector',
        requirement: 'earnings yield in the top 30% of the sector',
        basis: 'Compared with companies in the same sector',
        why: 'The inverse of P/E, read against peers.' },
    ] },
  noFilter('valuation-any', 'valuation', "Price doesn't matter to me", 'Any price'),

  /* -------------------------------------------------------------- momentum */
  { id: 'momentum-positive', categoryId: 'momentum', label: 'Price is going up',
    blurb: 'The price has been climbing lately.',
    clause: 'has positive momentum', chip: 'Price going up', icon: 'trendUp',
    summary: 'The price is up over three months and sits above its 50-day average.',
    caveat: 'Momentum describes the recent past. It does not mean the move continues.',
    rules: [
      { id: 'ret3m-0', indicator: 'return3M', comparison: 'gte', value: 0,
        requirement: 'price up over three months', basis: 'Fixed threshold',
        why: 'A short window that reflects the current trend.' },
      { id: 'above-50', indicator: 'priceVs50DMA', comparison: 'gte', value: 0,
        requirement: 'price at or above its 50-day average', basis: 'Fixed threshold',
        why: 'A common way to describe a trend that has turned up.' },
    ] },
  { id: 'momentum-improving', categoryId: 'momentum', label: 'Picking up speed',
    blurb: 'The price has turned upwards and is gaining pace.',
    clause: 'has improving momentum', chip: 'Speeding up', icon: 'spark',
    summary: 'The price is above its 50-day average with momentum strengthening but not stretched.',
    caveat: 'Momentum signals look backwards and can reverse quickly.',
    rules: [
      { id: 'above-50b', indicator: 'priceVs50DMA', comparison: 'gte', value: 0,
        requirement: 'price at or above its 50-day average', basis: 'Fixed threshold',
        why: 'The short-term trend has turned up.' },
      { id: 'rsi-band', indicator: 'rsi', comparison: 'between', value: 45, value2: 72,
        requirement: 'RSI between 45 and 72', basis: 'Fixed threshold',
        why: 'Picks up strengthening momentum while leaving out the most stretched readings.' },
    ] },
  { id: 'momentum-strong', categoryId: 'momentum', label: 'On a long winning run',
    blurb: 'The price has been climbing for months.',
    clause: 'is in a strong trend', chip: 'On a long run', icon: 'trendStrong',
    summary: 'The price is above both moving averages and the 50-day average is still rising.',
    caveat: 'A strong trend can end without warning.',
    rules: [
      { id: 'above-200', indicator: 'priceVs200DMA', comparison: 'gte', value: 5,
        requirement: 'price at least 5% above its 200-day average', basis: 'Fixed threshold',
        why: 'Describes a trend that has been running for months, not days.' },
      { id: 'slope-up', indicator: 'ma50Slope', comparison: 'gte', value: 0,
        requirement: 'the 50-day average still rising', basis: 'Fixed threshold',
        why: 'A rising average confirms the trend is intact.' },
    ] },
  { id: 'momentum-strength', categoryId: 'momentum', label: 'Beating companies like it',
    blurb: 'It has done better than its rivals lately.',
    clause: 'has outpaced its sector lately', chip: 'Beating its rivals', icon: 'trendUp',
    summary: 'The three-month return is in the top 30% of the sector.',
    rules: [
      { id: 'ret3m-top30', indicator: 'return3M', comparison: 'percentile_gte', value: 70, scope: 'sector',
        requirement: 'three-month return in the top 30% of the sector',
        basis: 'Compared with companies in the same sector',
        why: 'Relative strength is read against peers, not in isolation.' },
    ] },
  { id: 'momentum-near-highs', categoryId: 'momentum', label: 'Close to its best-ever price',
    blurb: 'It is trading near the highest price of the year.',
    clause: 'trades near its 52-week high', chip: 'Near its best price', icon: 'trendStrong',
    summary: 'The price sits within 10% of its highest point in the last year.',
    caveat: 'Being near a high is neither good nor bad on its own.',
    rules: [
      { id: 'dist-52w', indicator: 'distance52wHigh', comparison: 'gte', value: -10,
        requirement: 'within 10% of the 52-week high', basis: 'Fixed threshold',
        why: 'A simple description of where the price sits in its own range.' },
    ] },
  { id: 'momentum-oversold', categoryId: 'momentum', label: 'Has dropped a lot lately', more: true,
    blurb: 'The price has fallen sharply in a short time.',
    clause: 'sits in the oversold range', chip: 'Dropped a lot', icon: 'trendDown',
    summary: 'RSI is low enough to be called oversold by convention.',
    caveat: 'Oversold does not mean due for a rebound. Shares can stay oversold through a long decline.',
    rules: [
      { id: 'rsi-35', indicator: 'rsi', comparison: 'lte', value: 35,
        requirement: 'RSI of 35 or below', basis: 'Fixed threshold',
        why: 'RSI under 30 is conventionally called oversold; 35 widens it slightly.' },
    ] },
  noFilter('momentum-any', 'momentum', "Price moves don't matter to me", 'Any price move'),

  /* ----------------------------------------------------------- performance */
  { id: 'performance-strong', categoryId: 'performance', label: 'Did really well last year',
    blurb: 'It beat most other companies over the past year.',
    clause: 'has returned strongly over the past year', chip: 'Great last year', icon: 'spark',
    summary: 'The one-year return is in the top 30% of the list.',
    caveat: 'Past returns are history. They do not tell you what happens next.',
    rules: [
      { id: 'ret1y-top30', indicator: 'return1Y', comparison: 'percentile_gte', value: 70, scope: 'universe',
        requirement: 'one-year return in the top 30% of the list',
        basis: 'Compared with every company in the list',
        why: 'Ranked rather than fixed, so it adapts to the market backdrop.' },
    ] },
  { id: 'performance-steady', categoryId: 'performance', label: 'Does well year after year',
    blurb: 'It has made money over one year and over three.',
    clause: 'has returned steadily across years', chip: 'Good every year', icon: 'steady',
    summary: 'Positive over the past year and compounding over three.',
    caveat: 'Past returns do not guarantee future results.',
    rules: [
      { id: 'ret1y-0', indicator: 'return1Y', comparison: 'gte', value: 0,
        requirement: 'up over the past year', basis: 'History check',
        why: 'A floor rather than a target.' },
      { id: 'ret3y-8', indicator: 'return3Y', comparison: 'gte', value: 8,
        requirement: '8% a year or more over three years', basis: 'History check',
        why: 'A multi-year window so one strong year does not carry the result.', requiresHistoryYears: 3 },
    ] },
  { id: 'performance-positive', categoryId: 'performance', label: 'Went up over the year',
    blurb: 'It is worth more than it was a year ago.',
    clause: 'is up over the last year', chip: 'Up this year', icon: 'guard',
    summary: 'A simple filter: the one-year return is above zero.',
    rules: [
      { id: 'ret1y-pos', indicator: 'return1Y', comparison: 'gte', value: 0,
        requirement: 'one-year return above zero', basis: 'History check',
        why: 'The plainest description of the past year.' },
    ] },
  { id: 'performance-3y', categoryId: 'performance', label: 'Great over three years',
    blurb: 'It is one of the best over the last three years.',
    clause: 'has compounded well over three years', chip: 'Great over 3 years', icon: 'trophy',
    summary: 'The three-year annualised return is in the top 30% of the list.',
    rules: [
      { id: 'ret3y-top30', indicator: 'return3Y', comparison: 'percentile_gte', value: 70, scope: 'universe',
        requirement: 'three-year return in the top 30% of the list',
        basis: 'Compared with every company in the list',
        why: 'Needs enough listed history, so newer listings cannot pass.', requiresHistoryYears: 3 },
    ] },
  { id: 'performance-recovery', categoryId: 'performance', label: 'Bouncing back', more: true,
    blurb: 'It had a weak few years and is climbing again.',
    clause: 'is recovering after a weak stretch', chip: 'Bouncing back', icon: 'recovery',
    summary: 'A modest three-year record, with the recent months turning up.',
    caveat: 'A recovery in progress can fade.',
    rules: [
      { id: 'ret3y-weak', indicator: 'return3Y', comparison: 'lte', value: 8,
        requirement: 'under 8% a year over three years', basis: 'History check',
        why: 'Defines the weak stretch it is coming out of.', requiresHistoryYears: 3 },
      { id: 'ret3m-pos', indicator: 'return3M', comparison: 'gte', value: 2,
        requirement: 'up at least 2% over three months', basis: 'Fixed threshold',
        why: 'Where a turn would show up first.' },
    ] },
  noFilter('performance-any', 'performance', "Past results don't matter to me", 'Any past result'),

  /* ------------------------------------------------------------- dividends */
  { id: 'dividend-yield', categoryId: 'dividends', label: 'Pays you a lot',
    blurb: 'It hands more money back to owners than its rivals.',
    clause: 'pays a high dividend', chip: 'Pays a lot', icon: 'premium',
    summary: 'Dividend yield is in the top 30% of the sector.',
    caveat: 'A very high yield can be a sign of distress, or of a price that has fallen.',
    rules: [
      { id: 'dy-top30', indicator: 'dividendYield', comparison: 'percentile_gte', value: 70, scope: 'sector',
        requirement: 'dividend yield in the top 30% of the sector',
        basis: 'Compared with companies in the same sector',
        why: 'Payout norms differ by sector, so yield is ranked against peers.' },
    ] },
  { id: 'dividend-steady', categoryId: 'dividends', label: 'Pays you every single year',
    blurb: 'It has paid out five years in a row or more.',
    clause: 'pays dividends year after year', chip: 'Pays every year', icon: 'steady',
    summary: 'The company has paid a dividend for at least five years in a row.',
    caveat: 'A long streak is no promise that the next dividend arrives.',
    rules: [
      { id: 'streak-5', indicator: 'dividendStreak', comparison: 'gte', value: 5,
        requirement: 'dividends paid five years in a row', basis: 'History check',
        why: 'A record of paying through different conditions.' },
    ] },
  { id: 'dividend-growing', categoryId: 'dividends', label: 'Pays a bit more each year',
    blurb: 'The amount it hands back keeps going up.',
    clause: 'keeps raising its dividend', chip: 'Pays more each year', icon: 'trendUp',
    summary: 'Dividend per share has grown over the last five years.',
    rules: [
      { id: 'dps-5', indicator: 'dpsCagr5Y', comparison: 'gte', value: 5,
        requirement: 'dividend per share up 5% a year over five years', basis: 'History check',
        why: 'Rising payouts usually track rising earnings.', requiresHistoryYears: 5 },
    ] },
  { id: 'dividend-safe', categoryId: 'dividends', label: 'Pays only what it can afford',
    blurb: 'It hands back money without stretching itself.',
    clause: 'pays a dividend it can afford', chip: 'Pays what it can afford', icon: 'guard',
    summary: 'The dividend takes a manageable share of profit, not most of it.',
    rules: [
      { id: 'payout-band', indicator: 'payoutRatio', comparison: 'between', value: 20, value2: 70,
        requirement: 'payout between 20% and 70% of earnings', basis: 'Fixed threshold',
        why: 'Enough to be a real dividend, not so much that a weak year threatens it.' },
    ] },
  noFilter('dividend-any', 'dividends', "Payouts don't matter to me", 'Any payout'),

  /* ------------------------------------------------------------------ size */
  { id: 'size-large', categoryId: 'size', label: 'A really big company',
    blurb: 'One of the biggest companies on the list.',
    clause: 'is a large company', chip: 'Really big', icon: 'pillar',
    summary: 'Market value of ₹80,000 crore or more in this demo universe.',
    caveat: 'Size is not safety. Large companies fall too.',
    rules: [
      { id: 'mcap-large', indicator: 'marketCap', comparison: 'gte', value: 80000,
        requirement: 'company value of ₹80,000 crore or more', basis: 'Fixed threshold',
        why: 'The usual way to describe company size.' },
    ] },
  { id: 'size-mid', categoryId: 'size', label: 'A medium-sized company',
    blurb: 'Bigger than most, smaller than the giants.',
    clause: 'is a mid-sized company', chip: 'Medium-sized', icon: 'scales',
    summary: 'Market value between ₹20,000 and ₹80,000 crore in this demo universe.',
    rules: [
      { id: 'mcap-mid', indicator: 'marketCap', comparison: 'between', value: 20000, value2: 80000,
        requirement: 'company value between ₹20,000 and ₹80,000 crore', basis: 'Fixed threshold',
        why: 'The middle bucket by market value.' },
    ] },
  { id: 'size-small', categoryId: 'size', label: 'A small company',
    blurb: 'One of the smaller companies on the list.',
    clause: 'is a smaller company', chip: 'Small', icon: 'sprout',
    summary: 'Market value below ₹20,000 crore in this demo universe.',
    caveat: 'Smaller companies usually trade less easily and move more.',
    rules: [
      { id: 'mcap-small', indicator: 'marketCap', comparison: 'lte', value: 20000,
        requirement: 'company value below ₹20,000 crore', basis: 'Fixed threshold',
        why: 'The smaller end of the list.' },
    ] },
  noFilter('size-any', 'size', "Size doesn't matter to me", 'Any size'),

  /* ------------------------------------------------------------- liquidity */
  { id: 'liquidity-high', categoryId: 'liquidity', label: 'Very easy to buy and sell',
    blurb: 'Huge numbers of its shares change hands daily.',
    clause: 'trades easily every day', chip: 'Easy to buy and sell', icon: 'swing',
    summary: 'A large value of shares changes hands on a normal day.',
    rules: [
      { id: 'adv-60', indicator: 'avgDailyValue', comparison: 'gte', value: 60,
        requirement: '₹60 crore or more traded on an average day', basis: 'Fixed threshold',
        why: 'Heavy trading means orders fill near the price you see.' },
    ] },
  { id: 'liquidity-active', categoryId: 'liquidity', label: 'Easy enough to buy and sell',
    blurb: 'Enough shares are traded for you to get in and out.',
    clause: 'trades actively enough', chip: 'Traded every day', icon: 'pulse',
    summary: 'Daily traded value is comfortable for ordinary order sizes.',
    caveat: 'Trading activity can dry up exactly when you most want to sell.',
    rules: [
      { id: 'adv-20', indicator: 'avgDailyValue', comparison: 'gte', value: 20,
        requirement: '₹20 crore or more traded on an average day', basis: 'Fixed threshold',
        why: 'A lighter liquidity floor than the high-liquidity tag.' },
    ] },
  { id: 'liquidity-float', categoryId: 'liquidity', label: 'Lots of shares to go around', more: true,
    blurb: 'A big share of the company is open to everyone.',
    clause: 'has a large public float', chip: 'Plenty of shares', icon: 'open',
    summary: 'A larger share of the company is available to public investors.',
    rules: [
      { id: 'float-50', indicator: 'freeFloatPct', comparison: 'gte', value: 50,
        requirement: 'free float of 50% or more', basis: 'Fixed threshold',
        why: 'A bigger float usually means steadier trading.' },
    ] },
  noFilter('liquidity-any', 'liquidity', "Buying and selling doesn't matter", 'Any trading'),

  /* ------------------------------------------------------------- composite */
  { id: 'composite-quality', categoryId: 'composite', label: 'Good at pretty much everything',
    blurb: 'It earns well, holds little debt and makes real cash.',
    clause: 'is a quality business', chip: 'Good all round', icon: 'target',
    summary: 'Combines returns on capital, cash conversion, consistency and modest debt in one tag.',
    caveat: 'These four checks are one definition of quality, not the only one.',
    rules: [
      { id: 'q-roce', indicator: 'roce', comparison: 'gte', value: 14,
        requirement: 'return on capital of 14% or more', basis: 'Fixed threshold',
        why: 'The business earns well on everything invested in it.', lenderPolicy: 'skip' },
      { id: 'q-debt', indicator: 'debtToEquity', comparison: 'lte', value: 0.6,
        requirement: 'debt no more than 0.6x shareholder capital', basis: 'Fixed threshold',
        why: 'Quality is easier to sustain without heavy borrowing.',
        lenderPolicy: 'substitute',
        substitute: {
          id: 'q-car', indicator: 'capitalAdequacy', comparison: 'gte', value: 14,
          requirement: 'capital adequacy of 14% or more', basis: 'Fixed threshold',
          why: 'The lender version of the same check.' } },
      cashBacked,
      consistency3,
    ] },
  { id: 'composite-value-quality', categoryId: 'composite', label: 'Cheap but still healthy',
    blurb: 'It costs less than its rivals and is not in trouble.',
    clause: 'is cheap without being broken', chip: 'Cheap and healthy', icon: 'compare',
    summary: 'Below the sector median on price, while still earning a decent return and generating cash.',
    caveat: 'This is the classic value-trap guardrail, not a promise that the discount closes.',
    rules: [
      { id: 'vq-pe', indicator: 'pe', comparison: 'percentile_lte', value: 50, scope: 'sector',
        requirement: 'P/E in the cheaper half of the sector',
        basis: 'Compared with companies in the same sector',
        why: 'Starts from a genuine discount to peers.' },
      { id: 'vq-roe', indicator: 'roe', comparison: 'gte', value: 12,
        requirement: 'return on equity of 12% or more', basis: 'Fixed threshold',
        why: 'Separates a low price from a business that is not earning.' },
      cashBacked,
    ] },
  { id: 'composite-growth-quality', categoryId: 'composite', label: 'Grows fast and earns well',
    blurb: 'It is growing quickly and making real money doing it.',
    clause: 'grows with quality behind it', chip: 'Grows and earns', icon: 'rocket',
    summary: 'Strong profit growth, healthy return on capital and cash that keeps pace.',
    rules: [
      { id: 'gq-pat', indicator: 'patCagr3Y', comparison: 'gte', value: 12,
        requirement: 'profit growth of 12% a year or more', basis: 'Fixed threshold',
        why: 'The growth half of the tag.', requiresHistoryYears: 3 },
      { id: 'gq-roce', indicator: 'roce', comparison: 'gte', value: 12,
        requirement: 'return on capital of 12% or more', basis: 'Fixed threshold',
        why: 'Growth that earns its cost of capital is worth more than growth alone.',
        lenderPolicy: 'skip' },
      cashBacked,
    ] },
  { id: 'composite-stable-growth', categoryId: 'composite', label: 'Grows without the drama',
    blurb: 'It keeps growing and its price stays calm.',
    clause: 'grows without big swings', chip: 'Grows calmly', icon: 'steady',
    summary: 'Positive growth, consistent profits and price movement in the calmer half of the list.',
    rules: [
      { id: 'sg-rev', indicator: 'revenueCagr3Y', comparison: 'gte', value: 6,
        requirement: 'sales growth of 6% a year or more', basis: 'Fixed threshold',
        why: 'The growth floor for this blend.', requiresHistoryYears: 3 },
      consistency3,
      { id: 'sg-vol', indicator: 'volatility', comparison: 'percentile_lte', value: 50, scope: 'universe',
        requirement: 'price swings in the calmer half of the list',
        basis: 'Compared with every company in the list',
        why: 'The stability half of the blend.' },
    ] },
  noFilter('composite-any', 'composite', 'No ready-made set', 'None'),

  /* --------------------------------------------------------------- horizon */
  { id: 'horizon-short', categoryId: 'horizon', label: 'For a few months',
    blurb: 'You plan to sell again fairly soon.',
    clause: 'for a shorter-term view', chip: 'A few months', icon: 'clockShort',
    summary: 'Shorter holding periods lean on easily traded shares, so liquidity and movement are checked.',
    caveat: 'A horizon changes which checks matter. It is not a prediction of what happens in that time.',
    rules: [
      { id: 'h-adv-60', indicator: 'avgDailyValue', comparison: 'gte', value: 60,
        requirement: '₹60 crore or more traded on an average day', basis: 'Fixed threshold',
        why: 'Short holding periods depend on being able to get out easily.' },
      { id: 'h-vol', indicator: 'volatility', comparison: 'percentile_lte', value: 75, scope: 'universe',
        requirement: 'outside the most volatile quarter of the list',
        basis: 'Compared with every company in the list',
        why: 'A guardrail so a short horizon does not land only on the wildest movers.' },
    ] },
  { id: 'horizon-medium', categoryId: 'horizon', label: 'For one to three years',
    blurb: 'You can leave the money alone for a couple of years.',
    clause: 'to hold for one to three years', chip: 'One to three years', icon: 'clockMid',
    summary: 'A middle horizon, with a light check on how actively the share trades.',
    rules: [
      { id: 'h-adv-20', indicator: 'avgDailyValue', comparison: 'gte', value: 20,
        requirement: '₹20 crore or more traded on an average day', basis: 'Fixed threshold',
        why: 'Enough trading activity to enter and exit comfortably.' },
    ] },
  { id: 'horizon-long', categoryId: 'horizon', label: 'For five years or more',
    blurb: 'You are happy to wait a long time.',
    clause: 'to hold for the long term', chip: 'Five years or more', icon: 'clockLong',
    summary: 'A long horizon looks for a longer record: years of listing and repeated profit growth.',
    rules: [
      { id: 'h-listed', indicator: 'listedYears', comparison: 'gte', value: 5,
        requirement: 'listed for at least 5 years', basis: 'History check',
        why: 'A longer history gives the other checks something to work with.' },
      consistency3,
    ] },
  noFilter('horizon-any', 'horizon', 'Not sure yet', 'Not sure'),
];

/** How each preference reads inside the one-line screen summary. */
/** How each filter reads inside the one-line sentence. */
export const SUMMARY_PHRASES: Record<string, string> = {
  'growth-steady': 'growing a bit every year',
  'growth-fast': 'growing really fast',
  'growth-sales': 'selling more than before',
  'growth-profit': 'earning more than before',
  'growth-consistent': 'growing year after year',
  'growth-recovery': 'getting better after a bad patch',
  'profit-margins': 'keeping a lot from each sale',
  'profit-rising-margins': 'keeping more than they used to',
  'profit-roe': 'making good money from what they have',
  'profit-roce': 'using their money wisely',
  'profit-quality': 'turning profit into real cash',
  'profit-netmargin': 'keeping a big slice at the end',
  'stability-stable': 'calm and steady',
  'stability-low-vol': 'less jumpy than their rivals',
  'stability-low-beta': 'doing their own thing',
  'stability-earnings': 'steady in their profit',
  'stability-drawdown': 'free of a big crash',
  'balance-low-debt': 'hardly borrowing anything',
  'balance-manageable': 'borrowing only what they can repay',
  'balance-net-cash': 'holding more cash than debt',
  'balance-coverage': 'paying their interest easily',
  'balance-liquidity': 'able to pay this year’s bills',
  'cash-positive': 'bringing in real money',
  'cash-strong': 'collecting plenty of cash',
  'cash-backed': 'backing their profit with cash',
  'cash-fcf': 'left with money to spare',
  'cash-low-capex': 'cheap to keep running',
  'valuation-reasonable': 'priced about right',
  'valuation-discount': 'cheaper than companies like them',
  'valuation-low-pb': 'cheap for everything they own',
  'valuation-growth-value': 'growing fast without the big price',
  'valuation-earnings-yield': 'giving lots of profit for the price',
  'momentum-positive': 'going up in price',
  'momentum-improving': 'picking up speed',
  'momentum-strong': 'on a long winning run',
  'momentum-strength': 'beating companies like them',
  'momentum-near-highs': 'close to their best-ever price',
  'momentum-oversold': 'down a lot lately',
  'performance-strong': 'great over the past year',
  'performance-steady': 'good year after year',
  'performance-positive': 'up over the year',
  'performance-3y': 'great over three years',
  'performance-recovery': 'bouncing back',
  'dividend-yield': 'paying you a lot',
  'dividend-steady': 'paying you every single year',
  'dividend-growing': 'paying a bit more each year',
  'dividend-safe': 'paying only what they can afford',
  'size-large': 'really big companies',
  'size-mid': 'medium-sized companies',
  'size-small': 'small companies',
  'liquidity-high': 'very easy to buy and sell',
  'liquidity-active': 'easy enough to buy and sell',
  'liquidity-float': 'widely held',
  'composite-quality': 'good at pretty much everything',
  'composite-value-quality': 'cheap but still healthy',
  'composite-growth-quality': 'growing fast and earning well',
  'composite-stable-growth': 'growing without the drama',
};

export const OPTION_BY_ID: Record<string, Option> = Object.fromEntries(OPTIONS.map((o) => [o.id, o]));
export const optionsForCategory = (id: CategoryId) => OPTIONS.filter((o) => o.categoryId === id);
export const primaryOptions = (id: CategoryId) => optionsForCategory(id).filter((o) => !o.more);
export const moreOptions = (id: CategoryId) => optionsForCategory(id).filter((o) => o.more);

/** Combinations that pull against each other. Explained, never silently dropped. */
export const CONFLICTS: { options: [string, string]; message: string }[] = [
  { options: ['growth-fast', 'valuation-discount'],
    message: 'Companies growing quickly are rarely priced below their peers at the same time. Expect few matches, or none.' },
  { options: ['growth-fast', 'stability-stable'],
    message: 'Fast growth usually comes with larger price swings, so asking for both narrows the list sharply.' },
  { options: ['momentum-oversold', 'performance-strong'],
    message: 'A share in the oversold range has usually not delivered a strong past year. These pull in opposite directions.' },
  { options: ['momentum-strong', 'valuation-discount'],
    message: 'Shares in a strong trend have often already re-rated, so they rarely look cheap against peers.' },
  { options: ['dividend-yield', 'growth-fast'],
    message: 'Fast-growing companies usually reinvest rather than pay out, so a high yield and fast growth rarely appear together.' },
  { options: ['size-large', 'growth-fast'],
    message: 'Growing at that pace is harder at large size. The list will be short.' },
];

export const CATEGORY_ORDER: CategoryId[] = [
  'growth', 'profitability', 'stability', 'balance', 'cashflow', 'valuation',
  'momentum', 'performance', 'dividends', 'size', 'liquidity', 'composite', 'horizon',
];
