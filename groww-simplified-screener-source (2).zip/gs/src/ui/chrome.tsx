import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { IconBell, IconChevronRight, IconInfo, IconMoon, IconRefresh, IconSearch, IconSettings, IconSun, IconUser } from './icons';
import { GROWW_MARK, SCREENER_WORDMARK } from '../assets/logo';
import { CompanyLogo } from './companyLogo';
import { Button, Chip, Modal } from './primitives';
import { useStore } from '../state/store';
import { getEvents, subscribeEvents, track } from '../state/analytics';
import { RULE_VERSION, SNAPSHOT_LABEL, STOCKS, formatPrice } from '../data/stocks';
import { profileSummary } from '../data/profile';

/* --------------------------------------------------------------- header */

const NAV: { id: string; label: string }[] = [
  { id: 'stocks', label: 'Stocks' },
  { id: 'fno', label: 'F&O' },
  { id: 'mf', label: 'Mutual Funds' },
  { id: 'screener', label: 'Screener' },
];

/** the second row inside the Screener section; only Explore is built out */
const TABS: { id: string; label: string }[] = [
  { id: 'explore', label: 'Explore' },
  { id: 'dashboard', label: 'Dashboard' },
  { id: 'fund', label: 'Fund Plan' },
  { id: 'saved', label: 'Saved' },
];

export function GrowwHeader({ onNotice }: { onNotice: (msg: string) => void }) {
  const { state, dispatch } = useStore();
  const [searchOpen, setSearchOpen] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);
  const accountRef = useRef<HTMLDivElement | null>(null);
  const profileRows = profileSummary(state.profile);
  const dark = state.theme === 'dark'
    || (state.theme === 'system' && typeof window !== 'undefined' && window.matchMedia?.('(prefers-color-scheme: dark)').matches);

  useEffect(() => {
    if (!accountOpen) return undefined;
    const onDown = (e: MouseEvent) => {
      if (!accountRef.current?.contains(e.target as Node)) setAccountOpen(false);
    };
    const onEsc = (e: KeyboardEvent) => { if (e.key === 'Escape') setAccountOpen(false); };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onEsc);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onEsc);
    };
  }, [accountOpen]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, []);

  const notPartOfPrototype = (label: string) =>
    onNotice(`${label} is not part of this prototype. The screener is the piece to try.`);

  return (
    <>
      <header className="gw-header">
        <div className="shell shell--bleed">
          <div className="gw-header__row">
            <div className="gw-logo">
              <img className="gw-logo__mark" src={GROWW_MARK} alt="" width={36} height={36} />
              <img className="gw-logo__word" src={SCREENER_WORDMARK} alt="Screener" />
              <span className="gw-logo__sub">by Groww</span>
            </div>
            <nav className="gw-nav" aria-label="Main">
              {NAV.map((item) => {
                const active = item.id === 'screener';
                return (
                  <button
                    key={item.id}
                    className={active ? 'is-active' : ''}
                    aria-current={active ? 'page' : undefined}
                    onClick={() => (active
                      ? dispatch({ type: 'go', route: { name: state.onboardingComplete ? 'screener' : 'intro' } })
                      : notPartOfPrototype(item.label))}
                  >
                    {item.label}
                  </button>
                );
              })}
            </nav>
            <button className="gw-search" onClick={() => setSearchOpen(true)} aria-label="Search stocks">
              <IconSearch />
              <span>Search for stocks, sectors or ideas...</span>
              <kbd>⌘K</kbd>
            </button>
            <div className="row gap4">
              <button className="gw-icon-btn" aria-label="Notifications" onClick={() => notPartOfPrototype('Notifications')}><IconBell /></button>
              <div className="menu account" ref={accountRef}>
                <button className="gw-avatar" aria-haspopup="menu" aria-expanded={accountOpen}
                  aria-label="Account and profile" onClick={() => setAccountOpen((o) => !o)}>
                  S
                </button>
                {accountOpen ? (
                  <div className="menu__list menu__list--end account__menu" role="menu">
                    <div className="account__head">
                      <span className="gw-avatar" aria-hidden="true">S</span>
                      <span className="stack gap4">
                        <b>Demo account</b>
                        <span className="tiny faint">
                          {profileRows.length
                            ? profileRows.slice(0, 2).map((r) => r.value).join(' · ')
                            : 'Investing profile not set'}
                        </span>
                      </span>
                    </div>
                    <button className="menu__item" role="menuitem"
                      onClick={() => {
                        setAccountOpen(false);
                        track('profile_edit_opened', { from: 'header' });
                        dispatch({ type: 'go', route: { name: profileRows.length ? 'summary' : 'onboarding' } });
                      }}>
                      <span className="row gap8"><IconUser size={15} /> Investing profile</span>
                      <IconChevronRight size={14} />
                    </button>
                    <button className="menu__item" role="menuitem"
                      onClick={() => { setAccountOpen(false); notPartOfPrototype('Account settings'); }}>
                      <span className="row gap8"><IconSettings size={15} /> Account settings</span>
                      <IconChevronRight size={14} />
                    </button>
                  </div>
                ) : null}
              </div>
            </div>
          </div>
          <nav className="gw-tabs" aria-label="Screener sections">
            {TABS.map((t) => {
              const active = t.id === 'explore';
              return (
                <button key={t.id} className={active ? 'is-active' : ''}
                  aria-current={active ? 'page' : undefined}
                  onClick={() => (active ? undefined : notPartOfPrototype(t.label))}>
                  {t.label}
                </button>
              );
            })}
          </nav>
        </div>
      </header>
      {searchOpen ? <SearchModal onClose={() => setSearchOpen(false)} /> : null}

    </>
  );
}

function SearchModal({ onClose }: { onClose: () => void }) {
  const { dispatch } = useStore();
  const [q, setQ] = useState('');
  const results = useMemo(() => {
    const t = q.trim().toLowerCase();
    if (!t) return STOCKS.slice(0, 6);
    return STOCKS.filter((s) => s.name.toLowerCase().includes(t) || s.symbol.toLowerCase().includes(t)).slice(0, 8);
  }, [q]);

  return (
    <Modal title="Search stocks" subtitle="The 30 fictional companies in this prototype" onClose={onClose}>
      <div className="amount-field" style={{ marginTop: 0 }}>
        <IconSearch />
        {/* eslint-disable-next-line jsx-a11y/no-autofocus */}
        <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Company or symbol" aria-label="Search by company or symbol" />
      </div>
      <div className="stack" style={{ marginTop: 12 }}>
        {results.map((s) => (
          <button key={s.id} className="card__row" style={{ borderTop: '1px solid var(--border)' }}
            onClick={() => { track('stock_detail_opened', { id: s.id, from: 'search' }); dispatch({ type: 'go', route: { name: 'stock', id: s.id } }); onClose(); }}>
            <span className="row gap12">
              <CompanyLogo stock={s} size={34} />
              <span className="stack gap4">
                <span className="stock-name">{s.name}</span>
                <span className="small muted">{s.symbol} · {s.sector}</span>
              </span>
            </span>
            <span className="row gap8">
              <span className="mono-num">{formatPrice(s.price)}</span>
              <IconChevronRight />
            </span>
          </button>
        ))}
        {!results.length ? <p className="muted small" style={{ padding: '12px 0' }}>No company here matches that. Try “bank”, “pharma” or a symbol.</p> : null}
      </div>
    </Modal>
  );
}

/* --------------------------------------------------------------- footer */

export function AppFooter() {
  const [logOpen, setLogOpen] = useState(false);
  return (
    <>
      <footer className="gw-footer">
        <div className="shell gw-footer__row">
          <div className="stack gap4">
            <span>
              Demo data only — fictional companies, invented numbers, snapshot labelled {SNAPSHOT_LABEL}. Nothing here is live market data.
            </span>
            <span className="faint">
              A concept prototype, not investment advice. It filters and explains; it does not recommend. {RULE_VERSION}.
            </span>
          </div>
          <button className="link-btn link-btn--plain small" onClick={() => setLogOpen(true)}>Event log</button>
        </div>
      </footer>
      {logOpen ? <EventLog onClose={() => setLogOpen(false)} /> : null}
    </>
  );
}

function EventLog({ onClose }: { onClose: () => void }) {
  const [, force] = useState(0);
  useEffect(() => subscribeEvents(() => force((n) => n + 1)), []);
  const events = getEvents();
  return (
    <Modal title="Event log" subtitle="The analytics events this flow would send in production" onClose={onClose}>
      {!events.length ? <p className="muted small">Nothing fired yet.</p> : null}
      <div className="stack">
        {events.map((e, i) => (
          <div key={i} className="row gap8" style={{ padding: '8px 0', borderTop: i ? '1px solid var(--border)' : 0 }}>
            <code className="small" style={{ color: 'var(--heading)' }}>{e.name}</code>
            <span className="tiny faint grow" style={{ textAlign: 'right' }}>
              {e.props ? JSON.stringify(e.props) : ''}
            </span>
          </div>
        ))}
      </div>
    </Modal>
  );
}

/* ----------------------------------------------------------- coach marks */

export interface CoachStep {
  target: string;
  title: string;
  body: string;
}

export function CoachMarks({ steps, onDone }: { steps: CoachStep[]; onDone: () => void }) {
  const [i, setI] = useState(0);
  const [rect, setRect] = useState<DOMRect | null>(null);
  const [pos, setPos] = useState<{ top: number; left: number } | null>(null);
  const cardRef = useRef<HTMLDivElement | null>(null);

  const PAD = 8;    // halo drawn around the target
  const GAP = 14;   // distance between the target and the card
  const EDGE = 16;  // keep the card inside the viewport

  useLayoutEffect(() => {
    const target = () => document.querySelector<HTMLElement>(`[data-coach="${steps[i].target}"]`);
    const measure = () => {
      const el = target();
      setRect(el ? el.getBoundingClientRect() : null);
    };
    target()?.scrollIntoView({ block: 'center', behavior: 'smooth' });
    measure();
    // re-measure once the smooth scroll has settled
    const settle = window.setTimeout(measure, 320);
    window.addEventListener('resize', measure);
    window.addEventListener('scroll', measure, true);
    return () => {
      clearTimeout(settle);
      window.removeEventListener('resize', measure);
      window.removeEventListener('scroll', measure, true);
    };
  }, [i, steps]);

  useEffect(() => { track('coach_marks_shown', { step: i + 1 }); }, [i]);

  const spot = rect
    ? { top: rect.top - PAD, left: rect.left - PAD, width: rect.width + PAD * 2, height: rect.height + PAD * 2 }
    : null;

  /**
   * Place the card where it does not sit on top of what it is pointing at:
   * below, above, beside, and only then a corner — picking whichever candidate
   * fits on screen with the least overlap.
   */
  useLayoutEffect(() => {
    const cw = cardRef.current?.offsetWidth || 320;
    const ch = cardRef.current?.offsetHeight || 190;
    const vw = window.innerWidth;
    const vh = window.innerHeight;

    if (!spot) {
      setPos({ top: Math.max(EDGE, vh / 2 - ch / 2), left: Math.max(EDGE, vw / 2 - cw / 2) });
      return;
    }

    const x1 = spot.left;
    const y1 = spot.top;
    const x2 = spot.left + spot.width;
    const y2 = spot.top + spot.height;
    const clampX = (x: number) => Math.max(EDGE, Math.min(vw - cw - EDGE, x));
    const clampY = (y: number) => Math.max(EDGE, Math.min(vh - ch - EDGE, y));

    const candidates = [
      { top: y2 + GAP, left: clampX(x1) },            // below
      { top: y1 - ch - GAP, left: clampX(x1) },       // above
      { top: clampY(y1), left: x2 + GAP },            // to the right
      { top: clampY(y1), left: x1 - cw - GAP },       // to the left
      { top: vh - ch - EDGE, left: vw - cw - EDGE },  // bottom right
      { top: EDGE, left: vw - cw - EDGE },            // top right
      { top: vh - ch - EDGE, left: EDGE },            // bottom left
    ];
    const onScreen = (c: { top: number; left: number }) =>
      c.top >= EDGE && c.left >= EDGE && c.top + ch <= vh - EDGE && c.left + cw <= vw - EDGE;
    const overlap = (c: { top: number; left: number }) => {
      const ox = Math.max(0, Math.min(c.left + cw, x2) - Math.max(c.left, x1));
      const oy = Math.max(0, Math.min(c.top + ch, y2) - Math.max(c.top, y1));
      return ox * oy;
    };

    const usable = candidates.filter(onScreen);
    const clear = usable.find((c) => overlap(c) === 0);
    const best = clear
      ?? [...usable].sort((a, b) => overlap(a) - overlap(b))[0]
      ?? { top: clampY(y2 + GAP), left: clampX(x1) };
    setPos(best);
  }, [rect, i]);

  const finish = () => { track('coach_marks_dismissed', { atStep: i + 1 }); onDone(); };

  /**
   * On a narrow screen a tall target can leave nowhere clear to put the card.
   * Rather than covering it, the halo is trimmed back to the part that stays
   * visible above or below the card.
   */
  const halo = (() => {
    if (!spot || !pos) return spot;
    const cw = cardRef.current?.offsetWidth || 320;
    const ch = cardRef.current?.offsetHeight || 190;
    const sideBySide = Math.min(pos.left + cw, spot.left + spot.width) - Math.max(pos.left, spot.left) <= 0;
    if (sideBySide) return spot;
    const cardTop = pos.top;
    const cardBottom = pos.top + ch;
    const spotBottom = spot.top + spot.height;
    if (cardTop > spot.top && cardTop < spotBottom) {
      return { ...spot, height: Math.max(48, cardTop - GAP - spot.top) };
    }
    if (cardBottom > spot.top && cardBottom < spotBottom) {
      return { ...spot, top: cardBottom + GAP, height: Math.max(48, spotBottom - cardBottom - GAP) };
    }
    return spot;
  })();

  return (
    <>
      {halo ? <div className="coach-spot" style={halo} /> : <div className="coach-overlay" />}
      <div
        className="coach-card"
        ref={cardRef}
        style={{ top: pos?.top ?? 0, left: pos?.left ?? 0, visibility: pos ? 'visible' : 'hidden' }}
        role="dialog"
        aria-label="Quick tour"
      >
        <div className="label-caps">Step {i + 1} of {steps.length}</div>
        <h3>{steps[i].title}</h3>
        <p className="small muted">{steps[i].body}</p>
        <div className="coach-card__foot">
          <div className="coach-dots" aria-hidden="true">
            {steps.map((_, n) => <i key={n} className={n === i ? 'is-on' : ''} />)}
          </div>
          <div className="row gap8">
            <Button size="xs" variant="ghost" onClick={finish}>Skip</Button>
            <Button size="xs" variant="primary" onClick={() => (i === steps.length - 1 ? finish() : setI(i + 1))}>
              {i === steps.length - 1 ? 'Got it' : 'Next'}
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}

/* -------------------------------------------------------- small helpers */

export const RefreshChip = ({ onClick }: { onClick: () => void }) => (
  <Chip onClick={onClick} aria-label="Run this screen again"><IconRefresh size={15} /> Run again</Chip>
);
