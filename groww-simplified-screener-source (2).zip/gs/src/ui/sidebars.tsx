import React from 'react';
import { MountainArt } from './icons';

/** One step in a vertical progress list. Shared by the screener and the learning screens. */
export function Stage({ n, state, label, sub, onClick }: {
  n: number; state: 'active' | 'done' | 'upcoming'; label: string; sub: string; onClick?: () => void;
}) {
  const body = (
    <span className="stack gap4">
      <span className="stage__label">{label}</span>
      {sub ? <span className="stage__sub">{sub}</span> : null}
    </span>
  );
  return (
    <li className={`stage is-${state}`}>
      <span className="stage__num" aria-hidden="true">{n}</span>
      <span className="sr-only">
        {state === 'active' ? 'Current step: ' : state === 'done' ? 'Completed step: ' : 'Upcoming step: '}
      </span>
      {onClick ? <button className="stage-btn" onClick={onClick}>{body}</button> : body}
    </li>
  );
}

/** Shown in place of the left sidebar on narrow screens. */
export function StageStrip({ steps, active }: { steps: string[]; active: number }) {
  return (
    <div className="stage-strip">
      {steps.map((label, i) => (
        <span key={label} className={`stage-strip__item${i + 1 === active ? ' is-active' : ''}`}>
          {i + 1} · {label}
          {i + 1 === active ? <span className="sr-only"> (current step)</span> : null}
        </span>
      ))}
    </div>
  );
}

/** Build → Review → Explore, the screener's own journey. */
export function ScreenerStages({ active, onReview, onExplore }: {
  active: 'build' | 'review' | 'explore';
  onReview?: () => void;
  onExplore?: () => void;
}) {
  const stateFor = (id: 'build' | 'review' | 'explore') => {
    const order = ['build', 'review', 'explore'];
    const i = order.indexOf(id);
    const a = order.indexOf(active);
    return i === a ? 'active' : i < a ? 'done' : 'upcoming';
  };
  return (
    <>
      <div>
        <div className="side-title">
          <h2>Stock Screener</h2>
          <span className="beta">BETA</span>
        </div>
        <p className="small muted" style={{ marginTop: 4 }}>Find great companies, the easy way.</p>
      </div>
      <ol className="stages">
        <Stage n={1} state={stateFor('build') as 'active'} label="Build" sub="Add filters to create your screen" />
        <Stage n={2} state={stateFor('review') as 'active'} label="Review" sub="Check and refine your criteria" onClick={onReview} />
        <Stage n={3} state={stateFor('explore') as 'active'} label="Explore" sub="See results and find opportunities" onClick={onExplore} />
      </ol>
    </>
  );
}

/** What we checked → Why it matters → How it works, the learning journey. */
export function LearningStages({ active }: { active: 1 | 2 | 3 }) {
  const stateFor = (n: number) => (n === active ? 'active' : n < active ? 'done' : 'upcoming');
  return (
    <>
      <div>
        <div className="side-title"><h2>Learn as you go</h2></div>
        <p className="small muted" style={{ marginTop: 4 }}>See what is behind every filter you picked.</p>
      </div>
      <ol className="stages">
        <Stage n={1} state={stateFor(1) as 'active'} label="What we checked" sub="The numbers behind your filters" />
        <Stage n={2} state={stateFor(2) as 'active'} label="Why it matters" sub="What each one tells you" />
        <Stage n={3} state={stateFor(3) as 'active'} label="How it works" sub="Simple examples" />
      </ol>
      <div className="mountain"><MountainArt /></div>
      <blockquote className="side-quote">
        “The more you understand, the better you choose.”
        <span>— Groww</span>
      </blockquote>
    </>
  );
}
