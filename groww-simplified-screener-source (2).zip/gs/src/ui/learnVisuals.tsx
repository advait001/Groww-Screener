import React from 'react';
import type { LearnVisualKind } from '../data/learning';

/**
 * Educational diagrams, not trading charts. Each one illustrates the idea
 * behind an indicator; where a real value is available it is annotated, but
 * the shape of the diagram stays simple and readable.
 */

const W = 420;
const H = 156;

const label = (x: number, y: number, t: string, anchor: 'start' | 'middle' | 'end' = 'middle', fill = 'var(--text-2)', size = 11, weight = 400) => (
  <text x={x} y={y} textAnchor={anchor} fill={fill} fontSize={size} fontWeight={weight} fontFamily="inherit">{t}</text>
);

const frame = (children: React.ReactNode, aria: string) => (
  <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H} role="img" aria-label={aria}>{children}</svg>
);

/* --------------------------------------------------------------- shapes */

function GrowthBars({ years, rising = true }: { years?: string[]; rising?: boolean }) {
  const now = new Date().getFullYear();
  const ys = years ?? [now - 4, now - 3, now - 2, now - 1, now].map(String);
  const heights = rising ? [34, 46, 58, 74, 92] : [92, 74, 58, 46, 34];
  return frame(
    <>
      {heights.map((h, i) => {
        const x = 62 + i * 62;
        const last = i >= heights.length - 2;
        return (
          <g key={i}>
            <rect x={x} y={118 - h} width={38} height={h} rx={5}
              fill={last ? 'var(--green)' : 'var(--tone-blue-fg)'} opacity={last ? 0.92 : 0.55} />
            {label(x + 19, 136, ys[i])}
          </g>
        );
      })}
      <path d="M72 96 C 150 84, 230 58, 300 30" fill="none" stroke="var(--green-text)" strokeWidth="2" strokeLinecap="round" />
      <path d="M292 26l14 2-6 12z" fill="var(--green-text)" />
      <line x1="48" y1="118" x2={W - 30} y2="118" stroke="var(--border)" />
    </>,
    'Bars rising year by year, showing growth over time',
  );
}

function Consistency() {
  const years = ['Y1', 'Y2', 'Y3', 'Y4'];
  const up = [true, true, false, true];
  return frame(
    <>
      {years.map((y, i) => {
        const x = 54 + i * 86;
        return (
          <g key={y}>
            <rect x={x} y={44} width={66} height={48} rx={10}
              fill={up[i] ? 'var(--green-tint)' : 'var(--bg-3)'}
              stroke={up[i] ? 'var(--green)' : 'var(--border-2)'} />
            <path d={up[i] ? `M${x + 22} 72 l10 -12 l10 12` : `M${x + 22} 68 h20`}
              fill="none" stroke={up[i] ? 'var(--green-text)' : 'var(--text-3)'} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            {label(x + 33, 110, y)}
          </g>
        );
      })}
      {label(W / 2, 28, 'Profit higher than the year before?', 'middle', 'var(--heading)', 12, 500)}
      {label(W / 2, 136, '3 of 4 years up', 'middle', 'var(--green-text)', 12, 500)}
    </>,
    'Four years marked as profit up or flat',
  );
}

function LevelBar({ value, unit = '', cap }: { value?: number | null; unit?: string; cap?: number }) {
  const top = cap ?? (value && value > 40 ? Math.ceil(value * 1.5) : 40);
  const pct = value != null ? Math.max(0.04, Math.min(1, value / top)) : 0.62;
  return frame(
    <>
      <rect x={40} y={62} width={W - 80} height={26} rx={13} fill="var(--bg-3)" />
      <rect x={40} y={62} width={(W - 80) * pct} height={26} rx={13} fill="var(--green)" opacity={0.9} />
      <line x1={40 + (W - 80) * 0.5} y1={52} x2={40 + (W - 80) * 0.5} y2={98} stroke="var(--border-2)" strokeDasharray="3 3" />
      {label(40 + (W - 80) * 0.5, 44, 'typical level', 'middle', 'var(--text-3)')}
      {value != null ? label(40 + (W - 80) * pct, 112, `${value.toFixed(1)}${unit}`, 'middle', 'var(--heading)', 12, 500) : null}
      {label(40, 130, 'lower', 'start')}
      {label(W - 40, 130, 'higher', 'end')}
    </>,
    'A bar showing where a value sits against a typical level',
  );
}

function DebtLevel({ value }: { value?: number | null }) {
  const ratio = value ?? 0.4;
  const debtW = Math.max(30, Math.min(260, ratio * 200));
  return frame(
    <>
      <rect x={110} y={38} width={200} height={28} rx={6} fill="#bcd8f5" opacity={0.8} />
      {label(100, 57, 'Shareholders', 'end', 'var(--text-2)', 11.5)}
      <rect x={110} y={82} width={debtW} height={28} rx={6} fill="var(--blue)" opacity={0.55} />
      {label(100, 101, 'Borrowed', 'end', 'var(--text-2)', 11.5)}
      <line x1={310} y1={30} x2={310} y2={120} stroke="var(--border-2)" strokeDasharray="3 3" />
      {label(310, 136, 'same as shareholder money', 'middle', 'var(--text-3)')}
      {value != null ? label(110 + debtW + 8, 101, `${value.toFixed(2)}x`, 'start', 'var(--heading)', 12, 500) : null}
    </>,
    'Borrowed money compared with shareholder money',
  );
}

function Coverage({ value }: { value?: number | null }) {
  const n = Math.max(1, Math.min(7, Math.round(value ?? 5)));
  return frame(
    <>
      <rect x={38} y={56} width={44} height={40} rx={8} fill="var(--red-tint)" stroke="var(--red)" />
      {label(60, 112, 'Interest', 'middle')}
      {Array.from({ length: n }).map((_, i) => (
        <rect key={i} x={108 + i * 42} y={56} width={34} height={40} rx={8} fill="var(--green-tint)" stroke="var(--green)" />
      ))}
      {label(108 + (n * 42) / 2, 112, 'Profit', 'middle')}
      {label(W / 2, 32, value != null ? `Profit covers interest about ${value.toFixed(1)} times over` : 'Profit covers the interest bill several times over',
        'middle', 'var(--heading)', 12, 500)}
    </>,
    'Blocks of profit compared with one block of interest',
  );
}

function CashFlow() {
  const box = (x: number, colour: string, text: string, caption: string) => (
    <g>
      <rect x={x} y={52} width={104} height={46} rx={10} fill={colour} />
      {label(x + 52, 80, text, 'middle', 'var(--heading)', 13, 500)}
      {label(x + 52, 116, caption, 'middle')}
    </g>
  );
  return frame(
    <>
      {box(24, 'var(--green-tint)', 'Cash in', 'what customers paid')}
      <path d="M140 75h28" stroke="var(--text-3)" strokeWidth="1.6" strokeLinecap="round" />
      <path d="M164 70l6 5-6 5" fill="none" stroke="var(--text-3)" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
      {box(172, 'var(--red-tint)', 'Cash out', 'running the business')}
      <path d="M288 75h28" stroke="var(--text-3)" strokeWidth="1.6" strokeLinecap="round" />
      <path d="M312 70l6 5-6 5" fill="none" stroke="var(--text-3)" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
      <rect x={320} y={52} width={76} height={46} rx={10} fill="var(--green)" opacity={0.9} />
      {label(358, 80, 'Left over', 'middle', '#fff', 12.5, 500)}
      {label(358, 116, 'the cash flow', 'middle')}
    </>,
    'Cash coming in, cash going out, and what is left',
  );
}

function PeerBars({ value, peer, unit = 'x' }: { value?: number | null; peer?: number | null; unit?: string }) {
  const a = value ?? 18;
  const b = peer ?? 24;
  const max = Math.max(a, b) * 1.3 || 1;
  const bar = (v: number, x: number, colour: string, caption: string) => {
    const h = (v / max) * 76;
    return (
      <g>
        <rect x={x} y={104 - h} width={62} height={h} rx={6} fill={colour} />
        {label(x + 31, 100 - h, `${v.toFixed(1)}${unit}`, 'middle', 'var(--heading)', 12, 500)}
        {label(x + 31, 124, caption, 'middle')}
      </g>
    );
  };
  return frame(
    <>
      <line x1={40} y1={104} x2={W - 40} y2={104} stroke="var(--border)" />
      {bar(a, 116, 'var(--green)', 'This company')}
      {bar(b, 242, 'var(--border-2)', 'Similar companies')}
      {label(W / 2, 28, 'Cheaper or dearer than the companies beside it', 'middle', 'var(--text-2)', 11.5)}
    </>,
    'This company compared with similar companies',
  );
}

function VolatilityPaths() {
  return frame(
    <>
      <path d="M40 92 C 90 84, 140 76, 200 68 S 320 52, 380 46" fill="none" stroke="var(--green-text)" strokeWidth="2" strokeLinecap="round" />
      {label(40, 116, 'Calmer path', 'start', 'var(--green-text)', 11.5, 500)}
      <path d="M40 60 l24 26 l22 -34 l26 40 l24 -30 l28 36 l26 -42 l30 46 l26 -38 l28 30 l26 -34 l30 26"
        fill="none" stroke="var(--red)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" opacity={0.75} />
      {label(W - 40, 116, 'Bigger swings', 'end', 'var(--red)', 11.5, 500)}
      {label(W / 2, 140, 'Both can end the year in the same place', 'middle', 'var(--text-3)')}
    </>,
    'A calm price path next to a jagged one',
  );
}

function Returns({ oneYear, threeYear, worst }: { oneYear?: number | null; threeYear?: number | null; worst?: number | null }) {
  const rows: [string, number | null][] = [
    ['Past year', oneYear ?? 16],
    ['Per year, 3 years', threeYear ?? 12],
    ['Worst fall', worst ?? -18],
  ];
  const max = 60;
  return frame(
    <>
      <line x1={W / 2} y1={26} x2={W / 2} y2={128} stroke="var(--border)" />
      {rows.map(([name, v], i) => {
        const y = 36 + i * 32;
        if (v == null) return <g key={name}>{label(W / 2, y + 12, `${name}: no data`, 'middle')}</g>;
        const w = (Math.min(Math.abs(v), max) / max) * (W / 2 - 46);
        const x = v >= 0 ? W / 2 : W / 2 - w;
        return (
          <g key={name}>
            <rect x={x} y={y} width={w} height={18} rx={4} fill={v >= 0 ? 'var(--green)' : 'var(--red)'} opacity={0.85} />
            {label(v >= 0 ? W / 2 - 8 : W / 2 + 8, y + 13, name, v >= 0 ? 'end' : 'start')}
            {label(v >= 0 ? x + w + 6 : x - 6, y + 13, `${v > 0 ? '+' : ''}${v.toFixed(1)}%`, v >= 0 ? 'start' : 'end', 'var(--heading)', 11, 500)}
          </g>
        );
      })}
    </>,
    'Returns and the worst fall along the way',
  );
}

function Gauge({ value }: { value?: number | null }) {
  const v = value ?? 58;
  const x = 46 + (v / 100) * (W - 92);
  return frame(
    <>
      <rect x={46} y={64} width={(W - 92) * 0.3} height={16} rx={8} fill="var(--red-tint)" />
      <rect x={46 + (W - 92) * 0.3} y={64} width={(W - 92) * 0.4} height={16} fill="var(--bg-3)" />
      <rect x={46 + (W - 92) * 0.7} y={64} width={(W - 92) * 0.3} height={16} rx={8} fill="var(--green-tint)" />
      <line x1={x} y1={52} x2={x} y2={92} stroke="var(--heading)" strokeWidth="2.5" strokeLinecap="round" />
      {label(x, 44, v.toFixed(0), 'middle', 'var(--heading)', 13, 600)}
      {label(46 + (W - 92) * 0.15, 108, 'oversold', 'middle', 'var(--red)')}
      {label(W / 2, 108, 'middle of the range', 'middle')}
      {label(46 + (W - 92) * 0.85, 108, 'overbought', 'middle', 'var(--green-text)')}
      {label(W / 2, 134, 'A description of recent moves, not a prediction', 'middle', 'var(--text-3)')}
    </>,
    'A 0 to 100 momentum scale with a marker',
  );
}

function TrendLine({ above = true }: { above?: boolean }) {
  const price = above
    ? 'M40 104 C 110 96, 150 86, 210 74 S 330 50, 384 42'
    : 'M40 44 C 110 54, 150 66, 210 80 S 330 100, 384 110';
  const avg = above
    ? 'M40 112 C 120 106, 180 98, 250 88 S 340 70, 384 62'
    : 'M40 52 C 120 60, 180 70, 250 82 S 340 94, 384 100';
  return frame(
    <>
      <path d={avg} fill="none" stroke="var(--text-3)" strokeWidth="1.6" strokeDasharray="5 4" />
      <path d={price} fill="none" stroke={above ? 'var(--green-text)' : 'var(--red)'} strokeWidth="2.2" strokeLinecap="round" />
      {label(46, 28, 'Price', 'start', above ? 'var(--green-text)' : 'var(--red)', 11.5, 500)}
      {label(92, 28, '50-day average', 'start', 'var(--text-3)', 11.5)}
      {label(W - 40, 138, above ? 'price sitting above its average' : 'price sitting below its average', 'end', 'var(--text-2)')}
    </>,
    'A price line against its smoothed average',
  );
}

/* ---------------------------------------------------------------- export */

export interface LearnVisualProps {
  kind: LearnVisualKind;
  value?: number | null;
  peer?: number | null;
  unit?: string;
  returns?: { oneYear?: number | null; threeYear?: number | null; worst?: number | null };
}

export function LearnVisual({ kind, value, peer, unit, returns }: LearnVisualProps) {
  switch (kind) {
    case 'growthBars': return <GrowthBars rising={(value ?? 1) >= 0} />;
    case 'consistency': return <Consistency />;
    case 'debtLevel': return <DebtLevel value={value} />;
    case 'coverage': return <Coverage value={value} />;
    case 'cashFlow': return <CashFlow />;
    case 'peerBars': return <PeerBars value={value} peer={peer} unit={unit ?? 'x'} />;
    case 'volatilityPaths': return <VolatilityPaths />;
    case 'returns': return <Returns {...(returns ?? {})} />;
    case 'gauge': return <Gauge value={value} />;
    case 'trendLine': return <TrendLine above={(value ?? 1) >= 0} />;
    case 'levelBar':
    default: return <LevelBar value={value} unit={unit ?? ''} />;
  }
}
