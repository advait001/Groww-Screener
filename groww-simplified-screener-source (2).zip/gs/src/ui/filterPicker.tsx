import React, { useEffect, useMemo, useRef, useState } from 'react';
import type { CategoryId, Option } from '../data/config';
import { CATEGORIES, OPTIONS, OPTION_BY_ID, optionsForCategory } from '../data/config';
import type { Selections } from '../engine/screener';
import { IconCheck, IconClose, IconPlus, IconSearch, OptionIcon } from './icons';
import { Button } from './primitives';

type RailId = 'all' | CategoryId;

/**
 * A floating panel for browsing every filter in one place: search across all of
 * them, or walk the categories in the rail. Rows can be tapped to add, or
 * dragged onto the screener statement — the panel deliberately does not block
 * the page behind it, so dragging still works.
 */
export function FilterPicker({ selections, suggestions, onToggle, onClearAll, onClose }: {
  selections: Selections;
  suggestions: Partial<Record<CategoryId, string>>;
  onToggle: (optionId: string, from: 'tap' | 'keyboard' | 'drop') => void;
  onClearAll: () => void;
  onClose: () => void;
}) {
  const [rail, setRail] = useState<RailId>('all');
  const [query, setQuery] = useState('');
  const panelRef = useRef<HTMLDivElement | null>(null);
  const searchRef = useRef<HTMLInputElement | null>(null);
  const drag = useFilterDrag(onToggle);

  useEffect(() => { searchRef.current?.focus(); }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    const onDown = (e: MouseEvent) => {
      const t = e.target as HTMLElement;
      if (panelRef.current?.contains(t)) return;
      if (t.closest('[data-picker-toggle]')) return;
      onClose();
    };
    document.addEventListener('keydown', onKey);
    document.addEventListener('mousedown', onDown);
    return () => {
      document.removeEventListener('keydown', onKey);
      document.removeEventListener('mousedown', onDown);
    };
  }, [onClose]);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (q) {
      return OPTIONS.filter((o) =>
        o.label.toLowerCase().includes(q)
        || o.summary.toLowerCase().includes(q)
        || o.blurb.toLowerCase().includes(q));
    }
    return rail === 'all' ? OPTIONS : optionsForCategory(rail);
  }, [query, rail]);

  /** grouped by category, so a search or the "All filters" view stays readable */
  const groups = useMemo(() => {
    const out: { id: CategoryId; label: string; options: Option[] }[] = [];
    for (const c of CATEGORIES) {
      const options = results.filter((o) => o.categoryId === c.id);
      if (options.length) out.push({ id: c.id, label: c.label, options });
    }
    return out;
  }, [results]);

  const chosenCount = CATEGORIES.filter((c) => selections[c.id]).length;
  const chosenList = useMemo(
    () => CATEGORIES.map((c) => selections[c.id]).filter(Boolean).map((id) => OPTION_BY_ID[id as string]),
    [selections]);

  return (
    <>
      <div className="picker-scrim" onClick={onClose} />
      <div className="filter-picker" role="dialog" aria-label="Add filters to your screen" ref={panelRef}>
        <div className="picker-head">
          <div className="stack gap4 grow">
            <h2>Add filters</h2>
            <p className="small muted">One filter per group. Picking another swaps it.</p>
          </div>
          <button className="close-btn" onClick={onClose} aria-label="Close"><IconClose /></button>
        </div>

        <div className="picker-search">
          <IconSearch size={16} />
          <input
            ref={searchRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search — try “grows”, “cheap”, “safe”"
            aria-label="Search filters"
          />
          {query ? (
            <button className="close-btn" style={{ width: 26, height: 26 }} aria-label="Clear search" onClick={() => setQuery('')}>
              <IconClose size={14} />
            </button>
          ) : null}
        </div>

        {chosenList.length ? (
          <div className="picker-chips" aria-label="Filters you have chosen">
            {chosenList.map((o) => (
              <span className={`pchip cat-${o.categoryId}`} key={o.id}>
                <span className="pchip__icon"><OptionIcon name={o.icon} size={15} /></span>
                <span className="pchip__body">
                  <span className="pchip__cat">{CATEGORIES.find((c) => c.id === o.categoryId)?.label}</span>
                  <span className="pchip__label">{o.chip}</span>
                </span>
                <button className="pchip__x" aria-label={`Remove ${o.chip}`} onClick={() => onToggle(o.id, 'tap')}>
                  <IconClose size={13} />
                </button>
              </span>
            ))}
          </div>
        ) : null}

        <div className="picker-body">
          <nav className="picker-rail" aria-label="Filter categories">
            <button className={`picker-rail__item${rail === 'all' && !query ? ' is-active' : ''}`}
              onClick={() => { setRail('all'); setQuery(''); }}>
              <span className="grow">All filters</span>
              <span className="tiny faint">{OPTIONS.length}</span>
            </button>
            <span className="label-caps picker-rail__label">Categories</span>
            {CATEGORIES.map((c) => (
              <button key={c.id} className={`picker-rail__item${rail === c.id && !query ? ' is-active' : ''}`}
                aria-current={rail === c.id && !query ? 'true' : undefined}
                onClick={() => { setRail(c.id); setQuery(''); }}>
                <OptionIcon name={c.icon} size={16} />
                <span className="grow">{c.label}</span>
                {selections[c.id] ? <span className="cat-nav__dot" aria-label="filter chosen" /> : null}
              </button>
            ))}
          </nav>

          <div className="picker-list">
            {query ? (
              <p className="picker-list__note small muted">
                {results.length} {results.length === 1 ? 'filter' : 'filters'} matching “{query}”
              </p>
            ) : null}

            {groups.map((g) => (
              <section key={g.id}>
                {(rail === 'all' || query) ? <h3 className="picker-group">{g.label}</h3> : null}
                {g.options.map((o) => {
                  const selected = selections[o.categoryId] === o.id;
                  const suggested = suggestions[o.categoryId] === o.id && !selected;
                  return (
                    <button
                      key={o.id}
                      className={`picker-row cat-${o.categoryId}${selected ? ' is-selected' : ''}${drag.draggingId === o.id ? ' is-dragging' : ''}`}
                      aria-pressed={selected}
                      onPointerDown={(e) => drag.onPointerDown(e, o)}
                      onClick={() => { if (drag.consumeClick()) return; onToggle(o.id, 'tap'); }}
                    >
                      <span className="picker-row__icon"><OptionIcon name={o.icon} size={16} /></span>
                      <span className="stack gap4 grow" style={{ minWidth: 0 }}>
                        <span className="picker-row__label">
                          {o.label}
                          {suggested ? <span className="filter-opt__sugg" aria-label="suggested from your profile" /> : null}
                        </span>
                        <span className="picker-row__desc">{o.blurb}</span>
                      </span>
                      <span className="picker-row__add" aria-hidden="true">
                        {selected ? <IconCheck size={13} /> : <IconPlus size={13} />}
                      </span>
                    </button>
                  );
                })}
              </section>
            ))}

            {!groups.length ? (
              <p className="small muted" style={{ padding: '18px 4px' }}>
                Nothing matches that. Try a word like “growth”, “debt”, “value” or “trend”.
              </p>
            ) : null}
          </div>
        </div>

        <div className="picker-foot">
          <span className="picker-foot__note small muted">
            {chosenCount} of {CATEGORIES.length} groups used · tap a filter, or drag it across
          </span>
          <Button variant="outline" onClick={onClearAll} disabled={!chosenCount}>Clear all</Button>
          <Button variant="primary" onClick={onClose}>Apply</Button>
        </div>
      </div>
      {drag.ghost}
    </>
  );
}

/* ------------------------------------------------------------ drag layer */

const LIFT = 5;          // px of movement before a press becomes a drag
const FOLLOW = 0.26;     // how quickly the ghost catches up with the pointer

/**
 * Dragging a filter onto the statement, animated by hand rather than by the
 * browser: the native drag image cannot be styled or eased, so the row is
 * lifted into a ghost that trails the pointer, tilts with its speed, and
 * either flies into the statement or springs back to where it came from.
 * Pointer drags are for mice only — on touch the list needs to scroll, and
 * tapping a row already adds it.
 */
function useFilterDrag(onToggle: (optionId: string, from: 'tap' | 'keyboard' | 'drop') => void) {
  const [dragging, setDragging] = useState<Option | null>(null);
  const ghostRef = useRef<HTMLDivElement | null>(null);
  const clickBlocked = useRef(false);
  const st = useRef<{
    option: Option; from: DOMRect; startX: number; startY: number;
    x: number; y: number; tx: number; ty: number; raf: number; live: boolean; over: boolean;
  } | null>(null);

  const clearFlags = () => {
    delete document.body.dataset.filterDrag;
    delete document.body.dataset.filterOver;
  };

  const frame = () => {
    const d = st.current;
    if (!d) return;
    const g = ghostRef.current;
    if (g) {
      const vx = d.tx - d.x;
      d.x += vx * FOLLOW;
      d.y += (d.ty - d.y) * FOLLOW;
      const tilt = Math.max(-9, Math.min(9, vx * 0.45));
      g.style.transform = `translate3d(${d.x}px, ${d.y}px, 0) rotate(${tilt}deg)`;
    }
    d.raf = requestAnimationFrame(frame);
  };

  const finish = (d: NonNullable<typeof st.current>, target: Element | null) => {
    cancelAnimationFrame(d.raf);
    const g = ghostRef.current;
    const done = () => { st.current = null; setDragging(null); clearFlags(); };
    if (g) {
      g.style.transition = 'transform 260ms cubic-bezier(.2,.75,.25,1), opacity 220ms ease';
      if (target) {
        const r = target.getBoundingClientRect();
        g.style.transform = `translate3d(${r.left + r.width / 2 - 30}px, ${r.top + r.height / 2 - 18}px, 0) scale(0.55)`;
        g.style.opacity = '0';
      } else {
        // nothing under the pointer: spring back to the row it came from
        g.style.transform = `translate3d(${d.from.left}px, ${d.from.top}px, 0) scale(0.92)`;
        g.style.opacity = '0';
      }
      window.setTimeout(done, 260);
    } else done();
    if (target) onToggle(d.option.id, 'drop');
  };

  const onPointerDown = (e: React.PointerEvent<HTMLButtonElement>, option: Option) => {
    if (e.pointerType !== 'mouse' || e.button !== 0) return;
    const row = e.currentTarget;
    const from = row.getBoundingClientRect();
    const startX = e.clientX;
    const startY = e.clientY;
    let started = false;

    const move = (ev: PointerEvent) => {
      if (!started) {
        if (Math.hypot(ev.clientX - startX, ev.clientY - startY) < LIFT) return;
        started = true;
        clickBlocked.current = true;
        document.body.dataset.filterDrag = '1';
        st.current = {
          option, from, startX, startY,
          x: ev.clientX - 26, y: ev.clientY - 20,
          tx: ev.clientX - 26, ty: ev.clientY - 20,
          raf: 0, live: true, over: false,
        };
        setDragging(option);
        st.current.raf = requestAnimationFrame(frame);
      }
      const d = st.current;
      if (!d) return;
      d.tx = ev.clientX - 26;
      d.ty = ev.clientY - 20;
      const el = document.elementFromPoint(ev.clientX, ev.clientY);
      const over = !!el?.closest('[data-drop="statement"]');
      if (over !== d.over) {
        d.over = over;
        if (over) document.body.dataset.filterOver = '1';
        else delete document.body.dataset.filterOver;
      }
    };

    const up = (ev: PointerEvent) => {
      document.removeEventListener('pointermove', move);
      document.removeEventListener('pointerup', up);
      const d = st.current;
      if (!started || !d) return;
      const el = document.elementFromPoint(ev.clientX, ev.clientY);
      finish(d, el?.closest('[data-drop="statement"]') ?? null);
    };

    document.addEventListener('pointermove', move);
    document.addEventListener('pointerup', up);
  };

  useEffect(() => () => { if (st.current) cancelAnimationFrame(st.current.raf); clearFlags(); }, []);

  const ghost = dragging ? (
    <div className={`drag-ghost cat-${dragging.categoryId}`} ref={ghostRef} aria-hidden="true">
      <OptionIcon name={dragging.icon} size={15} />
      <span>{dragging.chip}</span>
    </div>
  ) : null;

  return {
    ghost,
    draggingId: dragging?.id ?? null,
    onPointerDown,
    consumeClick: () => {
      if (!clickBlocked.current) return false;
      clickBlocked.current = false;
      return true;
    },
  };
}
