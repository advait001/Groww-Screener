import React, { useState } from 'react';
import type { IndicatorId } from '../data/config';
import { CATEGORIES, OPTION_BY_ID } from '../data/config';
import { FORMULAS, INDICATORS, formatIndicator } from '../data/indicators';
import { iconForIndicator, learnTitle } from '../data/learning';
import type { Stock } from '../data/stocks';
import { UNIVERSE, type Selections, filteringOptions } from '../engine/screener';
import { getIndicatorValue, indicatorsUsed, type RuleOutcome } from '../engine/rules';
import type { StockResult } from '../engine/screener';
import { Button, Modal, Tag } from './primitives';
import { IconBulb, IconCheckCircle, IconCrossCircle, IconInfo, IconMinusCircle, IconChevronRight, OptionIcon } from './icons';
import { LessonVisual } from './visuals';
import { track } from '../state/analytics';

/* ------------------------------------------------------------ rule lines */

const statusIcon = (o: RuleOutcome) => {
  if (o.status === 'pass') return <span className="pos"><IconCheckCircle /></span>;
  if (o.status === 'fail') return <span className="neg"><IconCrossCircle /></span>;
  return <span className="faint"><IconMinusCircle /></span>;
};

export function RuleLine({ outcome, onIndicator }: { outcome: RuleOutcome; onIndicator?: (id: IndicatorId) => void }) {
  const meta = INDICATORS[outcome.applied.indicator];
  return (
    <div className="rule-line">
      <span className="rule-line__icon">{statusIcon(outcome)}</span>
      <div className="check-row__body">
        <div>
          {onIndicator ? (
            <button className="link-btn" onClick={() => onIndicator(outcome.applied.indicator)}>{meta.name}</button>
          ) : <span style={{ color: 'var(--heading)' }}>{meta.name}</span>}
          {outcome.status === 'not-applicable' ? null : <> — <span className="rule-value mono-num">{outcome.valueText}</span></>}
        </div>
        <div className="rule-line__req">
          {outcome.status === 'not-applicable' ? 'Not used for this company' : `Needs ${outcome.requirementText}`}
        </div>
        {outcome.note ? <div className="rule-line__note">{outcome.note}</div> : null}
      </div>
    </div>
  );
}

/* ------------------------------------------------- translation of choices */

export function TranslationRows({ selections, onIndicator }: { selections: Selections; onIndicator: (id: IndicatorId) => void }) {
  const options = filteringOptions(selections);
  if (!options.length) {
    return <p className="muted small">Pick at least one preference and the financial checks behind it will show up here.</p>;
  }
  return (
    <div className="xlate">
      {options.map((option) => {
        const lender = option.rules.find((r) => r.lenderPolicy);
        return (
          <section className={`xlate__card cat-${option.categoryId}`} key={option.id}>
            <header className="xlate__head">
              <span className="xlate__chip"><OptionIcon name={option.icon} size={14} /> {option.chip}</span>
              <span className="xlate__count">{option.rules.length} {option.rules.length === 1 ? 'check' : 'checks'}</span>
            </header>
            <ul className="xlate__checks">
              {option.rules.map((rule) => (
                <li key={rule.id}>
                  <button className="xlate__check"
                    onClick={() => { track('indicator_lesson_opened', { indicator: rule.indicator, from: 'translation' }); onIndicator(rule.indicator); }}>
                    <span className="xlate__check-name">{INDICATORS[rule.indicator].name}</span>
                    <span className="xlate__check-req">{rule.requirement}</span>
                    <IconChevronRight size={15} />
                  </button>
                </li>
              ))}
            </ul>
            {lender ? (
              <p className="xlate__note">Banks and lenders are checked differently.</p>
            ) : null}
            {option.caveat ? (
              <p className="xlate__caveat"><IconInfo size={14} /> <span>{option.caveat}</span></p>
            ) : null}
          </section>
        );
      })}
    </div>
  );
}

/* --------------------------------------------------- why a stock matched */

export function MatchExplanation({ result, onIndicator }: { result: StockResult; onIndicator: (id: IndicatorId) => void }) {
  const { stock, conditions } = result;
  return (
    <div>
      <div className="row gap8 wrap" style={{ marginBottom: 14 }}>
        <span className={`match${result.exact ? '' : ' match--partial'}`}>
          {result.matchedCount} of {result.filterCount} conditions matched
        </span>
        <Tag>{stock.sector}</Tag>
        <Tag tone="amber">Demo data</Tag>
      </div>
      {conditions.map((c) => (
        <div className="match-block" key={c.option.id}>
          <div className="match-block__head">
            <div className="stack gap4">
              <span className="label-caps">Your condition · {c.categoryLabel}</span>
              <strong style={{ color: 'var(--heading)', fontWeight: 500 }}>{c.option.label}</strong>
            </div>
            <span className={`tag${c.matched ? ' tag--green' : ' tag--red'}`}>{c.matched ? 'Matched' : 'Did not match'}</span>
          </div>
          <div className="stack gap12">
            {c.outcomes.map((o, i) => <RuleLine key={i} outcome={o} onIndicator={onIndicator} />)}
          </div>
          {!c.matched ? (
            <p className="small muted">
              {c.outcomes.some((o) => o.status === 'no-data')
                ? 'A figure this condition needs is missing, and missing data never counts as a pass.'
                : 'This company clears the rest of this condition but not every part of it.'}
            </p>
          ) : null}
          {c.option.caveat ? <p className="small faint">{c.option.caveat}</p> : null}
        </div>
      ))}
    </div>
  );
}

/* ------------------------------------------------------- indicators used */

export function IndicatorsUsed({ selections, sample, onIndicator }: {
  selections: Selections; sample?: Stock; onIndicator: (id: IndicatorId) => void;
}) {
  const ids = indicatorsUsed(filteringOptions(selections).map((o) => o.id));
  if (!ids.length) return <p className="muted small">No conditions are active, so no indicators were used.</p>;
  return (
    <div className="stack">
      <p className="small muted" style={{ marginBottom: 12 }}>
        These {ids.length} indicators did the filtering. Open any of them to see what it means, why this screen used it and where it can mislead.
      </p>
      {ids.map((id, i) => {
        const meta = INDICATORS[id];
        const value = sample ? getIndicatorValue(sample, id) : null;
        return (
          <button key={id} className="card__row" style={{ borderTop: i ? '1px solid var(--border)' : '1px solid var(--border)' }}
            onClick={() => { track('indicator_lesson_opened', { indicator: id, from: 'indicators_used' }); onIndicator(id); }}>
            <span className="stack gap4">
              <span style={{ color: 'var(--heading)' }}>{meta.name}</span>
              <span className="small muted">{meta.technicalName ?? meta.name}</span>
            </span>
            <span className="row gap8">
              {sample ? <span className="small mono-num muted">{formatIndicator(id, value)}</span> : null}
              <IconChevronRight />
            </span>
          </button>
        );
      })}
    </div>
  );
}

/* ---------------------------------------------------------- lesson modal */

export function LessonModal({ indicatorId, stock, selections, onClose }: {
  indicatorId: IndicatorId; stock?: Stock; selections: Selections; onClose: () => void;
}) {
  const [deeper, setDeeper] = useState(false);
  const meta = INDICATORS[indicatorId];
  const value = stock ? getIndicatorValue(stock, indicatorId) : null;

  // why this screen used it: taken from the rule that introduced it
  const owner = filteringOptions(selections).find((o) =>
    o.rules.some((r) => r.indicator === indicatorId || r.substitute?.indicator === indicatorId));
  const rule = owner?.rules.find((r) => r.indicator === indicatorId || r.substitute?.indicator === indicatorId);

  const peer = indicatorId === 'pe' ? (stock ? UNIVERSE.median('pe', stock.sector) : null)
    : indicatorId === 'pb' ? (stock ? UNIVERSE.median('pb', stock.sector) : null) : null;

  return (
    <Modal
      title={meta.name}
      subtitle={meta.technicalName && meta.technicalName !== meta.name ? `Called ${meta.technicalName} in the market` : undefined}
      onClose={onClose}
      footer={<Button variant="primary" className="grow" onClick={onClose}>Got it</Button>}
    >
      <div className="lesson">
        <p className="lesson__lead">{meta.what}</p>

        {stock ? (
          <>
            <div className="lesson__visual">
              <LessonVisual kind={meta.visual} value={value} stock={stock} peer={peer}
                unit={indicatorId === 'roe' || indicatorId === 'roce' ? '%' : ''} />
            </div>
            <div className="lesson__applied">
              <strong style={{ fontWeight: 500 }}>{stock.name}:</strong>{' '}
              {value === null
                ? 'not reported, so any rule using it could not pass.'
                : <><span className="mono-num">{formatIndicator(indicatorId, value)}</span>
                  {peer ? <> against a peer median of <span className="mono-num">{peer.toFixed(1)}x</span></> : null}</>}
            </div>
          </>
        ) : null}

        <div className="lesson__facts">
          <p className="lesson__fact">
            <span className="lesson__fact-icon tone-blue"><IconBulb size={15} /></span>
            <span><b>Read it</b> {meta.read}</span>
          </p>
          <p className="lesson__fact">
            <span className="lesson__fact-icon tone-amber"><IconInfo size={15} /></span>
            <span><b>Careful</b> {meta.limitation}</span>
          </p>
        </div>

        {rule && owner ? (
          <p className="lesson__why">
            Checked because you picked <b>{owner.label}</b>, which asks for {rule.requirement}.
          </p>
        ) : null}

        <div className="lesson__more">
          <button className="link-btn" onClick={() => setDeeper((d) => !d)}>
            {deeper ? 'Hide the maths' : 'How the number is worked out'}
          </button>
          {deeper ? (
            <p className="small muted" style={{ marginTop: 6 }}>
              {FORMULAS[indicatorId] ?? 'Calculated from the company’s reported figures.'}{' '}
              Every figure here is invented demo data, so read the value as an illustration of the method.
            </p>
          ) : null}
        </div>
      </div>
    </Modal>
  );
}

/**
 * What one preference means, and the checks behind it — kept to a short lead
 * line and one row per check. Anything longer lives in the indicator lesson,
 * which each row opens.
 */
export function OptionExplainer({ optionId, selections, selected, onToggle, onIndicator, onClose }: {
  optionId: string;
  selections: Selections;
  selected?: boolean;
  onToggle?: (optionId: string) => void;
  onIndicator: (id: IndicatorId) => void;
  onClose: () => void;
}) {
  const option = OPTION_BY_ID[optionId];
  if (!option) return null;
  const category = CATEGORIES.find((c) => c.id === option.categoryId);
  const usesLenderRule = option.rules.some((r) => r.lenderPolicy);

  return (
    <Modal
      title={option.label}
      subtitle={`${category?.label ?? ''} · ${option.rules.length
        ? `${option.rules.length} ${option.rules.length === 1 ? 'check' : 'checks'}`
        : 'no filter applied'}`}
      onClose={onClose}
      footer={
        <>
          {onToggle ? (
            <Button variant={selected ? 'outline' : 'tint'}
              onClick={() => { onToggle(optionId); onClose(); }}>
              {selected ? 'Remove from my screen' : 'Add to my screen'}
            </Button>
          ) : null}
          <Button variant="primary" className="grow" onClick={onClose}>Okay</Button>
        </>
      }
    >
      <div className="opt-modal">
        <div className={`opt-modal__head cat-${option.categoryId}`}>
          <span className="opt-modal__icon"><OptionIcon name={option.icon} size={20} /></span>
          <p className="opt-modal__lead">{option.summary}</p>
        </div>

        {option.rules.length ? (
          <>
            <span className="label-caps">What Groww checks</span>
            <div className="check-list">
              {option.rules.map((rule) => (
                <button className="check-item" key={rule.id}
                  onClick={() => { track('indicator_lesson_opened', { indicator: rule.indicator, from: 'option_explainer' }); onIndicator(rule.indicator); }}>
                  <span className="check-item__icon"><OptionIcon name={iconForIndicator(rule.indicator)} size={16} /></span>
                  <span className="stack gap4 grow" style={{ minWidth: 0 }}>
                    <b>{learnTitle(rule.indicator)}</b>
                    <span className="small muted">{rule.requirement}</span>
                  </span>
                  <IconChevronRight size={14} />
                </button>
              ))}
            </div>
          </>
        ) : (
          <p className="small muted">This one applies no filter. It is here for when you have no view on this area.</p>
        )}

        {usesLenderRule ? (
          <p className="tiny faint">Banks and lenders are checked differently — a capital buffer stands in for debt.</p>
        ) : null}

        {option.caveat ? (
          <div className="opt-modal__note">
            <IconInfo size={14} />
            <span>{option.caveat}</span>
          </div>
        ) : null}
      </div>
    </Modal>
  );
}
