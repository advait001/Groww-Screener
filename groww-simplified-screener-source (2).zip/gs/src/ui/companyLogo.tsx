import React from 'react';
import type { Stock } from '../data/stocks';

/**
 * The companies in this prototype are fictional, so they have no real logos.
 * Each one gets its own generated mark instead: a fixed colour pair and shape,
 * so the same company always looks the same wherever it appears, and no real
 * company's trademark is used anywhere.
 */

interface Brand { c1: string; c2: string; shape: ShapeName }

type ShapeName =
  | 'square' | 'orbit' | 'twin' | 'hex' | 'chevrons' | 'leaf'
  | 'ring' | 'peaks' | 'diamond' | 'grid' | 'bolt' | 'arcs';

const BRAND: Record<string, Brand> = {
  'sundale-bank': { c1: '#0f4c9e', c2: '#e03b2f', shape: 'square' },
  'meridian-finserv': { c1: '#1f7a5a', c2: '#8fd6b4', shape: 'ring' },
  'arcus-bank': { c1: '#7b2d8b', c2: '#f0b429', shape: 'orbit' },

  'velora-software': { c1: '#1b4fd8', c2: '#5fd3f3', shape: 'hex' },
  'nexthorn-tech': { c1: '#0e9c8f', c2: '#7be0d3', shape: 'chevrons' },
  'quantile-systems': { c1: '#38487a', c2: '#9aa6d8', shape: 'grid' },

  'kesari-consumer': { c1: '#e2711d', c2: '#f6c453', shape: 'leaf' },
  'anantam-foods': { c1: '#2f9e44', c2: '#b2f2bb', shape: 'twin' },
  'pravan-dairy': { c1: '#1c7ed6', c2: '#a5d8ff', shape: 'arcs' },

  'zylix-pharma': { c1: '#0b7285', c2: '#63e6be', shape: 'diamond' },
  'hemadri-life': { c1: '#9c36b5', c2: '#e599f7', shape: 'leaf' },
  'saral-healthcare': { c1: '#495057', c2: '#ced4da', shape: 'square' },

  'bharatiya-motors': { c1: '#c92a2a', c2: '#ffa8a8', shape: 'chevrons' },
  'girnar-components': { c1: '#343a40', c2: '#adb5bd', shape: 'hex' },

  'shravasti-cements': { c1: '#5f3dc4', c2: '#b197fc', shape: 'peaks' },
  'deccan-ceramics': { c1: '#a15c07', c2: '#ffd8a8', shape: 'diamond' },

  'agnisar-power': { c1: '#e8590c', c2: '#ffc078', shape: 'bolt' },
  'tarangini-gas': { c1: '#1098ad', c2: '#99e9f2', shape: 'arcs' },

  'vistara-chemicals': { c1: '#2b8a3e', c2: '#8ce99a', shape: 'orbit' },
  'ridhima-polymers': { c1: '#6741d9', c2: '#d0bfff', shape: 'grid' },

  'ujjwal-appliances': { c1: '#d6336c', c2: '#ffc9c9', shape: 'bolt' },
  'ashvi-electricals': { c1: '#f08c00', c2: '#ffe066', shape: 'ring' },

  'neelkanth-retail': { c1: '#1864ab', c2: '#74c0fc', shape: 'twin' },
  'chandrika-mart': { c1: '#c2255c', c2: '#faa2c1', shape: 'square' },

  'mahasagar-metals': { c1: '#495057', c2: '#f59f00', shape: 'peaks' },
  'girija-steel': { c1: '#862e9c', c2: '#b197fc', shape: 'hex' },

  'suvarna-realty': { c1: '#087f5b', c2: '#f6c453', shape: 'peaks' },
  'meghdoot-estates': { c1: '#3b5bdb', c2: '#bac8ff', shape: 'diamond' },

  'konark-infra': { c1: '#e67700', c2: '#ffd43b', shape: 'chevrons' },
  'prithvi-logistics': { c1: '#0c8599', c2: '#66d9e8', shape: 'arcs' },
};

/** stable fallback, so a new company still gets a consistent mark */
function fallback(stock: Stock): Brand {
  // deterministic: the same company always gets the same mark
  let h = 0;
  for (let i = 0; i < stock.id.length; i++) h = (h * 31 + stock.id.charCodeAt(i)) >>> 0;
  const palette: [string, string][] = [
    ['#1864ab', '#a5d8ff'], ['#2b8a3e', '#b2f2bb'], ['#c92a2a', '#ffc9c9'],
    ['#6741d9', '#d0bfff'], ['#0b7285', '#99e9f2'], ['#e8590c', '#ffd8a8'],
    ['#5f3dc4', '#e5dbff'], ['#087f5b', '#96f2d7'], ['#a61e4d', '#fcc2d7'],
    ['#364fc7', '#bac8ff'], ['#846b00', '#ffec99'], ['#495057', '#dee2e6'],
  ];
  const shapes: ShapeName[] = [
    'square', 'orbit', 'twin', 'hex', 'chevrons', 'leaf',
    'ring', 'peaks', 'diamond', 'grid', 'bolt', 'arcs',
  ];
  // unsigned shifts throughout: a signed shift can go negative and land off the end
  const [c1, c2] = palette[h % palette.length];
  return { c1, c2, shape: shapes[(h >>> 5) % shapes.length] };
}

const SHAPES: Record<ShapeName, (b: Brand) => React.ReactNode> = {
  square: (b) => (
    <>
      <rect x="4" y="4" width="40" height="40" rx="7" fill={b.c1} />
      <rect x="14" y="14" width="20" height="20" rx="3" fill="#fff" />
      <rect x="20" y="20" width="8" height="8" rx="1.5" fill={b.c2} />
    </>
  ),
  orbit: (b) => (
    <>
      <circle cx="24" cy="24" r="20" fill={b.c1} />
      <path d="M24 4a20 20 0 0114 34" stroke="#fff" strokeWidth="5" fill="none" strokeLinecap="round" />
      <circle cx="24" cy="24" r="7.5" fill={b.c2} />
    </>
  ),
  twin: (b) => (
    <>
      <circle cx="17" cy="24" r="13" fill={b.c1} />
      <circle cx="32" cy="24" r="14" fill="#fff" />
      <circle cx="32" cy="24" r="11" fill={b.c2} />
    </>
  ),
  hex: (b) => (
    <>
      <path d="M24 3l18 10.5v21L24 45 6 34.5v-21z" fill={b.c1} />
      <path d="M24 13l9 5.2v10.6L24 34l-9-5.2V18.2z" fill={b.c2} />
    </>
  ),
  chevrons: (b) => (
    <>
      <path d="M8 30l16-16 16 16" stroke={b.c1} strokeWidth="7" fill="none" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M8 41l16-16 16 16" stroke={b.c2} strokeWidth="6" fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </>
  ),
  leaf: (b) => (
    <>
      <path d="M24 5c11 7 15 15 15 22a15 15 0 01-30 0c0-7 4-15 15-22z" fill={b.c1} />
      <path d="M24 15v19" stroke="#fff" strokeWidth="3.4" strokeLinecap="round" />
      <path d="M24 24l7-6M24 30l-7-6" stroke="#fff" strokeWidth="2.6" strokeLinecap="round" opacity="0.9" />
      <circle cx="24" cy="10" r="3" fill={b.c2} />
    </>
  ),
  ring: (b) => (
    <>
      <circle cx="24" cy="24" r="17" stroke={b.c1} strokeWidth="8" fill="none" strokeDasharray="78 25" strokeLinecap="round" transform="rotate(-40 24 24)" />
      <circle cx="24" cy="24" r="6" fill={b.c2} />
    </>
  ),
  peaks: (b) => (
    <>
      <path d="M4 42L18 16l10 18z" fill={b.c2} />
      <path d="M20 42L32 12l14 30z" fill={b.c1} />
    </>
  ),
  diamond: (b) => (
    <>
      <rect x="10" y="10" width="28" height="28" rx="6" transform="rotate(45 24 24)" fill={b.c1} />
      <path d="M16 24h16" stroke="#fff" strokeWidth="5" strokeLinecap="round" />
      <circle cx="24" cy="24" r="3" fill={b.c2} />
    </>
  ),
  grid: (b) => (
    <>
      <rect x="6" y="6" width="16" height="16" rx="4" fill={b.c1} />
      <rect x="26" y="6" width="16" height="16" rx="4" fill={b.c2} />
      <rect x="6" y="26" width="16" height="16" rx="4" fill={b.c2} />
      <rect x="26" y="26" width="16" height="16" rx="4" fill={b.c1} />
    </>
  ),
  bolt: (b) => (
    <>
      <rect x="4" y="4" width="40" height="40" rx="12" fill={b.c1} />
      <path d="M27 9l-14 18h8l-3 12 14-18h-8z" fill="#fff" />
      <circle cx="36" cy="12" r="3.5" fill={b.c2} />
    </>
  ),
  arcs: (b) => (
    <>
      <path d="M10 36a14 14 0 0128 0" stroke={b.c1} strokeWidth="6" fill="none" strokeLinecap="round" />
      <path d="M4 36a20 20 0 0140 0" stroke={b.c2} strokeWidth="5" fill="none" strokeLinecap="round" opacity="0.85" />
      <circle cx="24" cy="36" r="4" fill={b.c1} />
    </>
  ),
};

export function CompanyLogo({ stock, size = 36 }: { stock: Stock; size?: number }) {
  const known = BRAND[stock.id];
  const brand = known && SHAPES[known.shape] ? known : fallback(stock);
  const inner = Math.round(size * 0.68);
  return (
    <span className="co-logo" style={{ width: size, height: size, borderRadius: Math.round(size * 0.28) }}>
      <svg viewBox="0 0 48 48" width={inner} height={inner} role="img" aria-label={`${stock.name} logo`}>
        {SHAPES[brand.shape](brand)}
      </svg>
    </span>
  );
}
