import React, { useEffect, useRef, useState } from 'react';
import { IconCheck, IconChevronDown, IconClose } from './icons';

/* --------------------------------------------------------------- button */

type BtnVariant = 'primary' | 'outline' | 'tint' | 'ghost' | 'neutral';
interface BtnProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: BtnVariant;
  size?: 'md' | 'sm' | 'xs';
  block?: boolean;
}

export function Button({ variant = 'neutral', size = 'md', block, className = '', ...rest }: BtnProps) {
  const cls = [
    'btn',
    variant !== 'neutral' ? `btn--${variant}` : '',
    size === 'sm' ? 'btn--sm' : size === 'xs' ? 'btn--xs' : '',
    block ? 'btn--block' : '',
    className,
  ].filter(Boolean).join(' ');
  return <button type="button" className={cls} {...rest} />;
}

/* ----------------------------------------------------------------- chip */

interface ChipProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  selected?: boolean;
  count?: number;
  as?: 'button' | 'span';
}

export function Chip({ selected, count, as = 'button', className = '', children, ...rest }: ChipProps) {
  const cls = ['chip', selected ? 'is-selected' : '', as === 'span' ? 'chip--static' : '', className].filter(Boolean).join(' ');
  const body = (
    <>
      {children}
      {typeof count === 'number' && count > 0 ? <span className="chip__count">{count}</span> : null}
    </>
  );
  if (as === 'span') return <span className={cls}>{body}</span>;
  return <button type="button" className={cls} aria-pressed={selected} {...rest}>{body}</button>;
}

export const Tag = ({ tone = 'neutral', children }: { tone?: 'neutral' | 'green' | 'red' | 'blue' | 'amber'; children: React.ReactNode }) => (
  <span className={`tag${tone === 'neutral' ? '' : ` tag--${tone}`}`}>{children}</span>
);

/* ---------------------------------------------------------------- radio */

export function RadioRow({ selected, label, note, onClick }: { selected: boolean; label: string; note?: string; onClick: () => void }) {
  return (
    <button type="button" className={`choice${selected ? ' is-selected' : ''}`} role="radio" aria-checked={selected} onClick={onClick}>
      <span className="radio" aria-hidden="true" />
      <span className="stack">
        <span>{label}</span>
        {note ? <span className="small muted">{note}</span> : null}
      </span>
    </button>
  );
}

/* ------------------------------------------------------- overlay plumbing */

function useDismiss(onClose: () => void) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prev;
    };
  }, [onClose]);
}

function useAutoFocus<T extends HTMLElement>() {
  const ref = useRef<T | null>(null);
  useEffect(() => { ref.current?.focus(); }, []);
  return ref;
}

interface PanelProps {
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  onClose: () => void;
  footer?: React.ReactNode;
  children: React.ReactNode;
  labelledBy?: string;
}

/** Side drawer on desktop, bottom sheet on small screens (see app.css). */
export function Drawer({ title, subtitle, onClose, footer, children, wide }: PanelProps & { wide?: boolean }) {
  useDismiss(onClose);
  const ref = useAutoFocus<HTMLDivElement>();
  return (
    <>
      <div className="overlay" onClick={onClose} />
      <div className={`drawer${wide ? ' drawer--wide' : ''}`} role="dialog" aria-modal="true" aria-label={typeof title === 'string' ? title : 'Details'} tabIndex={-1} ref={ref}>
        <div className="drawer__head">
          <div className="stack gap4">
            <h2>{title}</h2>
            {subtitle ? <div className="small muted">{subtitle}</div> : null}
          </div>
          <button type="button" className="close-btn" onClick={onClose} aria-label="Close"><IconClose /></button>
        </div>
        <div className="drawer__body">{children}</div>
        {footer ? <div className="drawer__foot">{footer}</div> : null}
      </div>
    </>
  );
}

export function Modal({ title, subtitle, onClose, footer, children }: PanelProps) {
  useDismiss(onClose);
  const ref = useAutoFocus<HTMLDivElement>();
  return (
    <>
      <div className="overlay" onClick={onClose} />
      <div className="modal" role="dialog" aria-modal="true" aria-label={typeof title === 'string' ? title : 'Dialog'} tabIndex={-1} ref={ref}>
        <div className="modal__head">
          <div className="stack gap4">
            <h2>{title}</h2>
            {subtitle ? <div className="small muted">{subtitle}</div> : null}
          </div>
          <button type="button" className="close-btn" onClick={onClose} aria-label="Close"><IconClose /></button>
        </div>
        <div className="modal__body">{children}</div>
        {footer ? <div className="modal__foot">{footer}</div> : null}
      </div>
    </>
  );
}

/* ----------------------------------------------------------------- menu */

export interface MenuOption<T extends string> { value: T; label: string }

/**
 * A small listbox styled like the rest of the app. A native <select> renders
 * OS chrome that ignores the theme, which looked out of place on dark.
 */
export function SelectMenu<T extends string>({ value, options, onChange, icon, label, align = 'end' }: {
  value: T;
  options: MenuOption<T>[];
  onChange: (value: T) => void;
  icon?: React.ReactNode;
  label?: string;
  align?: 'start' | 'end';
}) {
  const [open, setOpen] = useState(false);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const listRef = useRef<HTMLDivElement | null>(null);
  const current = options.find((o) => o.value === value);

  useEffect(() => {
    if (!open) return undefined;
    const onDown = (e: MouseEvent) => {
      if (!wrapRef.current?.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    listRef.current?.querySelector<HTMLButtonElement>('[aria-selected="true"]')?.focus();
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const onListKey = (e: React.KeyboardEvent) => {
    if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return;
    e.preventDefault();
    const items = Array.from(listRef.current?.querySelectorAll<HTMLButtonElement>('.menu__item') ?? []);
    const at = items.indexOf(document.activeElement as HTMLButtonElement);
    const next = e.key === 'ArrowDown' ? at + 1 : at - 1;
    items[Math.max(0, Math.min(items.length - 1, next))]?.focus();
  };

  return (
    <div className="menu" ref={wrapRef}>
      <button type="button" className={`chip menu__trigger${open ? ' is-selected' : ''}`}
        aria-haspopup="listbox" aria-expanded={open} onClick={() => setOpen((o) => !o)}>
        {icon}
        {label ? <span className="muted">{label}</span> : null}
        <span className="menu__value">{current?.label}</span>
        <IconChevronDown size={14} />
      </button>
      {open ? (
        <div className={`menu__list menu__list--${align}`} role="listbox" ref={listRef} onKeyDown={onListKey}>
          {options.map((o) => {
            const selected = o.value === value;
            return (
              <button type="button" key={o.value} role="option" aria-selected={selected}
                className={`menu__item${selected ? ' is-selected' : ''}`}
                onClick={() => { onChange(o.value); setOpen(false); }}>
                {o.label}
                {selected ? <IconCheck size={14} /> : null}
              </button>
            );
          })}
        </div>
      ) : null}
    </div>
  );
}

/* ---------------------------------------------------------------- toast */

export function Toast({ message, onDone }: { message: string; onDone: () => void }) {
  useEffect(() => {
    const t = setTimeout(onDone, 2600);
    return () => clearTimeout(t);
  }, [message, onDone]);
  return <div className="toast" role="status">{message}</div>;
}

export const Skeleton = ({ width = '100%', height = 14 }: { width?: number | string; height?: number }) => (
  <div className="skeleton" style={{ width, height }} />
);
