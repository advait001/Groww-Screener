import React from 'react';
import type { VisualKind } from '../data/indicators';
import type { Stock } from '../data/stocks';
import { priceSeries } from '../data/stocks';

const W = 300;
const H = 120;

const text = (x: number, y: number, s: string, anchor: 'start' | 'middle' | 'end' = 'middle', fill = 'var(--text-2)', size = 11) => (
  <text x={x} y={y} textAnchor={anchor} fill={fill} fontSize={size} fontFamily="inherit">{s}</text>
);

function RsiGauge({ value }: { value: number }) {
  const x = 20 + (value / 100) * (W - 40);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H} role="img" aria-label={`RSI of ${value.toFixed(0)} on a scale of 0 to 100`}>
      <rect x="20" y="52" width={(W - 40) * 0.3} height="10" rx="5" fill="var(--red-tint)" />
      <rect x={20 + (W - 40) * 0.3} y="52" width={(W - 40) * 0.4} height="10" fill="var(--bg-3)" />
      <rect x={20 + (W - 40) * 0.7} y="52" width={(W - 40) * 0.3} height="10" rx="5" fill="var(--green-tint)" />
      <line x1={x} y1="42" x2={x} y2="72" stroke="var(--heading)" strokeWidth="2.5" strokeLinecap="round" />
      {text(x, 34, value.toFixed(0), 'middle', 'var(--heading)', 13)}
      {text(20, 82, '0', 'start')}
      {text(20 + (W - 40) * 0.3, 82, '30 oversold', 'middle')}
      {text(20 + (W - 40) * 0.7, 82, '70 overbought', 'middle')}
      {text(W - 20, 82, '100', 'end')}
      {text(W / 2, 104, 'A description of recent moves, not a prediction', 'middle', 'var(--text-3)')}
    </svg>
  );
}

function PeerBars({ value, peer, label }: { value: number; peer: number | null; label: string }) {
  const max = Math.max(value, peer ?? value) * 1.25 || 1;
  const bar = (v: number, x: number, colour: string, caption: string) => {
    const h = (v / max) * 68;
    return (
      <g>
        <rect x={x} y={78 - h} width="46" height={h} rx="4" fill={colour} />
        {text(x + 23, 74 - h, `${v.toFixed(1)}x`, 'middle', 'var(--heading)', 12)}
        {text(x + 23, 94, caption, 'middle')}
      </g>
    );
  };
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H} role="img" aria-label={`${label} of ${value.toFixed(1)} against a peer median of ${peer?.toFixed(1) ?? 'not available'}`}>
      <line x1="20" y1="78" x2={W - 20} y2="78" stroke="var(--border)" />
      {bar(value, 74, 'var(--green)', 'This company')}
      {peer !== null ? bar(peer, 160, 'var(--border-2)', 'Sector peers') : text(183, 60, 'No peer data', 'middle')}
      {text(W / 2, 112, 'Valuation only means something next to something else', 'middle', 'var(--text-3)')}
    </svg>
  );
}

function GrowthBars({ value }: { value: number }) {
  const bars = [1, 1 + value / 100, (1 + value / 100) ** 2, (1 + value / 100) ** 3];
  const max = Math.max(...bars);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H} role="img" aria-label={`Growth of ${value.toFixed(1)}% a year compounding over three years`}>
      <line x1="20" y1="86" x2={W - 20} y2="86" stroke="var(--border)" />
      {bars.map((b, i) => {
        const h = (b / max) * 66;
        const x = 34 + i * 62;
        return (
          <g key={i}>
            <rect x={x} y={86 - h} width="40" height={h} rx="4" fill={i === bars.length - 1 ? 'var(--green)' : 'var(--bg-3)'} />
            {text(x + 20, 100, i === 0 ? 'Year 0' : `Year ${i}`, 'middle')}
          </g>
        );
      })}
      {text(W / 2, 22, `${value.toFixed(1)}% a year, compounding`, 'middle', 'var(--heading)', 12)}
      {text(W / 2, 114, 'The same rate repeated, not a forecast', 'middle', 'var(--text-3)')}
    </svg>
  );
}

function VolatilitySpread({ value }: { value: number }) {
  const spread = Math.min(46, value * 1.1);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H} role="img" aria-label={`Yearly price swings of about ${value.toFixed(1)} percent`}>
      <line x1="20" y1="60" x2={W - 20} y2="60" stroke="var(--border)" strokeDasharray="3 3" />
      <rect x={W / 2 - spread * 2} y={60 - spread / 2} width={spread * 4} height={spread} rx="6" fill="var(--green-tint)" />
      <line x1={W / 2 - spread * 2} y1="60" x2={W / 2 + spread * 2} y2="60" stroke="var(--green-text)" strokeWidth="2" />
      {text(W / 2, 30, `About ${value.toFixed(0)}% swing range over a year`, 'middle', 'var(--heading)', 12)}
      {text(W / 2, 106, 'A calm year can be followed by a rough one', 'middle', 'var(--text-3)')}
    </svg>
  );
}

function MovingAverage({ stock }: { stock: Stock }) {
  const series = priceSeries(stock, 40);
  const min = Math.min(...series);
  const max = Math.max(...series);
  const span = max - min || 1;
  const pts = series.map((v, i) => [20 + (i / (series.length - 1)) * (W - 40), 92 - ((v - min) / span) * 60]);
  const avg = series.map((_, i) => {
    const from = Math.max(0, i - 6);
    const slice = series.slice(from, i + 1);
    return slice.reduce((a, b) => a + b, 0) / slice.length;
  });
  const avgPts = avg.map((v, i) => [20 + (i / (avg.length - 1)) * (W - 40), 92 - ((v - min) / span) * 60]);
  const path = (p: number[][]) => p.map((q, i) => `${i === 0 ? 'M' : 'L'}${q[0].toFixed(1)} ${q[1].toFixed(1)}`).join(' ');
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H} role="img" aria-label="Price line against its smoothed average">
      <path d={path(pts)} fill="none" stroke="var(--green-text)" strokeWidth="1.8" />
      <path d={path(avgPts)} fill="none" stroke="var(--text-3)" strokeWidth="1.6" strokeDasharray="4 3" />
      {text(24, 20, 'Price', 'start', 'var(--green-text)')}
      {text(64, 20, 'Average', 'start', 'var(--text-3)')}
      {text(W / 2, 114, 'The average follows the price, so it confirms late', 'middle', 'var(--text-3)')}
    </svg>
  );
}

function RatioBar({ value, cap, unit }: { value: number; cap: number; unit: string }) {
  const pct = Math.max(0.02, Math.min(1, value / cap));
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H} role="img" aria-label={`Value of ${value} ${unit}`}>
      <rect x="20" y="54" width={W - 40} height="12" rx="6" fill="var(--bg-3)" />
      <rect x="20" y="54" width={(W - 40) * pct} height="12" rx="6" fill="var(--green)" />
      {text(W / 2, 40, `${value.toFixed(1)}${unit}`, 'middle', 'var(--heading)', 13)}
      {text(20, 84, '0', 'start')}
      {text(W - 20, 84, `${cap}${unit}`, 'end')}
    </svg>
  );
}

function Coverage({ value }: { value: number }) {
  const n = Math.max(1, Math.min(8, Math.round(value)));
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H} role="img" aria-label={`Profit covers interest about ${value.toFixed(1)} times`}>
      <rect x="22" y="54" width="26" height="26" rx="4" fill="var(--red-tint)" stroke="var(--red)" />
      {text(35, 96, 'Interest', 'middle')}
      {Array.from({ length: n }).map((_, i) => (
        <rect key={i} x={72 + i * 26} y="54" width="20" height="26" rx="4" fill="var(--green-tint)" stroke="var(--green-text)" />
      ))}
      {text(W / 2 + 20, 40, `Profit covers it about ${value.toFixed(1)}x over`, 'middle', 'var(--heading)', 12)}
      {text(W / 2, 114, 'One good year can flatter a cyclical business', 'middle', 'var(--text-3)')}
    </svg>
  );
}

function Consistency({ value }: { value: number }) {
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H} role="img" aria-label={`Profit grew in ${value} of the last four years`}>
      {[0, 1, 2, 3].map((i) => {
        const on = i < value;
        return (
          <g key={i}>
            <rect x={38 + i * 58} y="46" width="44" height="30" rx="6"
              fill={on ? 'var(--green-tint)' : 'var(--bg-3)'} stroke={on ? 'var(--green-text)' : 'var(--border-2)'} />
            {text(60 + i * 58, 66, on ? 'Up' : 'Flat', 'middle', on ? 'var(--green-text)' : 'var(--text-3)', 12)}
            {text(60 + i * 58, 92, `Y${i + 1}`, 'middle')}
          </g>
        );
      })}
      {text(W / 2, 28, `${value} of the last 4 years`, 'middle', 'var(--heading)', 12)}
    </svg>
  );
}

function Returns({ stock }: { stock: Stock }) {
  const rows: [string, number | null][] = [['1 year', stock.return1Y], ['3 years a year', stock.return3Y], ['Worst fall', stock.maxDrawdown1Y]];
  const max = 70;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H} role="img" aria-label="Past returns and the worst fall in the last year">
      <line x1={W / 2} y1="18" x2={W / 2} y2="104" stroke="var(--border)" />
      {rows.map(([label, v], i) => {
        const y = 28 + i * 28;
        if (v === null) return <g key={label}>{text(W / 2, y + 10, `${label}: no data`, 'middle')}</g>;
        const w = (Math.min(Math.abs(v), max) / max) * (W / 2 - 30);
        const x = v >= 0 ? W / 2 : W / 2 - w;
        return (
          <g key={label}>
            <rect x={x} y={y} width={w} height="14" rx="3" fill={v >= 0 ? 'var(--green)' : 'var(--red)'} opacity="0.85" />
            {text(v >= 0 ? W / 2 - 6 : W / 2 + 6, y + 11, label, v >= 0 ? 'end' : 'start')}
            {text(v >= 0 ? x + w + 6 : x - 6, y + 11, `${v > 0 ? '+' : ''}${v.toFixed(1)}%`, v >= 0 ? 'start' : 'end', 'var(--heading)', 11)}
          </g>
        );
      })}
    </svg>
  );
}

export function LessonVisual({ kind, value, stock, peer, unit = '' }: {
  kind: VisualKind; value: number | null; stock: Stock; peer?: number | null; unit?: string;
}) {
  if (value === null) {
    return <div className="small muted">No value available for this company, so there is nothing to draw here.</div>;
  }
  switch (kind) {
    case 'rsi': return <RsiGauge value={value} />;
    case 'peerBars': return <PeerBars value={value} peer={peer ?? null} label="Ratio" />;
    case 'growthBars': return <GrowthBars value={value} />;
    case 'volatilitySpread': return <VolatilitySpread value={value} />;
    case 'movingAverage': return <MovingAverage stock={stock} />;
    case 'coverage': return <Coverage value={value} />;
    case 'consistency': return <Consistency value={value} />;
    case 'returns': return <Returns stock={stock} />;
    case 'ratioBar':
    default: {
      const cap = value <= 1 ? 2 : value <= 10 ? 15 : value <= 60 ? 80 : Math.ceil(value * 1.4);
      return <RatioBar value={value} cap={cap} unit={unit} />;
    }
  }
}
