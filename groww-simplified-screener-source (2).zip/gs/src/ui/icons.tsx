import React from 'react';
import type { IconName } from '../data/config';

interface P { size?: number; className?: string }

const wrap = (size: number, children: React.ReactNode, className?: string) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
    strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true">
    {children}
  </svg>
);

/* ----------------------------------------------------------- ui icons */

export const IconSearch = ({ size = 18 }: P) => wrap(size, <><circle cx="11" cy="11" r="7" /><path d="M20 20l-3.6-3.6" /></>);
export const IconBell = ({ size = 18 }: P) => wrap(size, <><path d="M6 9a6 6 0 1112 0c0 4 1.2 5.5 1.8 6H4.2C4.8 14.5 6 13 6 9z" /><path d="M10 19a2 2 0 004 0" /></>);
export const IconRefresh = ({ size = 18 }: P) => wrap(size, <><path d="M20 12a8 8 0 10-3 6.2" /><path d="M20 6v5h-5" /></>);
export const IconChevronDown = ({ size = 16 }: P) => wrap(size, <path d="M6 9.5l6 5 6-5" />);
export const IconChevronRight = ({ size = 16 }: P) => wrap(size, <path d="M9 6l6 6-6 6" />);
export const IconChevronLeft = ({ size = 16 }: P) => wrap(size, <path d="M15 6l-6 6 6 6" />);
export const IconClose = ({ size = 18 }: P) => wrap(size, <><path d="M6 6l12 12" /><path d="M18 6L6 18" /></>);
export const IconCheck = ({ size = 16 }: P) => wrap(size, <path d="M4 12.5l5 5L20 6.5" />);
export const IconCheckCircle = ({ size = 18 }: P) => wrap(size, <><circle cx="12" cy="12" r="9" /><path d="M8 12.5l2.6 2.6L16 9.5" /></>);
export const IconCrossCircle = ({ size = 18 }: P) => wrap(size, <><circle cx="12" cy="12" r="9" /><path d="M9 9l6 6" /><path d="M15 9l-6 6" /></>);
export const IconMinusCircle = ({ size = 18 }: P) => wrap(size, <><circle cx="12" cy="12" r="9" /><path d="M8.5 12h7" /></>);
export const IconInfo = ({ size = 16 }: P) => wrap(size, <><circle cx="12" cy="12" r="9" /><path d="M12 11v5" /><path d="M12 8h.01" /></>);
export const IconFilter = ({ size = 18 }: P) => wrap(size, <><path d="M4 7h16" /><path d="M7 12h10" /><path d="M10 17h4" /></>);
export const IconSort = ({ size = 14 }: P) => wrap(size, <><path d="M8 4v16" /><path d="M5 8l3-4 3 4" /><path d="M16 20V4" /><path d="M13 16l3 4 3-4" /></>);
export const IconBookmark = ({ size = 18 }: P) => wrap(size, <path d="M7 4h10v16l-5-4-5 4z" />);
export const IconChart = ({ size = 18 }: P) => wrap(size, <><path d="M4 19h16" /><path d="M7 16V9" /><path d="M12 16V5" /><path d="M17 16v-4" /></>);
export const IconSun = ({ size = 18 }: P) => wrap(size, <><circle cx="12" cy="12" r="4" /><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M18.4 5.6L17 7M7 17l-1.4 1.4" /></>);
export const IconMoon = ({ size = 18 }: P) => wrap(size, <path d="M20 14.5A8 8 0 019.5 4a8 8 0 1010.5 10.5z" />);
export const IconDrag = ({ size = 16 }: P) => wrap(size, <><circle cx="9" cy="7" r="1" /><circle cx="15" cy="7" r="1" /><circle cx="9" cy="12" r="1" /><circle cx="15" cy="12" r="1" /><circle cx="9" cy="17" r="1" /><circle cx="15" cy="17" r="1" /></>);
export const IconBook = ({ size = 18 }: P) => wrap(size, <><path d="M4 5.5A1.5 1.5 0 015.5 4H11v16H5.5A1.5 1.5 0 014 18.5z" /><path d="M20 5.5A1.5 1.5 0 0018.5 4H13v16h5.5A1.5 1.5 0 0020 18.5z" /></>);
export const IconSave = ({ size = 18 }: P) => wrap(size, <><path d="M5 5h11l3 3v11H5z" /><path d="M9 5v5h6" /><path d="M8 19v-5h8v5" /></>);
export const IconTrash = ({ size = 16 }: P) => wrap(size, <><path d="M5 7h14" /><path d="M9 7V5h6v2" /><path d="M6.5 7l.8 12h9.4l.8-12" /></>);
export const IconEdit = ({ size = 16 }: P) => wrap(size, <><path d="M5 19h3l10-10-3-3L5 16z" /><path d="M14.5 6.5l3 3" /></>);
export const IconPlay = ({ size = 16 }: P) => wrap(size, <path d="M8 5l11 7-11 7z" />);
export const IconArrowDown = ({ size = 16 }: P) => wrap(size, <><path d="M12 4v15" /><path d="M7 14l5 5 5-5" /></>);
export const IconUser = ({ size = 16 }: P) => wrap(size, <><circle cx="12" cy="8.5" r="3.6" /><path d="M5 20c.8-4 3.6-6 7-6s6.2 2 7 6" /></>);
export const IconSettings = ({ size = 16 }: P) => wrap(size, <><circle cx="12" cy="12" r="3.2" /><path d="M19.4 14a1.6 1.6 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.6 1.6 0 00-1.8-.3 1.6 1.6 0 00-1 1.5V20a2 2 0 11-4 0v-.1A1.6 1.6 0 008 18.4a1.6 1.6 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.6 1.6 0 00.3-1.8 1.6 1.6 0 00-1.5-1H2a2 2 0 110-4h.1A1.6 1.6 0 003.6 8a1.6 1.6 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.6 1.6 0 001.8.3H8a1.6 1.6 0 001-1.5V2a2 2 0 114 0v.1a1.6 1.6 0 001 1.5 1.6 1.6 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.6 1.6 0 00-.3 1.8V8a1.6 1.6 0 001.5 1H22a2 2 0 110 4h-.1a1.6 1.6 0 00-1.5 1z" /></>);
export const IconPlus = ({ size = 16 }: P) => wrap(size, <><path d="M12 6v12" /><path d="M6 12h12" /></>);
export const IconArrowRight = ({ size = 16 }: P) => wrap(size, <><path d="M4 12h15" /><path d="M14 7l5 5-5 5" /></>);
export const IconBulb = ({ size = 18 }: P) => wrap(size, <><path d="M9.5 17h5" /><path d="M10 20h4" /><path d="M12 3a6 6 0 00-3.5 10.9c.4.3.6.7.6 1.1h5.8c0-.4.2-.8.6-1.1A6 6 0 0012 3z" /></>);
export const IconLeaf = ({ size = 18 }: P) => wrap(size, <><path d="M5 19c0-7 4.5-11 14-11 0 9-4.5 12-10 12-2.2 0-4-1.8-4-1z" /><path d="M9 16c1.5-3 4-5.5 7-7" /></>);
export const IconFlask = ({ size = 18 }: P) => wrap(size, <><path d="M10 3h4" /><path d="M11 3v6L5.6 18a1.6 1.6 0 001.4 2.4h10a1.6 1.6 0 001.4-2.4L13 9V3" /><path d="M8 15h8" /></>);
export const IconTarget = ({ size = 18 }: P) => wrap(size, <><circle cx="12" cy="12" r="8" /><circle cx="12" cy="12" r="4" /><circle cx="12" cy="12" r="1" /></>);
export const IconQuote = ({ size = 22 }: P) => wrap(size, <><path d="M9 7c-2.4 1-3.6 2.8-3.6 5.4H9V18H4v-4.9C4 9.4 5.7 7.3 9 6.2z" /><path d="M19 7c-2.4 1-3.6 2.8-3.6 5.4H19V18h-5v-4.9c0-3.7 1.7-5.8 5-6.9z" /></>);

/* ------------------------------------------------- option / category icons */

const OPTION_ICONS: Record<IconName, React.ReactNode> = {
  sprout: <><path d="M12 20v-7" /><path d="M12 13c0-3 2-5 5-5 0 3-2 5-5 5z" /><path d="M12 13C12 10.5 10 9 7.5 9c0 2.5 2 4 4.5 4z" /><path d="M8 20h8" /></>,
  rocket: <><path d="M12 3c3 2.4 4.5 5.6 4.5 9L12 18l-4.5-6c0-3.4 1.5-6.6 4.5-9z" /><circle cx="12" cy="10" r="1.6" /><path d="M9 18l-2 3 3-1M15 18l2 3-3-1" /></>,
  recovery: <><path d="M4 16l4-4 3 2 4-6 5 3" /><path d="M20 8v4h-4" /></>,
  pillar: <><path d="M4 20h16" /><path d="M6 20V9h4v11" /><path d="M14 20V5h4v15" /></>,
  shield: <><path d="M12 3l7 3v6c0 4-3 6.6-7 9-4-2.4-7-5-7-9V6z" /><path d="M9 12l2 2 4-4" /></>,
  wave: <><path d="M3 13c2 0 2.5-3 4.5-3S10 15 12 15s2.5-5 4.5-5S19 13 21 13" /></>,
  swing: <><path d="M3 18l3-9 3 12 3-15 3 12 3-7 3 4" /></>,
  open: <><circle cx="12" cy="12" r="8" /><path d="M8.5 12h7" /></>,
  tag: <><path d="M12.5 4H20v7.5L11 20 4 13z" /><circle cx="16" cy="8" r="1.4" /></>,
  scales: <><path d="M12 4v16" /><path d="M6 8h12" /><path d="M6 8l-3 6h6z" /><path d="M18 8l-3 6h6z" /></>,
  premium: <><path d="M5 18l2-9 5 4 5-8 2 13z" /><circle cx="12" cy="4" r="1.4" /></>,
  trendUp: <><path d="M4 17l5-5 3 2 5-7" /><path d="M17 7h3v3" /></>,
  trendStrong: <><path d="M4 19l4-3 3-6 4 4 5-9" /><path d="M20 5h-4" /><path d="M20 5v4" /></>,
  trendDown: <><path d="M4 8l5 5 3-2 5 6" /><path d="M17 17h3v-3" /></>,
  steady: <><path d="M3 15l4-2 4-4 4 3 5-6" /><path d="M3 20h18" /></>,
  spark: <><path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z" /></>,
  guard: <><path d="M12 3l7 3v6c0 4-3 6.6-7 9-4-2.4-7-5-7-9V6z" /><path d="M8.5 13l3 2 4-5" /></>,
  clockShort: <><circle cx="12" cy="12" r="8" /><path d="M12 8v4l2.5 1.5" /></>,
  clockMid: <><circle cx="12" cy="12" r="8" /><path d="M12 7v5l3 2" /><path d="M12 4v1" /></>,
  clockLong: <><circle cx="12" cy="12" r="8" /><path d="M12 6v6l4 2" /><path d="M20 4l-2 2" /></>,
  coins: <><ellipse cx="9" cy="7" rx="5" ry="2.4" /><path d="M4 7v4c0 1.3 2.2 2.4 5 2.4s5-1.1 5-2.4V7" /><path d="M10 15.6c.9 1 3 1.8 5.5 1.8 3 0 5.5-1.1 5.5-2.4v-4" /><ellipse cx="15.5" cy="11" rx="5.5" ry="2.4" /></>,
  target: <><circle cx="12" cy="12" r="8" /><circle cx="12" cy="12" r="4" /><circle cx="12" cy="12" r="1" /></>,
  compare: <><path d="M12 4v16" /><path d="M4 8h5" /><path d="M15 8h5" /><path d="M6.5 8l-2.5 5h5z" /><path d="M17.5 8L15 13h5z" /></>,
  bars: <><rect x="4" y="13" width="4" height="7" rx="1" /><rect x="10" y="8" width="4" height="12" rx="1" /><rect x="16" y="4" width="4" height="16" rx="1" /></>,
  trophy: <><path d="M8 4h8v5a4 4 0 01-8 0z" /><path d="M8 5H5v2a3 3 0 003 3" /><path d="M16 5h3v2a3 3 0 01-3 3" /><path d="M12 13v4" /><path d="M9 20h6" /><path d="M10 17h4v3h-4z" /></>,
  calendar: <><rect x="4" y="5.5" width="16" height="14.5" rx="2.5" /><path d="M4 10h16" /><path d="M8.5 3.5v4" /><path d="M15.5 3.5v4" /></>,
  pulse: <><path d="M3 12h4l2.5-6 4 12 2.5-6h5" /></>,
};

export const OptionIcon = ({ name, size = 20 }: { name: IconName; size?: number }) =>
  wrap(size, OPTION_ICONS[name] ?? OPTION_ICONS.open);

/** the option glyphs, also usable on their own */
export const IconBars = ({ size = 18 }: P) => <OptionIcon name="bars" size={size} />;
export const IconCompare = ({ size = 18 }: P) => <OptionIcon name="compare" size={size} />;
export const IconCoins = ({ size = 18 }: P) => <OptionIcon name="coins" size={size} />;
export const IconScales = ({ size = 18 }: P) => <OptionIcon name="scales" size={size} />;
export const IconShield = ({ size = 18 }: P) => <OptionIcon name="shield" size={size} />;
export const IconPulse = ({ size = 18 }: P) => <OptionIcon name="pulse" size={size} />;
export const IconTrendUp = ({ size = 18 }: P) => <OptionIcon name="trendUp" size={size} />;
export const IconLock = ({ size = 16 }: P) => wrap(size, <><rect x="5" y="10.5" width="14" height="9.5" rx="2.5" /><path d="M8.5 10.5V8a3.5 3.5 0 017 0v2.5" /></>);

/* ------------------------------------------------------------ sparkline */

export function Sparkline({ series, up, width = 96, height = 30 }: { series: number[]; up: boolean; width?: number; height?: number }) {
  if (!series.length) return null;
  const min = Math.min(...series);
  const max = Math.max(...series);
  const span = max - min || 1;
  const step = width / (series.length - 1);
  const points = series.map((v, i) => `${(i * step).toFixed(1)},${(height - ((v - min) / span) * (height - 4) - 2).toFixed(1)}`);
  const base = height - ((series[0] - min) / span) * (height - 4) - 2;
  return (
    <svg width={width} height={height} aria-hidden="true" style={{ display: 'block' }}>
      <line x1="0" y1={base} x2={width} y2={base} stroke="var(--border-2)" strokeWidth="1" strokeDasharray="2 3" />
      <polyline points={points.join(' ')} fill="none" strokeWidth="1.6"
        stroke={up ? 'var(--green-text)' : 'var(--red)'} strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}

/* ------------------------------------------------------------ area chart */

export function PriceChart({ series, up, height = 230 }: { series: number[]; up: boolean; height?: number }) {
  const width = 720;
  if (series.length < 2) return null;
  const min = Math.min(...series);
  const max = Math.max(...series);
  const span = max - min || 1;
  const step = width / (series.length - 1);
  const pts = series.map((v, i) => [i * step, height - ((v - min) / span) * (height - 24) - 12] as const);
  const line = pts.map((p, i) => `${i === 0 ? 'M' : 'L'}${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(' ');
  const area = `${line} L${width} ${height} L0 ${height} Z`;
  const colour = up ? 'var(--green-text)' : 'var(--red)';
  return (
    <svg viewBox={`0 0 ${width} ${height}`} width="100%" height={height} role="img"
      aria-label={`Price trend over the selected period, ${up ? 'up' : 'down'} overall. Demo data.`}>
      <defs>
        <linearGradient id="gw-area" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={colour} stopOpacity="0.18" />
          <stop offset="100%" stopColor={colour} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill="url(#gw-area)" />
      <path d={line} fill="none" stroke={colour} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}


/* --------------------------------------------------------- illustrations */

/** Simple goal illustration for the left sidebar. */
export const MountainArt = () => (
  <svg viewBox="0 0 220 130" width="100%" height="auto" aria-hidden="true">
    <ellipse cx="110" cy="118" rx="94" ry="10" fill="var(--green-tint)" />
    <path d="M18 112c12-26 24-40 34-40s18 10 26 24" fill="none" stroke="var(--border-2)" strokeWidth="1.2" />
    <path d="M52 112L92 44l40 68z" fill="#5367ff" opacity="0.22" />
    <path d="M92 44l40 68H92z" fill="#5367ff" opacity="0.3" />
    <path d="M104 112l44-56 44 56z" fill="var(--green)" opacity="0.28" />
    <path d="M148 56l44 56h-44z" fill="var(--green)" opacity="0.45" />
    <path d="M148 56v-22" stroke="var(--green-text)" strokeWidth="2" strokeLinecap="round" />
    <path d="M148 34l14 5-14 5z" fill="var(--green)" />
    <path d="M92 44V26" stroke="#5367ff" strokeWidth="2" strokeLinecap="round" />
    <path d="M92 26l12 4-12 4z" fill="#5367ff" />
    <g fill="var(--bg-3)">
      <ellipse cx="44" cy="34" rx="16" ry="7" />
      <ellipse cx="58" cy="30" rx="11" ry="6" />
      <ellipse cx="186" cy="26" rx="14" ry="6" />
    </g>
  </svg>
);

/** Friendly figure on the beginner-guide card. */
/**
 * Beginner-tip illustration: a price chart with two other checks sitting beside
 * it — the picture the tip describes, where the trend is only one of several
 * things being read. Drawn from theme variables so it holds up in both themes.
 */
export const GuideArt = () => (
  <svg viewBox="0 0 108 100" width="92" height="85" aria-hidden="true" focusable="false">
    {/* the chart panel */}
    <rect x="16" y="20" width="76" height="58" rx="9"
      fill="var(--bg)" stroke="var(--border-2)" strokeWidth="1.4" />
    <path d="M24 62L40 55L56 46L72 41L85 32"
      fill="none" stroke="var(--green)" strokeWidth="1.8" strokeLinecap="round"
      strokeLinejoin="round" opacity="0.38" strokeDasharray="3.5 3.5" />
    {/* candles: two up, one down, one up */}
    <g strokeLinecap="round">
      <path d="M31 33v28" stroke="var(--green)" strokeWidth="1.3" opacity="0.65" />
      <rect x="28" y="40" width="6" height="15" rx="1.6" fill="var(--green)" opacity="0.85" />
      <path d="M47 30v29" stroke="var(--red)" strokeWidth="1.3" opacity="0.6" />
      <rect x="44" y="36" width="6" height="14" rx="1.6" fill="var(--red)" opacity="0.8" />
      <path d="M63 28v30" stroke="var(--green)" strokeWidth="1.3" opacity="0.65" />
      <rect x="60" y="34" width="6" height="18" rx="1.6" fill="var(--green)" opacity="0.85" />
      <path d="M79 25v28" stroke="var(--green)" strokeWidth="1.3" opacity="0.65" />
      <rect x="76" y="29" width="6" height="16" rx="1.6" fill="var(--green)" opacity="0.85" />
    </g>
    {/* the other checks the screen reads alongside price */}
    <g>
      <circle cx="17" cy="69" r="13" fill="var(--tone-blue-bg)" stroke="var(--tone-blue-fg)" strokeWidth="1.2" />
      <rect x="11" y="69" width="3.4" height="6" rx="1.2" fill="var(--tone-blue-fg)" />
      <rect x="15.6" y="65.5" width="3.4" height="9.5" rx="1.2" fill="var(--tone-blue-fg)" />
      <rect x="20.2" y="62.5" width="3.4" height="12.5" rx="1.2" fill="var(--tone-blue-fg)" />
    </g>
    <g>
      <circle cx="91" cy="69" r="13" fill="var(--amber-tint)" stroke="var(--amber)" strokeWidth="1.2" />
      <text x="91" y="74.5" textAnchor="middle" fontSize="14" fontWeight="600"
        fill="var(--amber)" fontFamily="inherit">₹</text>
    </g>
  </svg>
);
