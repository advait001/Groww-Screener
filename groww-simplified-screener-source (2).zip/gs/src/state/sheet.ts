/**
 * Sending rows to a Google Sheet.
 *
 * The prototype is a single static file with no backend, so the sheet is
 * reached through a Google Apps Script web app (see tools/google-sheet-endpoint.gs).
 * That script is deployed once by the sheet's owner and accepts POSTed JSON.
 *
 * Two details worth knowing, because both are easy to get wrong:
 *
 *   - The request goes out with `mode: 'no-cors'` and a `text/plain` content
 *     type. Apps Script does not answer CORS preflight requests, so anything
 *     that triggers one (an `application/json` header, a custom header) is
 *     rejected before it arrives. A "simple" request slips through. The cost
 *     is that the response is opaque — we cannot read success from it — so a
 *     send that resolves is treated as delivered.
 *   - Nothing is lost when the user is offline or the endpoint is not set
 *     yet. Rows queue in localStorage and flush on the next load.
 */

/** Paste the deployed Apps Script URL here, or set it at runtime (see below). */
const BUILT_IN_ENDPOINT =
  'https://script.google.com/macros/s/AKfycbxugC4jefNPnQHGxlJb3l7y7rJOMe2XMmUkKd628yF9gNdKYIvbH9UlFOMPoeGg_x04/exec';

const ENDPOINT_KEY = 'groww-screener.sheet-endpoint';
const QUEUE_KEY = 'groww-screener.sheet-queue';
const IDENTITY_KEY = 'groww-screener.identity';
const MAX_QUEUE = 50;

export interface Identity { name: string; email: string; at: number; }

export interface SheetRow {
  event: string;
  name: string;
  email: string;
  detail: string;
  at: string;
  session: string;
}

const safeGet = (key: string): string | null => {
  try { return window.localStorage.getItem(key); } catch { return null; }
};
const safeSet = (key: string, value: string) => {
  try { window.localStorage.setItem(key, value); } catch { /* private mode */ }
};

/** One id per browser tab session, so rows can be grouped into a visit. */
const session = Math.random().toString(36).slice(2, 10);

/**
 * The endpoint, in order of precedence: a `?sheet=` query parameter (which is
 * then remembered), anything already saved, then the built-in constant. The
 * query parameter is what lets the sheet be re-pointed without a rebuild.
 */
export function endpoint(): string {
  try {
    const fromUrl = new URLSearchParams(window.location.search).get('sheet');
    if (fromUrl) { safeSet(ENDPOINT_KEY, fromUrl); return fromUrl; }
  } catch { /* no URL access */ }
  return safeGet(ENDPOINT_KEY) || BUILT_IN_ENDPOINT;
}

export const isConfigured = () => endpoint().length > 0;

/* --------------------------------------------------------------- identity */

export function getIdentity(): Identity | null {
  const raw = safeGet(IDENTITY_KEY);
  if (!raw) return null;
  try {
    const v = JSON.parse(raw) as Identity;
    return v && typeof v.email === 'string' ? v : null;
  } catch { return null; }
}

export function setIdentity(name: string, email: string): Identity {
  const id: Identity = { name: name.trim(), email: email.trim(), at: Date.now() };
  safeSet(IDENTITY_KEY, JSON.stringify(id));
  return id;
}

export function clearIdentity() {
  try { window.localStorage.removeItem(IDENTITY_KEY); } catch { /* ignore */ }
}

/** Good enough to catch typos without rejecting valid unusual addresses. */
export const looksLikeEmail = (v: string) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim());

/* ------------------------------------------------------------- the queue */

const readQueue = (): SheetRow[] => {
  const raw = safeGet(QUEUE_KEY);
  if (!raw) return [];
  try {
    const v = JSON.parse(raw);
    return Array.isArray(v) ? v : [];
  } catch { return []; }
};

const writeQueue = (rows: SheetRow[]) =>
  safeSet(QUEUE_KEY, JSON.stringify(rows.slice(-MAX_QUEUE)));

export const queuedCount = () => readQueue().length;

/** One POST. Resolves true when the request left without throwing. */
async function post(row: SheetRow): Promise<boolean> {
  const url = endpoint();
  if (!url) return false;
  try {
    await fetch(url, {
      method: 'POST',
      mode: 'no-cors',
      // text/plain keeps this a "simple" request, so no preflight is sent
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify(row),
      keepalive: true,
    });
    return true;
  } catch {
    return false;
  }
}

/** Try the backlog. Stops at the first failure so order is preserved. */
export async function flush(): Promise<void> {
  if (!isConfigured()) return;
  let rows = readQueue();
  while (rows.length) {
    const ok = await post(rows[0]);
    if (!ok) break;
    rows = rows.slice(1);
    writeQueue(rows);
  }
}

/**
 * Record a row. Never throws and never blocks the UI: a failed send is
 * queued rather than surfaced, because a prototype should not interrupt
 * someone to report that a spreadsheet is unreachable.
 */
export function sendRow(event: string, detail: Record<string, unknown> = {}): void {
  const who = getIdentity();
  const row: SheetRow = {
    event,
    name: who?.name ?? '',
    email: who?.email ?? '',
    detail: Object.keys(detail).length ? JSON.stringify(detail) : '',
    at: new Date().toISOString(),
    session,
  };
  if (!isConfigured()) {
    const rows = readQueue();
    rows.push(row);
    writeQueue(rows);
    return;
  }
  void post(row).then((ok) => {
    if (ok) return;
    const rows = readQueue();
    rows.push(row);
    writeQueue(rows);
  });
}

/** Called once at start-up to drain anything left from a previous visit. */
export function startSheet(): void {
  void flush();
}
