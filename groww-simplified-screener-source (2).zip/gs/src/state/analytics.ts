/**
 * No analytics provider is wired up in a prototype, but every event the real
 * feature would need is fired here, with the same names a product team would
 * report on. The footer can show the log so the instrumentation is visible.
 *
 * A short list of these — the calls to action — is also forwarded to a Google
 * Sheet, when one has been configured. See src/state/sheet.ts.
 */
import { sendRow } from './sheet';

export type EventName =
  | 'onboarding_started' | 'onboarding_step_answered' | 'onboarding_skipped' | 'onboarding_completed'
  | 'profile_edit_opened'
  | 'screener_opened' | 'coach_marks_shown' | 'coach_marks_dismissed'
  | 'category_selected' | 'screener_option_selected' | 'screener_option_removed' | 'screener_reset'
  | 'screener_option_dropped'
  | 'translation_opened' | 'translation_closed'
  | 'conflict_shown'
  | 'screener_run' | 'results_viewed' | 'results_sorted'
  | 'stock_match_explanation_opened' | 'indicators_used_opened' | 'indicator_lesson_opened'
  | 'zero_result_triggered' | 'broad_result_triggered' | 'relaxation_applied' | 'narrowing_applied'
  | 'templates_opened' | 'template_applied' | 'filter_picker_opened'
  | 'screener_edited' | 'screener_saved' | 'screener_deleted' | 'saved_screen_run'
  | 'stock_detail_opened' | 'watchlist_toggled'
  | 'returning_user_detected' | 'theme_changed' | 'prototype_reset'
  | 'visitor_identified' | 'visitor_skipped_identity'
  | 'goal_planner_opened' | 'goal_planner_viewed' | 'goal_type_picked'
  | 'goal_suggestion_applied' | 'goal_plan_submitted' | 'goal_mix_shuffled'
  | 'goal_invest_opened' | 'goal_invest_confirmed';

export interface TrackedEvent {
  name: EventName;
  props?: Record<string, unknown>;
  at: number;
}

const events: TrackedEvent[] = [];
const listeners = new Set<() => void>();

/**
 * The events worth a row in the sheet. Everything else still fires locally
 * and shows in the event log — this is only the subset a person reading the
 * spreadsheet would actually want: the calls to action, not every tap.
 */
const TO_SHEET: ReadonlySet<EventName> = new Set<EventName>([
  'visitor_identified',
  'visitor_skipped_identity',
  'screener_run',
  'goal_planner_opened',
  'goal_plan_submitted',
  'goal_invest_confirmed',
  'template_applied',
  'screener_saved',
  'stock_detail_opened',
]);

export function track(name: EventName, props?: Record<string, unknown>) {
  events.push({ name, props, at: Date.now() });
  if (events.length > 200) events.shift();
  listeners.forEach((l) => l());
  if (typeof console !== 'undefined' && console.debug) console.debug('[event]', name, props ?? '');
  if (TO_SHEET.has(name)) sendRow(name, props ?? {});
}

export const getEvents = () => [...events].reverse();
export function subscribeEvents(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}
