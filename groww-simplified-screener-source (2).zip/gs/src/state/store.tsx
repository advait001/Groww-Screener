import React, { createContext, useContext, useEffect, useMemo, useReducer } from 'react';
import type { CategoryId, IndicatorId } from '../data/config';
import type { Profile, ProfileFieldId } from '../data/profile';
import { PROFILE_QUESTIONS } from '../data/profile';
import type { Selections, SortKey } from '../engine/screener';
import { track } from './analytics';

export type Route =
  | { name: 'intro' }
  | { name: 'onboarding' }
  | { name: 'summary' }
  | { name: 'screener' }
  | { name: 'processing' }
  | { name: 'results' }
  | { name: 'stock'; id: string }
  /** how Groww built your screen — the translation overview */
  | { name: 'learning' }
  /** one indicator, taught; origin lets Back return where the user came from */
  | { name: 'indicator'; id: IndicatorId; origin?: 'learning' | 'why' | 'results'; stockId?: string }
  /** why one stock matched (or did not) */
  | { name: 'whyMatched'; stockId: string }
  /** invest for a goal: the planner and the fund plan it produces */
  | { name: 'goal' };

export interface SavedScreen {
  id: string;
  name: string;
  selections: Selections;
  createdAt: string;
}

export interface State {
  route: Route;
  /** where the user came from, so back buttons behave */
  history: Route[];
  onboardingStep: number;
  onboardingComplete: boolean;
  profile: Profile;
  selections: Selections;
  lastRun?: { selections: Selections; count: number; at: string };
  saved: SavedScreen[];
  coachDone: boolean;
  /** the starter tips are a first-run thing; once true they never come back */
  tipsDone: boolean;
  theme: 'system' | 'light' | 'dark';
  sort: SortKey;
  sessions: number;
}

const STORAGE_KEY = 'groww-simple-screener.v1';

export const initialState: State = {
  route: { name: 'intro' },
  history: [],
  onboardingStep: 0,
  onboardingComplete: false,
  profile: {},
  selections: {},
  saved: [],
  coachDone: false,
  tipsDone: false,
  theme: 'system',
  sort: 'relevance',
  sessions: 1,
};

export type Action =
  | { type: 'go'; route: Route }
  | { type: 'back' }
  | { type: 'profileField'; field: ProfileFieldId; value: string | number }
  | { type: 'onboardingStep'; step: number }
  | { type: 'finishOnboarding' }
  | { type: 'resetOnboarding' }
  | { type: 'select'; category: CategoryId; optionId: string }
  | { type: 'clearCategory'; category: CategoryId }
  | { type: 'resetSelections' }
  | { type: 'setSelections'; selections: Selections }
  | { type: 'recordRun'; count: number }
  | { type: 'sort'; key: SortKey }
  | { type: 'saveScreen'; name: string }
  | { type: 'deleteScreen'; id: string }
  | { type: 'coachDone' }
  | { type: 'tipsDone' }
  | { type: 'theme'; theme: State['theme'] }
  | { type: 'hydrate'; state: Partial<State> }
  | { type: 'resetAll' };

export function reducer(state: State, action: Action): State {
  switch (action.type) {
    case 'go':
      if (state.route.name === action.route.name && JSON.stringify(state.route) === JSON.stringify(action.route)) return state;
      return { ...state, route: action.route, history: [...state.history, state.route].slice(-12) };
    case 'back': {
      const history = [...state.history];
      const prev = history.pop();
      return { ...state, route: prev ?? { name: 'screener' }, history };
    }
    case 'profileField':
      return { ...state, profile: { ...state.profile, [action.field]: action.value } };
    case 'onboardingStep':
      return { ...state, onboardingStep: Math.max(0, Math.min(PROFILE_QUESTIONS.length - 1, action.step)) };
    case 'finishOnboarding':
      return { ...state, onboardingComplete: true };
    case 'resetOnboarding':
      return { ...state, onboardingStep: 0, onboardingComplete: false, profile: {} };
    case 'select': {
      const current = state.selections[action.category];
      if (current === action.optionId) {
        const selections = { ...state.selections };
        delete selections[action.category];
        return { ...state, selections };
      }
      return { ...state, selections: { ...state.selections, [action.category]: action.optionId } };
    }
    case 'clearCategory': {
      const selections = { ...state.selections };
      delete selections[action.category];
      return { ...state, selections };
    }
    case 'resetSelections':
      return { ...state, selections: {} };
    case 'setSelections':
      return { ...state, selections: { ...action.selections } };
    case 'recordRun':
      // running a screen means the walkthrough tips have done their job
      return {
        ...state,
        tipsDone: true,
        lastRun: { selections: state.selections, count: action.count, at: new Date().toISOString() },
      };
    case 'sort':
      return { ...state, sort: action.key };
    case 'saveScreen': {
      const entry: SavedScreen = {
        id: `saved-${Date.now()}`,
        name: action.name,
        selections: state.selections,
        createdAt: new Date().toISOString(),
      };
      return { ...state, saved: [entry, ...state.saved].slice(0, 8) };
    }
    case 'deleteScreen':
      return { ...state, saved: state.saved.filter((s) => s.id !== action.id) };
    case 'coachDone':
      return { ...state, coachDone: true };
    case 'tipsDone':
      return { ...state, tipsDone: true };
    case 'theme':
      return { ...state, theme: action.theme };
    case 'hydrate':
      return { ...state, ...action.state, history: [] };
    case 'resetAll':
      // everything goes back to a first-run state; the chosen theme is kept,
      // since that is a display preference rather than prototype progress
      return { ...initialState, theme: state.theme, sessions: 1, route: { name: 'intro' }, history: [] };
    default:
      return state;
  }
}

interface Store {
  state: State;
  dispatch: React.Dispatch<Action>;
}

const StoreContext = createContext<Store>({ state: initialState, dispatch: () => undefined });

function load(): Partial<State> | null {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<State> & { sessions?: number };
    return { ...parsed, sessions: (parsed.sessions ?? 0) + 1 };
  } catch {
    return null;
  }
}

function save(state: State) {
  try {
    const { profile, onboardingComplete, selections, lastRun, saved, coachDone, tipsDone, theme, sort, sessions } = state;
    window.localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({ profile, onboardingComplete, selections, lastRun, saved, coachDone, tipsDone, theme, sort, sessions }),
    );
  } catch {
    /* storage can be unavailable; the prototype still works for this session */
  }
}

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  useEffect(() => {
    const stored = load();
    if (stored) {
      dispatch({ type: 'hydrate', state: stored });
      if (stored.onboardingComplete) {
        track('returning_user_detected', { sessions: stored.sessions });
        dispatch({ type: 'go', route: { name: 'screener' } });
      }
    }
  }, []);

  useEffect(() => { save(state); }, [state]);

  useEffect(() => {
    const root = document.documentElement;
    if (state.theme === 'system') root.removeAttribute('data-theme');
    else root.setAttribute('data-theme', state.theme);
  }, [state.theme]);

  const value = useMemo(() => ({ state, dispatch }), [state]);
  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export const useStore = () => useContext(StoreContext);

export function clearStoredState() {
  try { window.localStorage.removeItem(STORAGE_KEY); } catch { /* ignore */ }
}
