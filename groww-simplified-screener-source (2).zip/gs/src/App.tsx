import React, { useEffect, useState } from 'react';
import { useStore } from './state/store';
import { startSheet } from './state/sheet';
import { AppFooter, GrowwHeader } from './ui/chrome';
import { GoalScreen } from './screens/Goal';
import { Toast } from './ui/primitives';
import { IntroScreen, OnboardingScreen, ProcessingScreen, SummaryScreen } from './screens/Flow';
import { ScreenerScreen } from './screens/Screener';
import { ResultsScreen } from './screens/Results';
import { StockDetailScreen } from './screens/StockDetail';
import { LearningScreen } from './screens/Learning';
import { IndicatorLearningScreen } from './screens/IndicatorLearning';
import { WhyMatchedScreen } from './screens/WhyMatched';

export function App() {
  const { state } = useStore();
  const [toast, setToast] = useState<string | null>(null);
  const route = state.route;

  // drain anything a previous visit could not send
  useEffect(() => { startSheet(); }, []);

  return (
    <>
      <GrowwHeader onNotice={setToast} />
      <main id="main">
        {route.name === 'intro' ? <IntroScreen /> : null}
        {route.name === 'onboarding' ? <OnboardingScreen /> : null}
        {route.name === 'summary' ? <SummaryScreen /> : null}
        {route.name === 'screener' ? <ScreenerScreen onToast={setToast} /> : null}
        {route.name === 'processing' ? <ProcessingScreen /> : null}
        {route.name === 'results' ? <ResultsScreen onToast={setToast} /> : null}
        {route.name === 'stock' ? <StockDetailScreen id={route.id} onToast={setToast} /> : null}
        {route.name === 'learning' ? <LearningScreen /> : null}
        {route.name === 'indicator' ? <IndicatorLearningScreen id={route.id} origin={route.origin} stockId={route.stockId} /> : null}
        {route.name === 'whyMatched' ? <WhyMatchedScreen stockId={route.stockId} /> : null}
        {route.name === 'goal' ? <GoalScreen /> : null}
      </main>
      <AppFooter />
      {toast ? <Toast message={toast} onDone={() => setToast(null)} /> : null}
    </>
  );
}
