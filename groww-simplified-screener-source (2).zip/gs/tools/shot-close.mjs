import puppeteer from 'puppeteer';
const FILE = 'file:///mnt/user-data/outputs/groww-simplified-screener.html';
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const clickText = async (page, sel, text) => {
  const ok = await page.evaluate((s, t) => {
    const el = [...document.querySelectorAll(s)].find((e) => e.textContent.trim().startsWith(t));
    if (!el) return false; el.click(); return true;
  }, sel, text);
  if (!ok) throw new Error(`not found: ${text}`);
  await wait(240);
};
const b = await puppeteer.launch({ args: ['--no-sandbox'] });
for (const [name, dark] of [['light', false], ['dark', true]]) {
  const page = await b.newPage();
  await page.setViewport({ width: 1440, height: 1100, deviceScaleFactor: 2 });
  await page.goto(FILE, { waitUntil: 'networkidle0' });
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle0' });
  await wait(420);
  if (dark) {
    await page.evaluate(() => [...document.querySelectorAll('button')]
      .find((x) => /theme/i.test(x.getAttribute('aria-label') || ''))?.click());
    await wait(200);
  }
  await clickText(page, '.btn', 'Explore the screener');
  await page.evaluate(() => [...document.querySelectorAll('.coach-card .btn')].find((x) => x.textContent.includes('Skip'))?.click());
  await wait(200);
  await clickText(page, '.btn', 'Add filters');
  await clickText(page, '.picker-row', 'Growing fast');
  await clickText(page, '.picker-row', 'Strong ROE');
  await clickText(page, '.picker-row', 'Low debt');
  await clickText(page, '.picker-foot .btn', 'Done');
  await wait(300);
  await clickText(page, '.run-row .btn', 'Run screener');
  await wait(2600);
  // close matches sit behind a toggle when there are exact matches
  await page.evaluate(() => {
    const el = [...document.querySelectorAll('button')].find((e) => /close match/i.test(e.textContent));
    el?.click();
  });
  await wait(500);
  const card = await page.$('.close-card');
  if (!card) { console.log(name, 'no close matches'); await page.close(); continue; }
  await page.evaluate(() => document.querySelector('.close-grid')?.scrollIntoView({ block: 'center' }));
  await wait(500);
  const gridEl = await page.$('.close-grid');
  await gridEl.screenshot({ path: `/home/claude/close-${name}.png` });
  await page.close();
}
await b.close();
console.log('close-match shots written');
