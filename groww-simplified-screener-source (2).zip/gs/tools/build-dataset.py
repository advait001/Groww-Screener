"""
Turns the 1,000-row master register in the uploaded PDF into the app's Stock
shape. Every column the PDF publishes is carried over untouched; the fields the
app needs that the register does not print are derived from those columns where
an exact relationship exists (P/B = P/E x ROE, payout = yield x P/E, earnings
yield, PEG) and otherwise generated from a per-symbol seed, conditioned on that
company's own sector, size, growth, quality and beta so nothing contradicts the
published figures.
"""
import json, math

rows = json.load(open('rows.json'))

COLS = ['price', 'marketCap', 'return1Y', 'revenueCagr3Y', 'patCagr3Y', 'roe',
        'roce', 'debtToEquity', 'pe', 'sectorPe', 'rsi', 'beta', 'dividendYield']

LENDERS = {'Banking', 'Financial Services'}

# sector-typical operating margins, used only for the fields the register omits
SECTOR_MARGIN = {
    'Agriculture': (8, 16), 'Automobiles': (9, 17), 'Banking': (24, 34),
    'Cement & Materials': (14, 23), 'Chemicals': (14, 24), 'Consumer Goods': (12, 22),
    'Energy': (9, 19), 'Financial Services': (22, 32), 'Healthcare': (14, 22),
    'Industrials': (10, 19), 'Information Technology': (19, 28), 'Logistics': (11, 20),
    'Media': (10, 20), 'Metals & Mining': (11, 21), 'Pharmaceuticals': (17, 27),
    'Real Estate': (15, 26), 'Retail': (5, 11), 'Telecom': (27, 39),
    'Textiles': (7, 14), 'Utilities': (13, 24),
}
DEFAULT_MARGIN = (10, 20)


def seeded(symbol):
    """mulberry32, seeded from the symbol, so a company's generated fields never move"""
    h = 0
    for ch in symbol:
        h = (h * 31 + ord(ch)) & 0xFFFFFFFF
    state = [h or 1]

    def rnd():
        state[0] = (state[0] + 0x6D2B79F5) & 0xFFFFFFFF
        t = state[0]
        t = (t ^ (t >> 15)) * (t | 1) & 0xFFFFFFFF
        t ^= (t + ((t ^ (t >> 7)) * (t | 61) & 0xFFFFFFFF)) & 0xFFFFFFFF
        return (((t ^ (t >> 14)) & 0xFFFFFFFF) / 4294967296)
    return rnd


r1 = lambda v: round(v, 1)
r2 = lambda v: round(v, 2)

out = []
for row in rows:
    v = dict(zip(COLS, row['nums']))
    sector, symbol = row['sector'], row['symbol']
    lender = sector in LENDERS
    rnd = seeded(symbol)
    between = lambda a, b: a + rnd() * (b - a)

    pe = v['pe'] if v['pe'] > 0 else None
    roe, roce, de, beta = v['roe'], v['roce'], v['debtToEquity'], v['beta']
    rev3, pat3, ret1y = v['revenueCagr3Y'], v['patCagr3Y'], v['return1Y']

    # --- exact identities off the published columns
    pb = r1(pe * roe / 100) if pe else r1(max(0.3, roe / 12))
    earnings_yield = r1(100 / pe) if pe else None
    peg = r2(pe / pat3) if pe and pat3 > 0 else None
    payout = min(95, round(v['dividendYield'] * pe)) if pe else 0

    # --- quality, used to condition the generated fields
    quality = max(0.0, min(1.0, (roce / 40) * 0.6 + (1 - min(de, 2) / 2) * 0.4))

    lo, hi = SECTOR_MARGIN.get(sector, DEFAULT_MARGIN)
    ebitda_margin = r1(between(lo, hi) + quality * 4)
    net_margin = r1(max(0.8, ebitda_margin * between(0.42, 0.66)))
    margin_trend = round(between(-180, 60) + (rev3 - 8) * 6 + quality * 90)

    consistency = max(0, min(5, round(2 + quality * 2 + (1 if pat3 > 10 else 0) - (1 if beta > 1.3 else 0))))
    rev_up_years = max(0, min(5, consistency + (1 if rev3 > 8 else 0)))

    # cash conversion spreads wider than profitability does: weak operators can
    # report a profit and still bring in little or no cash
    weak_cash = quality < 0.3 and rnd() < 0.4
    cfo_pat = r2(between(-0.35, 0.4) if weak_cash else between(0.42, 1.2) + quality * 0.3)
    capex_rev = r1(between(2, 14) * (0.4 if lender else 1))
    fcf_positive = cfo_pat > 0.75 and capex_rev < ebitda_margin * between(0.45, 0.85)

    # --- returns: the register gives 1Y, the rest follow from it
    ret3y = r1(ret1y * between(0.35, 0.75) + between(-2, 9))
    ret5y = r1(ret3y * between(0.7, 1.15))
    ret6m = r1(ret1y * between(0.3, 0.7) + between(-6, 6))
    ret3m = r1(ret1y * between(0.12, 0.42) + between(-6, 6))
    ret1m = r1(ret3m * between(0.2, 0.6) + between(-4, 4))
    volatility = r1(max(9, beta * between(19, 27) + between(-3, 4)))
    drawdown = r1(-abs(volatility * between(0.7, 1.5)))

    # --- trend, anchored to RSI so the momentum fields agree with each other
    rsi = v['rsi']
    vs50 = r1((rsi - 50) * between(0.22, 0.42) + between(-2.5, 2.5))
    vs200 = r1(ret1y * between(0.25, 0.5) + between(-5, 5))
    vs20 = r1(vs50 * between(0.5, 1.2) + between(-2, 2))
    ma_slope = r2(vs50 * between(0.05, 0.2))
    dist52w = r1(-abs(between(0.5, 32) * (0.45 if rsi > 55 else 1.35)))

    mcap = v['marketCap']
    out.append({
        'name': row['name'], 'symbol': symbol, 'sector': sector,
        'price': r2(v['price']),
        'changePct1D': r2(between(-3.1, 3.3)),
        'marketCap': round(mcap, 1),
        'avgDailyValue': round(max(3, mcap * between(0.0004, 0.004)), 1),
        'freeFloatPct': r1(between(26, 88)),
        'listedYears': round(between(2, 34)) if rnd() > 0.06 else r1(between(0.7, 2.8)),
        'revenueYoY': r1(rev3 + between(-5, 6)),
        'revenueCagr3Y': rev3,
        'revenueCagr5Y': r1(rev3 + between(-3.5, 3.5)),
        'patYoY': r1(pat3 + between(-7, 8)),
        'patCagr3Y': pat3,
        'epsCagr3Y': r1(pat3 + between(-2.5, 1.5)),
        'profitConsistency': consistency,
        'revenueUpYears': rev_up_years,
        'ebitdaMargin': ebitda_margin,
        'netMargin': net_margin,
        'marginTrendBps': margin_trend,
        'roe': roe,
        'roce': None if lender else roce,
        'roa': r1(roe * between(0.09, 0.14)) if lender else r1(roe / (1 + de) * between(0.7, 1.0)),
        'debtToEquity': None if lender else de,
        'netDebtToEbitda': None if lender else r1(de * between(1.3, 3.1) - (between(0.6, 2.4) if rnd() > 0.72 else 0)),
        'interestCoverage': None if lender else r1(max(0.8, (12 - min(de, 2.5) * 4) * between(0.6, 1.9))),
        'currentRatio': None if lender else r2(between(0.9, 2.7)),
        'capitalAdequacy': r1(between(13.1, 19.6)) if lender else None,
        'gnpa': r1(between(1.0, 5.6)) if lender else None,
        'nim': r1(between(2.7, 4.7)) if lender else None,
        'cfoPositive': cfo_pat > 0.15,
        'cfoPatRatio': cfo_pat,
        'fcfPositive': fcf_positive,
        'capexRevenue': capex_rev,
        'cfoUpYears': max(0, min(5, consistency + (1 if cfo_pat > 0.9 else 0))),
        'pe': pe,
        'pb': pb,
        'evEbitda': r1(pe * between(0.45, 0.8)) if pe else None,
        'evSales': r1(max(0.3, (pe or 18) * between(0.45, 0.8) * ebitda_margin / 100)),
        'peg': peg,
        'earningsYield': earnings_yield,
        'return1M': ret1m, 'return3M': ret3m, 'return6M': ret6m,
        'return1Y': ret1y, 'return3Y': ret3y, 'return5Y': ret5y,
        'volatility': volatility, 'beta': beta,
        'maxDrawdown1Y': drawdown,
        'downsideDeviation': r1(volatility * between(0.45, 0.75)),
        'rsi': rsi,
        'priceVs20DMA': vs20, 'priceVs50DMA': vs50, 'priceVs200DMA': vs200,
        'ma50Slope': ma_slope, 'distance52wHigh': dist52w,
        'volumeRatio': r2(between(0.6, 2.3)),
        'dividendYield': v['dividendYield'],
        'payoutRatio': payout,
        'dpsCagr5Y': r1(between(-2, 17)) if v['dividendYield'] > 0.4 else None,
        'dividendStreak': round(between(2, 15)) if v['dividendYield'] > 0.4 else 0,
        'promoterHolding': r1(between(22, 75)),
        'promoterPledge': r1(between(2, 29)) if rnd() > 0.8 else 0,
        'fiiHolding': r1(between(1.5, 27)),
    })

json.dump(out, open('stocks.json', 'w'))
print('built', len(out), 'companies')
print('sectors', len(set(s['sector'] for s in out)))
print('lenders', sum(1 for s in out if s['capitalAdequacy'] is not None))
print('loss-makers (no P/E)', sum(1 for s in out if s['pe'] is None))
print('new listings (<3y)', sum(1 for s in out if s['listedYears'] < 3))
