import puppeteer from 'puppeteer';
const FILE = 'file:///mnt/user-data/outputs/groww-simplified-screener.html';
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const clickText = async (page, sel, text) => {
  const ok = await page.evaluate((s, t) => {
    const el = [...document.querySelectorAll(s)].find((e) => e.textContent.trim().startsWith(t));
    if (!el) return false; el.click(); return true;
  }, sel, text);
  if (!ok) throw new Error(`not found: ${text}`);
  await wait(240);
};
const b = await puppeteer.launch({ args: ['--no-sandbox'] });
for (const [name, dark] of [['light', false], ['dark', true]]) {
  const page = await b.newPage();
  await page.setViewport({ width: 1440, height: 1000, deviceScaleFactor: 2 });
  await page.goto(FILE, { waitUntil: 'networkidle0' });
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle0' });
  await wait(420);
  if (dark) {
    await page.evaluate(() => [...document.querySelectorAll('button')]
      .find((x) => /theme/i.test(x.getAttribute('aria-label') || ''))?.click());
    await wait(200);
  }
  await clickText(page, '.btn', 'Explore the screener');
  await page.evaluate(() => [...document.querySelectorAll('.coach-card .btn')].find((x) => x.textContent.includes('Skip'))?.click());
  await wait(200);
  await clickText(page, '.btn', 'Add filters');
  await clickText(page, '.picker-row', 'Growing steadily');
  await clickText(page, '.picker-row', 'Low debt');
  await clickText(page, '.picker-foot .btn', 'Done');
  await wait(400);

  const slide = await (await page.$('.slide-run')).boundingBox();
  await page.screenshot({ path: `/home/claude/slide-${name}-idle.png`,
    clip: { x: slide.x - 24, y: slide.y - 24, width: slide.width + 48, height: slide.height + 48 } });

  const knob = await (await page.$('.slide-run__knob')).boundingBox();
  await page.mouse.move(knob.x + knob.width / 2, knob.y + knob.height / 2);
  await page.mouse.down();
  await page.mouse.move(knob.x + knob.width / 2 + slide.width * 0.45, knob.y + knob.height / 2, { steps: 16 });
  await wait(120);
  await page.screenshot({ path: `/home/claude/slide-${name}-mid.png`,
    clip: { x: slide.x - 24, y: slide.y - 24, width: slide.width + 48, height: slide.height + 48 } });

  await page.mouse.move(slide.x + slide.width - 10, knob.y + knob.height / 2, { steps: 12 });
  await wait(100);
  await page.screenshot({ path: `/home/claude/slide-${name}-end.png`,
    clip: { x: slide.x - 24, y: slide.y - 24, width: slide.width + 48, height: slide.height + 48 } });
  await page.mouse.up();
  await wait(900);
  console.log(name, '| after release:', (await page.evaluate(() => document.getElementById('root').textContent)).slice(0, 60));
  await page.close();
}
await b.close();
console.log('slide shots written');
