"""
Rewrites every filter's name, chip and one-line blurb into plain language —
the test being whether a ten-year-old could tell what the filter does from the
words alone. The rules, thresholds and explanations underneath are untouched;
only the words a beginner reads on the main screen change.
"""
import json
import re
import sys

PATH = 'src/data/config.ts'

# id: (label, chip, blurb)
NAMES = {
    # growth
    'growth-steady':      ('Grows a little every year', 'Grows every year', 'Sales and profit go up most years.'),
    'growth-fast':        ('Growing really fast', 'Growing fast', 'Sales and profit are shooting up.'),
    'growth-sales':       ('Selling more than before', 'Selling more', 'It sold more this year than last year.'),
    'growth-profit':      ('Earning more than before', 'Earning more', 'It kept more profit than last year.'),
    'growth-consistent':  ('Grows year after year', 'Grows every year', 'Almost every year is better than the one before.'),
    'growth-recovery':    ('Getting better after a bad patch', 'Getting better', 'It had a slow few years and is picking up.'),
    'growth-any':         ("Growth doesn't matter to me", 'Any growth', ''),
    # profitability
    'profit-margins':     ('Keeps a lot from each sale', 'Keeps a lot per sale', 'Less of its money goes on costs than its rivals.'),
    'profit-rising-margins': ('Keeping more than it used to', 'Keeping more', 'It gets to keep a bigger slice than before.'),
    'profit-roe':         ('Makes good money from what it has', 'Good earner', 'It turns the owners’ money into decent profit.'),
    'profit-roce':        ('Uses its money wisely', 'Uses money well', 'Everything it spends is put to good use.'),
    'profit-quality':     ('Its profit is real cash', 'Real cash profit', 'The profit it reports actually shows up as money.'),
    'profit-netmargin':   ('Keeps a big slice at the end', 'Big final slice', 'After every bill is paid, a lot is left.'),
    'profit-any':         ("Profit doesn't matter to me", 'Any profit', ''),
    # stability
    'stability-stable':   ('Calm and steady', 'Calm and steady', 'The price and the profit both stay fairly still.'),
    'stability-low-vol':  ('Price jumps around less', 'Price stays still', 'Its price moves less than most of its rivals.'),
    'stability-low-beta': ('Does its own thing', 'Goes its own way', 'When the whole market drops, it drops less.'),
    'stability-earnings': ('Profit stays steady', 'Steady profit', 'Its profit goes up most years instead of bouncing.'),
    'stability-drawdown': ('Never crashed badly', 'No big crash', 'Even at its worst it did not fall very far.'),
    'stability-any':      ("Steadiness doesn't matter to me", 'Any steadiness', ''),
    # balance sheet
    'balance-low-debt':   ('Hardly borrows anything', 'Barely borrows', 'It owes very little to anyone.'),
    'balance-manageable': ('Borrows only what it can repay', 'Can repay what it owes', 'It has debt, but nothing it cannot handle.'),
    'balance-net-cash':   ('Has more cash than debt', 'More cash than debt', 'Its piggy bank is bigger than what it owes.'),
    'balance-coverage':   ('Pays its interest easily', 'Pays interest easily', 'Its profit covers the interest many times over.'),
    'balance-liquidity':  ('Can pay this year’s bills', 'Can pay the bills', 'It has enough to cover what is due soon.'),
    'balance-any':        ("Borrowing doesn't matter to me", 'Any borrowing', ''),
    # cash flow
    'cash-positive':      ('Brings in real money', 'Brings in money', 'The day-to-day business actually collects cash.'),
    'cash-strong':        ('Collects more cash than it reports', 'Lots of cash in', 'More money comes in than the profit figure suggests.'),
    'cash-backed':        ('Its profit is real cash', 'Real cash profit', 'Most of its profit arrives as actual money.'),
    'cash-fcf':           ('Has money left over', 'Money left over', 'After spending on itself, cash is still left.'),
    'cash-low-capex':     ('Does not need to spend much', 'Spends little on itself', 'It can keep going without buying lots of new things.'),
    'cash-any':           ("Cash doesn't matter to me", 'Any cash', ''),
    # valuation
    'valuation-reasonable': ('Priced about right', 'Fairly priced', 'It costs about the same as companies like it.'),
    'valuation-discount':   ('Cheaper than companies like it', 'Cheaper than rivals', 'You pay less for it than for its rivals.'),
    'valuation-low-pb':     ('Cheap for everything it owns', 'Cheap for what it owns', 'Its price is low next to the stuff it actually owns.'),
    'valuation-growth-value': ('Growing fast but not overpriced', 'Growth without the price', 'It grows quickly and still is not expensive.'),
    'valuation-earnings-yield': ('Lots of profit for the price', 'Lots of profit per rupee', 'Each rupee you pay buys a big slice of profit.'),
    'valuation-any':        ("Price doesn't matter to me", 'Any price', ''),
    # momentum
    'momentum-positive':  ('Price is going up', 'Price going up', 'The price has been climbing lately.'),
    'momentum-improving': ('Picking up speed', 'Speeding up', 'The price has turned upwards and is gaining pace.'),
    'momentum-strong':    ('On a long winning run', 'On a long run', 'The price has been climbing for months.'),
    'momentum-strength':  ('Beating companies like it', 'Beating its rivals', 'It has done better than its rivals lately.'),
    'momentum-near-highs': ('Close to its best-ever price', 'Near its best price', 'It is trading near the highest price of the year.'),
    'momentum-oversold':  ('Has dropped a lot lately', 'Dropped a lot', 'The price has fallen sharply in a short time.'),
    'momentum-any':       ("Price moves don't matter to me", 'Any price move', ''),
    # performance
    'performance-strong': ('Did really well last year', 'Great last year', 'It beat most other companies over the past year.'),
    'performance-steady': ('Does well year after year', 'Good every year', 'It has made money over one year and over three.'),
    'performance-positive': ('Went up over the year', 'Up this year', 'It is worth more than it was a year ago.'),
    'performance-3y':     ('Great over three years', 'Great over 3 years', 'It is one of the best over the last three years.'),
    'performance-recovery': ('Bouncing back', 'Bouncing back', 'It had a weak few years and is climbing again.'),
    'performance-any':    ("Past results don't matter to me", 'Any past result', ''),
    # dividends
    'dividend-yield':     ('Pays you a lot', 'Pays a lot', 'It hands more money back to owners than its rivals.'),
    'dividend-steady':    ('Pays you every single year', 'Pays every year', 'It has paid out five years in a row or more.'),
    'dividend-growing':   ('Pays a bit more each year', 'Pays more each year', 'The amount it hands back keeps going up.'),
    'dividend-safe':      ('Pays only what it can afford', 'Pays what it can afford', 'It hands back money without stretching itself.'),
    'dividend-any':       ("Payouts don't matter to me", 'Any payout', ''),
    # size
    'size-large':         ('A really big company', 'Really big', 'One of the biggest companies on the list.'),
    'size-mid':           ('A medium-sized company', 'Medium-sized', 'Bigger than most, smaller than the giants.'),
    'size-small':         ('A small company', 'Small', 'One of the smaller companies on the list.'),
    'size-any':           ("Size doesn't matter to me", 'Any size', ''),
    # liquidity
    'liquidity-high':     ('Very easy to buy and sell', 'Easy to buy and sell', 'Huge numbers of its shares change hands daily.'),
    'liquidity-active':   ('Easy enough to buy and sell', 'Traded every day', 'Enough shares are traded for you to get in and out.'),
    'liquidity-float':    ('Lots of shares to go around', 'Plenty of shares', 'A big share of the company is open to everyone.'),
    'liquidity-any':      ("Buying and selling doesn't matter", 'Any trading', ''),
    # composite
    'composite-quality':  ('Good at pretty much everything', 'Good all round', 'It earns well, holds little debt and makes real cash.'),
    'composite-value-quality': ('Cheap but still healthy', 'Cheap and healthy', 'It costs less than its rivals and is not in trouble.'),
    'composite-growth-quality': ('Grows fast and earns well', 'Grows and earns', 'It is growing quickly and making real money doing it.'),
    'composite-stable-growth': ('Grows without the drama', 'Grows calmly', 'It keeps growing and its price stays calm.'),
    'composite-any':      ('No ready-made set', 'None', ''),
    # horizon
    'horizon-short':      ('For a few months', 'A few months', 'You plan to sell again fairly soon.'),
    'horizon-medium':     ('For one to three years', 'One to three years', 'You can leave the money alone for a couple of years.'),
    'horizon-long':       ('For five years or more', 'Five years or more', 'You are happy to wait a long time.'),
    'horizon-any':        ('Not sure yet', 'Not sure', ''),
}

# category id: (label, question, panelBlurb, blurb)
CATEGORIES = {
    'growth':        ('Getting bigger', 'Should the company be getting bigger?',
                      'Companies that sell more and earn more than they used to.',
                      'Whether it sells and earns more than it used to.'),
    'profitability': ('Making money', 'How well should it make money?',
                      'How much the company keeps out of everything it sells.',
                      'How much it keeps out of what it sells.'),
    'stability':     ('Staying calm', 'How bumpy a ride are you okay with?',
                      'Companies whose price and profit move less than most.',
                      'How much the price and the profit jump around.'),
    'balance':       ('Money it owes', 'How much borrowing is okay?',
                      'How much the company has borrowed, and whether it can repay it.',
                      'What it owes and whether it can pay it back.'),
    'cashflow':      ('Real cash', 'Should the profit be real cash?',
                      'Whether the profit it reports actually turns up as money.',
                      'Whether its profit arrives as actual money.'),
    'valuation':     ('What it costs', 'How should the price compare with others?',
                      'What you pay for it next to companies that do the same thing.',
                      'What you pay, next to companies like it.'),
    'momentum':      ('Recent price', 'What should the price have been doing?',
                      'Which way the share price has been heading lately.',
                      'Which way the price has been moving.'),
    'performance':   ('Past results', 'What track record are you after?',
                      'How the share has done over the past year and the past three.',
                      'How it has done over one year and three.'),
    'dividends':     ('Money paid to you', 'Do you want to be paid along the way?',
                      'Companies that hand some of their profit back to owners.',
                      'Whether it hands money back to you.'),
    'size':          ('How big it is', 'How big should the company be?',
                      'Big, medium or small, by what the whole company is worth.',
                      'How big the company is.'),
    'liquidity':     ('Easy to trade', 'How easily should it trade?',
                      'How many of its shares change hands on a normal day.',
                      'How easy it is to buy or sell.'),
    'composite':     ('Ready-made', 'Want several checks in one go?',
                      'Each of these bundles a few checks into one pick.',
                      'Bundles of checks in a single pick.'),
    'horizon':       ('How long you’ll wait', 'How long will you leave the money alone?',
                      'Roughly how long you plan to hold on for.',
                      'How long you plan to stay invested.'),
}


def ts(value):
    """A TypeScript string literal, single-quoted where that is safe."""
    if "'" not in value:
        return "'" + value + "'"
    return json.dumps(value)


def main():
    src = open(PATH).read()
    missed = []

    for oid, (label, chip, blurb) in NAMES.items():
        start = src.find("id: '%s'" % oid)
        if start < 0:
            missed.append(oid)
            continue
        # the option object ends where the next one begins
        nxt = src.find("\n  { id: '", start)
        end = nxt if nxt > 0 else len(src)
        block = src[start:end]
        block = re.sub(r"label: (?:'[^']*'|\"[^\"]*\")", 'label: ' + ts(label), block, count=1)
        block = re.sub(r"chip: (?:'[^']*'|\"[^\"]*\")", 'chip: ' + ts(chip), block, count=1)
        if blurb:
            block = re.sub(r"blurb: (?:'[^']*'|\"[^\"]*\")", 'blurb: ' + ts(blurb), block, count=1)
        src = src[:start] + block + src[end:]

    # the "doesn't matter" options are produced by a helper, so patch its call sites
    def no_filter(m):
        oid = m.group(1)
        label, chip, _ = NAMES[oid]
        return "noFilter('%s', '%s', %s, %s)" % (oid, m.group(2), ts(label), ts(chip))
    src = re.sub(r"noFilter\('([a-z-]+)', '([a-z]+)', (?:'[^']*'|\"[^\"]*\"), (?:'[^']*'|\"[^\"]*\")\)",
                 no_filter, src)

    for cid, (label, question, panel, blurb) in CATEGORIES.items():
        start = src.find("{ id: '%s', label:" % cid)
        if start < 0:
            missed.append('category:' + cid)
            continue
        end = src.find("optional: true }", start) + len("optional: true }")
        block = src[start:end]
        block = re.sub(r"label: (?:'[^']*'|\"[^\"]*\")", 'label: ' + ts(label), block, count=1)
        block = re.sub(r"question: (?:'[^']*'|\"[^\"]*\")", 'question: ' + ts(question), block, count=1)
        block = re.sub(r"panelBlurb: (?:'[^']*'|\"[^\"]*\")", 'panelBlurb: ' + ts(panel), block, count=1)
        block = re.sub(r"blurb: (?:'[^']*'|\"[^\"]*\")", 'blurb: ' + ts(blurb), block, count=1)
        src = src[:start] + block + src[end:]

    open(PATH, 'w').write(src)
    print('renamed %d filters and %d categories' % (len(NAMES), len(CATEGORIES)))
    if missed:
        print('MISSED:', missed, file=sys.stderr)
        sys.exit(1)


main()
