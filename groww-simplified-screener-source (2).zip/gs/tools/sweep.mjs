import puppeteer from 'puppeteer';
const FILE = 'file:///mnt/user-data/outputs/groww-simplified-screener.html';
const OUT = '/tmp/claude-0/-home-claude/2cac05a6-3bef-5461-8d18-ade585261293/scratchpad/shots';
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const b = await puppeteer.launch({ args: ['--no-sandbox'] });
const p = await b.newPage();
await p.setViewport({ width: 1512, height: 1000, deviceScaleFactor: 2 });
const errs = [];
p.on('pageerror', (e) => errs.push(String(e).slice(0, 160)));
const ct = async (sel, t) => {
  const ok = await p.evaluate((s, t) => {
    const e = [...document.querySelectorAll(s)].find((x) => (x.textContent || '').toLowerCase().includes(t.toLowerCase()));
    if (!e) return false; e.click(); return true;
  }, sel, t);
  await wait(280); return ok;
};
await p.goto(FILE, { waitUntil: 'networkidle0' });
await p.evaluate(() => localStorage.clear());
await p.reload({ waitUntil: 'networkidle0' });
await wait(500);

// onboarding
await ct('button', 'Get started');
await wait(300);
await p.screenshot({ path: `${OUT}/sweep-onboarding.png` });
for (let i = 0; i < 6; i++) {
  await p.evaluate(() => document.querySelectorAll('.choice')[0]?.click());
  await wait(120);
  const done = await p.evaluate(() => {
    const b = [...document.querySelectorAll('.onb__actions .btn')].find((x) => /Continue|See my profile/.test(x.textContent));
    if (b) { b.click(); return false; } return true;
  });
  await wait(260);
  if (done) break;
}
await p.screenshot({ path: `${OUT}/sweep-summary.png` });
await ct('.btn', 'Open screener');
await p.evaluate(() => [...document.querySelectorAll('.coach-card button')].find((x) => /skip/i.test(x.textContent))?.click());
await wait(300);

// coach marks replay to check them in dark
await p.screenshot({ path: `${OUT}/sweep-explore-profile.png` });

// learning overview
for (const f of ['Grows a little every year', 'Calm and steady']) {
  await p.evaluate(() => [...document.querySelectorAll('button')].find((x) => /add (more )?filters|tap to add/i.test(x.textContent || ''))?.click());
  await wait(320);
  await ct('.picker-row', f);
  await p.evaluate(() => [...document.querySelectorAll('.picker-foot button')].find((x) => /apply/i.test(x.textContent))?.click());
  await wait(260);
}
await p.evaluate(() => [...document.querySelectorAll('button')].find((x) => /run screener/i.test(x.textContent))?.click());
await wait(2800);
await ct('.res-bar__btn', 'What we checked');
await wait(400);
await p.screenshot({ path: `${OUT}/sweep-checked.png` });
await p.keyboard.press('Escape'); await wait(300);

console.log('errors:', errs.length ? errs.slice(0, 3) : 'none');
await b.close();
