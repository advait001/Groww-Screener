import json
stocks = json.load(open('stocks.json'))
sectors = sorted({s['sector'] for s in stocks})
NUM = ['price', 'changePct1D', 'marketCap', 'avgDailyValue', 'freeFloatPct', 'listedYears',
       'revenueYoY', 'revenueCagr3Y', 'revenueCagr5Y', 'patYoY', 'patCagr3Y', 'epsCagr3Y',
       'profitConsistency', 'revenueUpYears', 'ebitdaMargin', 'netMargin', 'marginTrendBps',
       'roe', 'roce', 'roa', 'debtToEquity', 'netDebtToEbitda', 'interestCoverage', 'currentRatio',
       'capitalAdequacy', 'gnpa', 'nim', 'cfoPositive', 'cfoPatRatio', 'fcfPositive',
       'capexRevenue', 'cfoUpYears', 'pe', 'pb', 'evEbitda', 'evSales', 'peg', 'earningsYield',
       'return1M', 'return3M', 'return6M', 'return1Y', 'return3Y', 'return5Y',
       'volatility', 'beta', 'maxDrawdown1Y', 'downsideDeviation', 'rsi',
       'priceVs20DMA', 'priceVs50DMA', 'priceVs200DMA', 'ma50Slope', 'distance52wHigh',
       'volumeRatio', 'dividendYield', 'payoutRatio', 'dpsCagr5Y', 'dividendStreak',
       'promoterHolding', 'promoterPledge', 'fiiHolding']
BOOL = {'cfoPositive', 'fcfPositive'}

def cell(s, f):
    v = s[f]
    if v is None:
        return 'n'
    if f in BOOL:
        return '1' if v else '0'
    return repr(round(v, 2) if isinstance(v, float) else v).replace('.0,', ',')

lines = []
import re
for s in stocks:
    s['name'] = re.sub(r'\s+(Limited|Ltd\.?)$', '', s['name'])
    vals = ','.join(cell(s, f) for f in NUM)
    lines.append(f'[{json.dumps(s["name"])},{json.dumps(s["symbol"])},{sectors.index(s["sector"])},{vals}]')

head = f'''/**
 * DEMO DATA ONLY — 1,000 synthetic companies.
 *
 * Built by tools/build-dataset.py from the uploaded 1,000-stock prototype
 * register. Every column that register publishes — price, market cap, 1Y
 * return, 3Y revenue and profit CAGR, ROE, ROCE, D/E, P/E, sector P/E, RSI,
 * beta and dividend yield — is carried here unchanged. The remaining fields
 * the screener needs are derived: P/B from P/E and ROE, payout from yield and
 * P/E, earnings yield and PEG from P/E, and the rest generated per company
 * from a seed made of its own ticker, conditioned on its sector, size, growth,
 * quality and beta so nothing contradicts the published figures.
 *
 * Nothing here is live market data and no company here is real.
 */

export const SNAPSHOT_LABEL = '19 Sep 2026, end of day';
export const RULE_VERSION = 'rules v2.1';

export const SECTORS = [
{chr(10).join(f"  {json.dumps(s)}," for s in sectors)}
] as const;
export type Sector = (typeof SECTORS)[number];

export interface Stock {{
  id: string; name: string; symbol: string; sector: Sector;
  price: number; change1D: number; changePct1D: number;
  marketCap: number; avgDailyValue: number; freeFloatPct: number; listedYears: number;
  revenueYoY: number; revenueCagr3Y: number | null; revenueCagr5Y: number | null;
  patYoY: number | null; patCagr3Y: number | null; epsCagr3Y: number | null;
  profitConsistency: number | null; revenueUpYears: number | null;
  ebitdaMargin: number; netMargin: number; marginTrendBps: number;
  roe: number; roce: number | null; roa: number;
  debtToEquity: number | null; netDebtEbitda: number | null;
  interestCoverage: number | null; currentRatio: number | null;
  capitalAdequacy: number | null; gnpa: number | null; nim: number | null;
  cfoPositive: boolean; cfoPatRatio: number; fcfPositive: boolean;
  capexRevenue: number; cfoUpYears: number | null;
  pe: number | null; pb: number; evEbitda: number | null; evSales: number;
  peg: number | null; earningsYield: number | null;
  return1M: number; return3M: number; return6M: number;
  return1Y: number; return3Y: number | null; return5Y: number | null;
  volatility: number; beta: number; maxDrawdown1Y: number; downsideDeviation: number;
  rsi: number; priceVs20DMA: number; priceVs50DMA: number; priceVs200DMA: number;
  ma50Slope: number; distance52wHigh: number; volumeRatio: number;
  dividendYield: number; payoutRatio: number; dpsCagr5Y: number | null; dividendStreak: number;
  promoterHolding: number; promoterPledge: number; fiiHolding: number;
}}

/** field order of the packed rows below */
const FIELDS = {json.dumps(NUM)} as const;
const BOOLS = new Set({json.dumps(sorted(BOOL))});
const n = null;

/** name, symbol, sector index, then the fields above in order */
const ROWS: (string | number | null)[][] = [
{chr(10).join('  ' + l + ',' for l in lines)}
];

export const STOCKS: Stock[] = ROWS.map((r) => {{
  const s: Record<string, unknown> = {{
    id: String(r[1]).toLowerCase(),
    name: r[0],
    symbol: r[1],
    sector: SECTORS[r[2] as number],
  }};
  FIELDS.forEach((f, i) => {{
    const v = r[i + 3];
    s[f] = BOOLS.has(f) ? v === 1 : v;
  }});
  s.change1D = Math.round((s.price as number) * (s.changePct1D as number)) / 100;
  return s as unknown as Stock;
}});
'''
open('stocks_head.ts', 'w').write(head)
print('emitted', len(lines), 'rows |', round(len(head) / 1024), 'KB')
