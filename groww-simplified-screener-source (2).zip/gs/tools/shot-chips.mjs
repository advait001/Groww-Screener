import puppeteer from 'puppeteer';
const FILE = 'file:///mnt/user-data/outputs/groww-simplified-screener.html';
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const clickText = async (page, sel, text) => {
  const ok = await page.evaluate((s, t) => {
    const el = [...document.querySelectorAll(s)].find((e) => e.textContent.trim().startsWith(t));
    if (!el) return false; el.click(); return true;
  }, sel, text);
  if (!ok) throw new Error(`not found: ${text}`);
  await wait(200);
};
// one filter from every category, so all 13 chips appear together
const PICKS = ['Growing steadily', 'High margins', 'Relatively stable', 'Low debt', 'Cash backed',
  'Reasonably valued', 'Positive momentum', 'Positive year', 'Safe payout', 'Large cap',
  'Active trading', 'Quality business', 'Long term'];
const b = await puppeteer.launch({ args: ['--no-sandbox'] });
for (const [name, dark] of [['light', false], ['dark', true]]) {
  const page = await b.newPage();
  await page.setViewport({ width: 1440, height: 1100, deviceScaleFactor: 2 });
  await page.goto(FILE, { waitUntil: 'networkidle0' });
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle0' });
  await wait(420);
  if (dark) {
    await page.evaluate(() => [...document.querySelectorAll('button')]
      .find((x) => /theme/i.test(x.getAttribute('aria-label') || ''))?.click());
    await wait(200);
  }
  await clickText(page, '.btn', 'Explore the screener');
  await page.evaluate(() => [...document.querySelectorAll('.coach-card .btn')].find((x) => x.textContent.includes('Skip'))?.click());
  await wait(200);
  await clickText(page, '.btn', 'Add filters');
  for (const p of PICKS) await clickText(page, '.picker-row', p);
  await clickText(page, '.picker-foot .btn', 'Done');
  await wait(400);
  await page.screenshot({ path: `/home/claude/chips-${name}.png`, clip: { x: 0, y: 60, width: 1440, height: 760 } });
  const st = await page.$('.statement');
  const sb = await st.boundingBox();
  await page.screenshot({ path: `/home/claude/chips-${name}-zoom.png`,
    clip: { x: sb.x - 8, y: sb.y - 8, width: sb.width + 16, height: sb.height + 16 } });
  // and the sidebar list, which uses the same tint
  const bare = await page.evaluate(() => [...document.querySelectorAll('.stmt-chip, .chosen-row')]
    .filter((el) => {
      const bg = getComputedStyle(el).getPropertyValue('--cat-bg').trim();
      return !bg || bg === 'transparent';
    }).length);
  console.log(name, '| chips without a tint:', bare);
  await page.close();
}
await b.close();
