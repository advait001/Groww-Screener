/**
 * Final verification sweep: coach marks, processing screen, learning overview,
 * and the explore + results screens at narrow widths. Writes to shots/.
 */
import puppeteer from 'puppeteer';

const FILE = 'file:///mnt/user-data/outputs/groww-simplified-screener.html';
const OUT = '/tmp/claude-0/-home-claude/2cac05a6-3bef-5461-8d18-ade585261293/scratchpad/shots';
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
const errors = [];

const fresh = async (width) => {
  const page = await browser.newPage();
  await page.setViewport({ width, height: 1000, deviceScaleFactor: 2 });
  page.on('pageerror', (e) => errors.push(String(e).slice(0, 160)));
  await page.goto(FILE, { waitUntil: 'networkidle0' });
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle0' });
  await wait(450);
  return page;
};

const hit = (page, sel, text) => page.evaluate((s, t) => {
  const el = [...document.querySelectorAll(s)]
    .find((e) => (e.textContent || '').trim().toLowerCase().includes(t.toLowerCase()));
  if (!el) return false;
  el.click();
  return true;
}, sel, text);

const toExplore = async (page, { coach = false } = {}) => {
  await hit(page, 'button', 'Explore the screener');
  await wait(300);
  if (!coach) {
    await page.evaluate(() => [...document.querySelectorAll('.coach-card button')]
      .find((b) => /skip/i.test(b.textContent))?.click());
    await wait(260);
  }
};

const addTwo = async (page) => {
  for (const label of ['Grows a little every year', 'Calm and steady']) {
    await page.evaluate(() => [...document.querySelectorAll('button')]
      .find((b) => /add (more )?filters|tap to add/i.test(b.textContent || ''))?.click());
    await wait(300);
    const ok = await hit(page, '.picker-row', label);
    if (!ok) console.log('MISS picker row:', label);
    await page.evaluate(() => [...document.querySelectorAll('.picker-foot button, .picker__foot button')]
      .find((b) => /apply|done/i.test(b.textContent))?.click());
    await wait(260);
  }
};

const shoot = async (page, name, full = false) => {
  await page.screenshot({ path: `${OUT}/${name}.png`, fullPage: full });
  const overflow = await page.evaluate(() =>
    document.documentElement.scrollWidth - document.documentElement.clientWidth);
  console.log(name.padEnd(22), 'h-overflow:', overflow);
  return overflow;
};

// 1. coach marks on first entry
let p = await fresh(1512);
await toExplore(p, { coach: true });
await shoot(p, 'v-coach');
await p.close();

// 2. processing screen mid-run + 3. learning overview
p = await fresh(1512);
await toExplore(p);
await addTwo(p);
await hit(p, 'button', 'Run Screener');
await wait(900);
await shoot(p, 'v-processing');
await wait(2600);
const gotLearn = await hit(p, 'button, a', 'How the screener works')
  || await hit(p, 'button, a', 'Learn how it works')
  || await hit(p, 'button, a', 'What the numbers mean');
await wait(700);
if (!gotLearn) console.log('MISS learning overview entry');
await shoot(p, 'v-learning', true);
await p.close();

// 4+5. narrow widths
for (const w of [720, 420]) {
  p = await fresh(w);
  await toExplore(p);
  await shoot(p, `v-explore-${w}`);
  await page_picker(p, w);
  await addTwo(p);
  await hit(p, 'button', 'Run Screener');
  await wait(3200);
  await shoot(p, `v-results-${w}`);
  await p.close();
}

async function page_picker(page, w) {
  await page.evaluate(() => [...document.querySelectorAll('button')]
    .find((b) => /add (more )?filters|tap to add/i.test(b.textContent || ''))?.click());
  await wait(380);
  await shoot(page, `v-picker-${w}`);
  await page.evaluate(() => [...document.querySelectorAll('.picker-foot button, .picker__foot button')]
    .find((b) => /apply|done/i.test(b.textContent))?.click());
  await wait(240);
}

console.log('errors:', errors.length ? errors.slice(0, 4).join(' | ') : 'none');
await browser.close();
