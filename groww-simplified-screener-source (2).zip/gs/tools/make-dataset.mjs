/**
 * Generates src/data/stocks.ts — the demo universe.
 * Companies are fictional; every figure is produced here from sector and
 * archetype ranges with a fixed seed, so the dataset is reproducible and
 * internally coherent (valuation follows growth and quality, cash follows
 * margins, and so on). Field names follow the data dictionary in the spec.
 */
import { readFileSync, writeFileSync } from 'node:fs';

let seed = 20260919;
const rnd = () => {
  seed = (seed + 0x6d2b79f5) >>> 0;
  let t = seed;
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};
const between = (a, b) => a + rnd() * (b - a);
const r1 = (x) => Math.round(x * 10) / 10;
const r2 = (x) => Math.round(x * 100) / 100;
const pick = (arr) => arr[Math.floor(rnd() * arr.length)];

/* sector shapes: margins, valuation base, capital intensity */
const SECTORS = {
  'Banking & Finance': { margin: [20, 30], peBase: 16, pbBase: 2.4, capex: [0.5, 2], lender: true },
  'IT Services':       { margin: [18, 27], peBase: 27, pbBase: 6.5, capex: [2, 5] },
  'FMCG':              { margin: [14, 24], peBase: 42, pbBase: 9,   capex: [3, 6] },
  'Pharma':            { margin: [16, 26], peBase: 30, pbBase: 5.4, capex: [5, 9] },
  'Auto & Ancillaries':{ margin: [10, 17], peBase: 21, pbBase: 3.2, capex: [5, 10] },
  'Cement & Materials':{ margin: [14, 22], peBase: 22, pbBase: 2.8, capex: [7, 13] },
  'Energy':            { margin: [9, 18],  peBase: 13, pbBase: 1.5, capex: [8, 15] },
  'Specialty Chemicals':{ margin: [15, 24], peBase: 29, pbBase: 5.2, capex: [6, 11] },
  'Consumer Durables': { margin: [9, 16],  peBase: 34, pbBase: 6.2, capex: [3, 6] },
  'Retail':            { margin: [4, 9],   peBase: 45, pbBase: 5.5, capex: [4, 8] },
  'Metals':            { margin: [11, 20], peBase: 10, pbBase: 1.3, capex: [8, 14] },
  'Realty':            { margin: [15, 25], peBase: 24, pbBase: 3.1, capex: [6, 12] },
  'Infrastructure & Logistics': { margin: [10, 18], peBase: 20, pbBase: 2.6, capex: [7, 13] },
  'Telecom':           { margin: [28, 40], peBase: 34, pbBase: 5.1, capex: [14, 22] },
  'Textiles':          { margin: [7, 13],  peBase: 14, pbBase: 1.4, capex: [5, 9] },
  'Hospitality':       { margin: [12, 22], peBase: 37, pbBase: 4.4, capex: [8, 14] },
};

/* archetypes: how a company behaves across growth, quality, price and trend */
const ARCH = {
  compounder:  { revG: [10, 16], patG: [12, 20], roe: [18, 28], de: [0, 0.25], peMul: [1.15, 1.4], cons: [4, 5], vol: [13, 21], ret1y: [10, 26], ret3y: [12, 22], div: [0.4, 1.2] },
  quality:     { revG: [7, 13],  patG: [8, 15],  roe: [16, 24], de: [0.1, 0.5], peMul: [0.95, 1.2], cons: [4, 5], vol: [14, 22], ret1y: [6, 20],  ret3y: [9, 17],  div: [0.8, 2.2] },
  growth:      { revG: [18, 30], patG: [20, 34], roe: [15, 24], de: [0.1, 0.6], peMul: [1.3, 1.9], cons: [3, 5], vol: [24, 36], ret1y: [22, 58], ret3y: [18, 34], div: [0, 0.4] },
  value:       { revG: [3, 9],   patG: [2, 9],   roe: [9, 15],  de: [0.3, 0.9], peMul: [0.55, 0.8], cons: [2, 4], vol: [19, 29], ret1y: [-8, 12], ret3y: [2, 11],  div: [1.8, 4.2] },
  cyclical:    { revG: [4, 14],  patG: [-4, 18], roe: [8, 18],  de: [0.4, 1.3], peMul: [0.6, 1.0], cons: [2, 3], vol: [27, 40], ret1y: [-14, 38],ret3y: [4, 24],  div: [0.6, 2.6] },
  turnaround:  { revG: [1, 7],   patG: [-6, 8],  roe: [6, 12],  de: [0.5, 1.2], peMul: [0.7, 1.0], cons: [1, 3], vol: [24, 34], ret1y: [6, 22],  ret3y: [-2, 7],  div: [0, 1.2] },
  dividend:    { revG: [3, 8],   patG: [3, 9],   roe: [13, 20], de: [0.2, 0.7], peMul: [0.75, 1.0], cons: [4, 5], vol: [12, 19], ret1y: [2, 14],  ret3y: [5, 12],  div: [2.8, 5.5] },
  laggard:     { revG: [-2, 5],  patG: [-14, 3], roe: [4, 10],  de: [0.6, 1.6], peMul: [0.6, 0.95], cons: [0, 2], vol: [26, 40], ret1y: [-34, -4],ret3y: [-6, 4],  div: [0, 1.4] },
  lossmaker:   { revG: [-4, 8],  patG: null,     roe: [-14, -2],de: [0.7, 1.8], peMul: null,       cons: [0, 1], vol: [32, 46], ret1y: [-40, -8],ret3y: [-12, 2], div: [0, 0] },
  newlisting:  { revG: [14, 28], patG: [10, 26], roe: [7, 16],  de: [0.1, 0.7], peMul: [1.2, 1.8], cons: null,   vol: [28, 40], ret1y: [-12, 40],ret3y: null,     div: [0, 0.6] },
};

/* 62 fictional companies: name, symbol, sector, archetype */
const COMPANIES = [
  ['Sundale Bank', 'SUNDBANK', 'Banking & Finance', 'quality'],
  ['Meridian Finserv', 'MERIFIN', 'Banking & Finance', 'growth'],
  ['Arcus Bank', 'ARCUSBK', 'Banking & Finance', 'turnaround'],
  ['Kaveri Bank', 'KAVERIBK', 'Banking & Finance', 'compounder'],
  ['Dhanvi Capital', 'DHANVI', 'Banking & Finance', 'value'],
  ['Saptagiri Housing Finance', 'SAPTHF', 'Banking & Finance', 'dividend'],
  ['Velora Software', 'VELORA', 'IT Services', 'compounder'],
  ['Nexthorn Technologies', 'NXTHORN', 'IT Services', 'growth'],
  ['Quantile Systems', 'QNTL', 'IT Services', 'laggard'],
  ['Aravalli Digital', 'ARAVDIG', 'IT Services', 'quality'],
  ['Pralay Cloudworks', 'PRALAY', 'IT Services', 'newlisting'],
  ['Kesari Consumer', 'KESARI', 'FMCG', 'compounder'],
  ['Anantam Foods', 'ANANTAM', 'FMCG', 'growth'],
  ['Pravan Dairy', 'PRAVAN', 'FMCG', 'turnaround'],
  ['Madhuban Staples', 'MADHUBAN', 'FMCG', 'dividend'],
  ['Surabhi Beverages', 'SURABHI', 'FMCG', 'quality'],
  ['Zylix Pharma', 'ZYLIX', 'Pharma', 'compounder'],
  ['Hemadri Life Sciences', 'HEMLIFE', 'Pharma', 'growth'],
  ['Saral Healthcare', 'SARALHC', 'Pharma', 'lossmaker'],
  ['Trinetra Labs', 'TRINLAB', 'Pharma', 'quality'],
  ['Osmia Biotech', 'OSMIA', 'Pharma', 'newlisting'],
  ['Bharatiya Motors', 'BHARMOT', 'Auto & Ancillaries', 'cyclical'],
  ['Girnar Auto Components', 'GIRNAR', 'Auto & Ancillaries', 'turnaround'],
  ['Vaayu Mobility', 'VAAYU', 'Auto & Ancillaries', 'growth'],
  ['Shakti Forgings', 'SHAKFRG', 'Auto & Ancillaries', 'value'],
  ['Shravasti Cements', 'SHRACEM', 'Cement & Materials', 'quality'],
  ['Deccan Ceramics', 'DECCERAM', 'Cement & Materials', 'laggard'],
  ['Naveli Buildmart', 'NAVELI', 'Cement & Materials', 'cyclical'],
  ['Agnisar Power', 'AGNIPWR', 'Energy', 'dividend'],
  ['Tarangini Gas', 'TARGAS', 'Energy', 'value'],
  ['Udaan Renewables', 'UDAANRE', 'Energy', 'growth'],
  ['Samudra Petro', 'SAMPETRO', 'Energy', 'cyclical'],
  ['Vistara Chemicals', 'VISTCHEM', 'Specialty Chemicals', 'compounder'],
  ['Ridhima Polymers', 'RIDHIMA', 'Specialty Chemicals', 'laggard'],
  ['Kalpataru Specialities', 'KALPSPL', 'Specialty Chemicals', 'quality'],
  ['Ujjwal Appliances', 'UJJWAL', 'Consumer Durables', 'compounder'],
  ['Ashvi Electricals', 'ASHVIEL', 'Consumer Durables', 'turnaround'],
  ['Rohini Homeware', 'ROHINI', 'Consumer Durables', 'growth'],
  ['Neelkanth Retail', 'NEELRET', 'Retail', 'growth'],
  ['Chandrika Mart', 'CHANMART', 'Retail', 'newlisting'],
  ['Tulsi Bazaar', 'TULSIBZ', 'Retail', 'value'],
  ['Mahasagar Metals', 'MAHAMET', 'Metals', 'value'],
  ['Girija Steel', 'GIRSTEEL', 'Metals', 'cyclical'],
  ['Lohit Alloys', 'LOHIT', 'Metals', 'laggard'],
  ['Suvarna Realty', 'SUVREAL', 'Realty', 'growth'],
  ['Meghdoot Estates', 'MEGHEST', 'Realty', 'lossmaker'],
  ['Prastha Developers', 'PRASTHA', 'Realty', 'cyclical'],
  ['Konark Infra', 'KONARK', 'Infrastructure & Logistics', 'cyclical'],
  ['Prithvi Logistics', 'PRITHLOG', 'Infrastructure & Logistics', 'compounder'],
  ['Setubandh Projects', 'SETUBAN', 'Infrastructure & Logistics', 'turnaround'],
  ['Aakash Ports', 'AAKASHP', 'Infrastructure & Logistics', 'quality'],
  ['Aarav Telecom', 'AARAVTEL', 'Telecom', 'growth'],
  ['Sanchar Networks', 'SANCHAR', 'Telecom', 'value'],
  ['Vaani Broadband', 'VAANIBB', 'Telecom', 'laggard'],
  ['Tanvi Textiles', 'TANVITEX', 'Textiles', 'value'],
  ['Mirai Apparel', 'MIRAIAP', 'Textiles', 'turnaround'],
  ['Charu Fabrics', 'CHARUFAB', 'Textiles', 'dividend'],
  ['Vrinda Hotels', 'VRINDAH', 'Hospitality', 'growth'],
  ['Anokhi Resorts', 'ANOKHIR', 'Hospitality', 'cyclical'],
  ['Sarovar Leisure', 'SAROVAR', 'Hospitality', 'newlisting'],
  ['Kartavya Foods', 'KARTAVYA', 'FMCG', 'value'],
];

const slug = (name) => name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

const rows = COMPANIES.map(([name, symbol, sector, archetype]) => {
  const S = SECTORS[sector];
  const A = ARCH[archetype];
  const lender = !!S.lender;
  const loss = archetype === 'lossmaker';
  const fresh = archetype === 'newlisting';

  const revenueCagr3Y = fresh ? null : r1(between(...A.revG));
  const revenueCagr5Y = fresh ? null : r1(revenueCagr3Y + between(-3, 3));
  const revenueYoY = r1((revenueCagr3Y ?? between(...A.revG)) + between(-4, 5));
  const patCagr3Y = loss || fresh || !A.patG ? null : r1(between(...A.patG));
  const patYoY = loss ? null : r1((patCagr3Y ?? between(8, 22)) + between(-6, 7));
  const epsCagr3Y = patCagr3Y === null ? null : r1(patCagr3Y + between(-2.5, 1.5));
  const profitConsistency = fresh ? null : Math.round(between(...A.cons));
  const revenueUpYears = fresh ? null : Math.min(5, profitConsistency + (rnd() > 0.4 ? 1 : 0));

  const ebitdaMargin = r1(between(...S.margin) + (archetype === 'laggard' || loss ? -4 : archetype === 'compounder' ? 3 : 0));
  const netMargin = r1(Math.max(loss ? -12 : 1.2, ebitdaMargin * between(0.42, 0.68)));
  const marginTrendBps = Math.round(between(archetype === 'laggard' || loss ? -320 : -60, archetype === 'growth' || archetype === 'compounder' ? 320 : 140));

  const roe = r1(between(...A.roe));
  const roce = lender ? null : r1(roe * between(0.85, 1.25));
  const roa = lender ? r1(roe * between(0.09, 0.14)) : r1(roe * between(0.45, 0.8));

  const debtToEquity = lender ? null : r2(between(...A.de));
  const netDebtEbitda = lender ? null : r1(debtToEquity * between(1.4, 3.2) - (rnd() > 0.75 ? between(0.6, 2.2) : 0));
  const interestCoverage = lender ? null : r1(Math.max(0.8, (12 - debtToEquity * 7) * between(0.6, 1.8)));
  const currentRatio = lender ? null : r2(between(0.9, 2.6));
  const capitalAdequacy = lender ? r1(between(13.2, 19.4)) : null;
  const gnpa = lender ? r1(between(1.1, 5.4)) : null;
  const nim = lender ? r1(between(2.8, 4.6)) : null;

  const cfoPatRatio = loss ? r2(between(-0.4, 0.5)) : r2(between(archetype === 'laggard' ? 0.5 : 0.75, archetype === 'compounder' ? 1.35 : 1.15));
  const cfoPositive = !loss && cfoPatRatio > 0.15;
  const capexRevenue = r1(between(...S.capex) * (archetype === 'growth' ? 1.4 : 1));
  const fcfPositive = cfoPositive && capexRevenue < ebitdaMargin * between(0.5, 0.9);
  const cfoUpYears = fresh ? null : Math.round(between(loss ? 0 : 2, 5));

  const marketCap = Math.round(between(1800, 46000) * (archetype === 'compounder' || archetype === 'quality' ? between(1.8, 9) : between(0.7, 3.4)));
  const price = r2(between(90, 3900));
  const changePct1D = r2(between(-3.2, 3.4));
  const avgDailyValue = Math.round(Math.max(6, marketCap * between(0.0006, 0.0045)));
  const freeFloatPct = r1(between(28, 88));
  const listedYears = fresh ? r1(between(0.6, 2.6)) : Math.round(between(6, 34));

  const peMulRange = A.peMul ?? [1, 1];
  const pe = loss ? null : r1(S.peBase * between(...peMulRange) * between(0.9, 1.12));
  const pb = r1(S.pbBase * between(...peMulRange) * between(0.85, 1.15) * (lender ? 1 : 1));
  const evEbitda = loss ? null : r1(Math.max(3, (pe ?? 18) * between(0.45, 0.75)));
  const evSales = r1(Math.max(0.4, (evEbitda ?? 8) * (ebitdaMargin / 100) * between(0.85, 1.2)));
  const peg = pe && patCagr3Y && patCagr3Y > 0 ? r2(pe / patCagr3Y) : null;
  const earningsYield = pe ? r1(100 / pe) : null;

  const return1Y = r1(between(...A.ret1y));
  const return3Y = A.ret3y ? r1(between(...A.ret3y)) : null;
  const return5Y = A.ret3y ? r1(between(...A.ret3y) * between(0.75, 1.15)) : null;
  const return6M = r1(return1Y * between(0.35, 0.75) + between(-5, 5));
  const return3M = r1(return1Y * between(0.15, 0.45) + between(-5, 5));
  const return1M = r1(return3M * between(0.2, 0.6) + between(-4, 4));
  const volatility = r1(between(...A.vol));
  const beta = r2(Math.max(0.45, volatility / between(20, 30)));
  const maxDrawdown1Y = r1(-Math.abs(volatility * between(0.7, 1.5)));
  const downsideDeviation = r1(volatility * between(0.45, 0.75));

  const trendUp = return3M > 0;
  const priceVs50DMA = r1(return3M * between(0.2, 0.5) + between(-3, 3));
  const priceVs200DMA = r1(return1Y * between(0.25, 0.5) + between(-5, 5));
  const priceVs20DMA = r1(priceVs50DMA * between(0.5, 1.2) + between(-2, 2));
  const ma50Slope = r2(priceVs50DMA * between(0.05, 0.2));
  const rsi = Math.round(Math.max(14, Math.min(86, 50 + return3M * between(1.1, 1.9) + between(-5, 5))));
  const distance52wHigh = r1(-Math.abs(between(0.5, 34) * (trendUp ? 0.5 : 1.4)));
  const volumeRatio = r2(between(0.6, 2.3));

  const dividendYield = r2(between(...A.div));
  const payoutRatio = dividendYield > 0 ? Math.round(Math.min(82, dividendYield * (pe ?? 18) * between(0.8, 1.2))) : 0;
  const dpsCagr5Y = dividendYield > 0.5 ? r1(between(-2, 16)) : null;
  const dividendStreak = dividendYield > 0.5 ? Math.round(between(2, 14)) : 0;

  const promoterHolding = r1(between(24, 74));
  const promoterPledge = rnd() > 0.78 ? r1(between(2, 28)) : 0;
  const fiiHolding = r1(between(2, 26));

  return {
    id: slug(name), name, symbol, sector, archetype,
    price, change1D: r2(price * changePct1D / 100), changePct1D,
    marketCap, avgDailyValue, freeFloatPct, listedYears,
    revenueYoY, revenueCagr3Y, revenueCagr5Y, patYoY, patCagr3Y, epsCagr3Y,
    profitConsistency, revenueUpYears,
    ebitdaMargin, netMargin, marginTrendBps,
    roe, roce, roa,
    debtToEquity, netDebtEbitda, interestCoverage, currentRatio,
    capitalAdequacy, gnpa, nim,
    cfoPositive, cfoPatRatio, fcfPositive, capexRevenue, cfoUpYears,
    pe, pb, evEbitda, evSales, peg, earningsYield,
    return1M, return3M, return6M, return1Y, return3Y, return5Y,
    volatility, beta, maxDrawdown1Y, downsideDeviation,
    rsi, priceVs20DMA, priceVs50DMA, priceVs200DMA, ma50Slope, distance52wHigh, volumeRatio,
    dividendYield, payoutRatio, dpsCagr5Y, dividendStreak,
    promoterHolding, promoterPledge, fiiHolding,
  };
});

const lines = rows.map((r) => {
  const entries = Object.entries(r)
    .filter(([k]) => k !== 'archetype')
    .map(([k, v]) => `${k}: ${typeof v === 'string' ? JSON.stringify(v) : v}`);
  return `  { ${entries.join(', ')} },`;
});

const header = `/**
 * DEMO DATA ONLY.
 * Every company below is fictional and every number is generated for this
 * prototype by tools/make-dataset.mjs from sector and archetype ranges with a
 * fixed seed. Nothing here is live market data, and nothing here describes a
 * real listed company. Field names follow the product data dictionary.
 */

export const SNAPSHOT_LABEL = '12 Sep 2026, end of day';
export const RULE_VERSION = 'rules v2.0';

export type Sector =
${Object.keys(SECTORS).map((s) => `  | ${JSON.stringify(s)}`).join('\n')};

export interface Stock {
  id: string; name: string; symbol: string; sector: Sector;
  /** price and market */
  price: number; change1D: number; changePct1D: number;
  marketCap: number; avgDailyValue: number; freeFloatPct: number; listedYears: number;
  /** growth */
  revenueYoY: number; revenueCagr3Y: number | null; revenueCagr5Y: number | null;
  patYoY: number | null; patCagr3Y: number | null; epsCagr3Y: number | null;
  profitConsistency: number | null; revenueUpYears: number | null;
  /** profitability */
  ebitdaMargin: number; netMargin: number; marginTrendBps: number;
  roe: number; roce: number | null; roa: number;
  /** balance sheet */
  debtToEquity: number | null; netDebtEbitda: number | null;
  interestCoverage: number | null; currentRatio: number | null;
  capitalAdequacy: number | null; gnpa: number | null; nim: number | null;
  /** cash flow */
  cfoPositive: boolean; cfoPatRatio: number; fcfPositive: boolean;
  capexRevenue: number; cfoUpYears: number | null;
  /** valuation */
  pe: number | null; pb: number; evEbitda: number | null; evSales: number;
  peg: number | null; earningsYield: number | null;
  /** performance */
  return1M: number; return3M: number; return6M: number;
  return1Y: number; return3Y: number | null; return5Y: number | null;
  volatility: number; beta: number; maxDrawdown1Y: number; downsideDeviation: number;
  /** momentum */
  rsi: number; priceVs20DMA: number; priceVs50DMA: number; priceVs200DMA: number;
  ma50Slope: number; distance52wHigh: number; volumeRatio: number;
  /** dividends */
  dividendYield: number; payoutRatio: number; dpsCagr5Y: number | null; dividendStreak: number;
  /** ownership */
  promoterHolding: number; promoterPledge: number; fiiHolding: number;
}

export const STOCKS: Stock[] = [
${lines.join('\n')}
];
`;

const helpers = readFileSync(new URL('./stocks-helpers.txt', import.meta.url), 'utf8');
writeFileSync(new URL('../src/data/stocks.ts', import.meta.url), `${header}\n${helpers}`);
console.log('generated', rows.length, 'companies');
const bySector = {};
rows.forEach((r) => { bySector[r.sector] = (bySector[r.sector] || 0) + 1; });
console.log(Object.entries(bySector).map(([k, v]) => `${k}:${v}`).join('  '));
console.log('loss-makers', rows.filter((r) => r.pe === null).length, '| new listings', rows.filter((r) => r.listedYears < 3).length, '| lenders', rows.filter((r) => r.capitalAdequacy !== null).length);
