import puppeteer from 'puppeteer';
const FILE = 'file:///mnt/user-data/outputs/groww-simplified-screener.html';
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const clickText = async (page, sel, text) => {
  const ok = await page.evaluate((s, t) => {
    const el = [...document.querySelectorAll(s)].find((e) => e.textContent.trim().startsWith(t));
    if (!el) return false; el.click(); return true;
  }, sel, text);
  if (!ok) throw new Error(`not found: ${text}`);
  await wait(240);
};
const b = await puppeteer.launch({ args: ['--no-sandbox'] });
const page = await b.newPage();
await page.setViewport({ width: 1440, height: 1000, deviceScaleFactor: 2 });
await page.goto(FILE, { waitUntil: 'networkidle0' });
await page.evaluate(() => localStorage.clear());
await page.reload({ waitUntil: 'networkidle0' });
await wait(450);
await page.evaluate(() => [...document.querySelectorAll('button')]
  .find((x) => /theme/i.test(x.getAttribute('aria-label') || ''))?.click());
await wait(200);
await clickText(page, '.btn', 'Explore the screener');
await page.evaluate(() => [...document.querySelectorAll('.coach-card .btn')].find((x) => x.textContent.includes('Skip'))?.click());
await wait(200);
await clickText(page, '.btn', 'Add filters');
await wait(400);

const row = await page.evaluateHandle(() =>
  [...document.querySelectorAll('.picker-row')].find((e) => e.textContent.includes('Growing fast')));
const rb = await row.asElement().boundingBox();
const drop = await (await page.$('.dropzone')).boundingBox();

await page.mouse.move(rb.x + 90, rb.y + rb.height / 2);
await page.mouse.down();
await page.mouse.move(rb.x + 140, rb.y + rb.height / 2 - 20, { steps: 6 });
await wait(160);
await page.screenshot({ path: '/home/claude/drag-1-lift.png', clip: { x: 0, y: 60, width: 1440, height: 640 } });

await page.mouse.move(drop.x + drop.width / 2, drop.y + drop.height / 2, { steps: 24 });
await wait(220);
console.log('body flags:', await page.evaluate(() => JSON.stringify(document.body.dataset)));
await page.screenshot({ path: '/home/claude/drag-2-over.png', clip: { x: 0, y: 60, width: 1440, height: 640 } });

await page.mouse.up();
await wait(120);
await page.screenshot({ path: '/home/claude/drag-3-landing.png', clip: { x: 0, y: 60, width: 1440, height: 640 } });
await wait(500);
console.log('chips after drop:', await page.evaluate(() => [...document.querySelectorAll('.stmt-chip')].map((c) => c.textContent.trim())));
console.log('flags cleared:', await page.evaluate(() => JSON.stringify(document.body.dataset)));
console.log('ghost removed:', await page.evaluate(() => !document.querySelector('.drag-ghost')));

// and a drag that is released over nothing
const row2 = await page.evaluateHandle(() =>
  [...document.querySelectorAll('.picker-row')].find((e) => e.textContent.includes('Sales growth')));
const rb2 = await row2.asElement().boundingBox();
await page.mouse.move(rb2.x + 90, rb2.y + rb2.height / 2);
await page.mouse.down();
await page.mouse.move(rb2.x + 260, rb2.y + 240, { steps: 14 });
await wait(200);
await page.mouse.up();
await wait(400);
console.log('chips after a cancelled drag:', await page.evaluate(() => document.querySelectorAll('.stmt-chip').length));
await b.close();
console.log('drag shots written');
