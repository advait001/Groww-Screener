import puppeteer from 'puppeteer';
const FILE = 'file:///mnt/user-data/outputs/groww-simplified-screener.html';
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const clickText = async (page, sel, text) => {
  const ok = await page.evaluate((s, t) => {
    const el = [...document.querySelectorAll(s)].find((e) => e.textContent.trim().startsWith(t));
    if (!el) return false; el.click(); return true;
  }, sel, text);
  if (!ok) throw new Error(`not found: ${text}`);
  await wait(240);
};
const b = await puppeteer.launch({ args: ['--no-sandbox'] });
for (const [name, dark] of [['light', false], ['dark', true]]) {
  const page = await b.newPage();
  await page.setViewport({ width: 1440, height: 1100, deviceScaleFactor: 2 });
  await page.goto(FILE, { waitUntil: 'networkidle0' });
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle0' });
  await wait(420);
  if (dark) {
    await page.evaluate(() => [...document.querySelectorAll('button')]
      .find((x) => /theme/i.test(x.getAttribute('aria-label') || ''))?.click());
    await wait(200);
  }
  await clickText(page, '.btn', 'Explore the screener');
  await page.evaluate(() => [...document.querySelectorAll('.coach-card .btn')].find((x) => x.textContent.includes('Skip'))?.click());
  await wait(200);
  await clickText(page, '.btn', 'Add filters');
  await clickText(page, '.picker-row', 'Cash backed');
  await clickText(page, '.picker-row', 'Growing steadily');
  await clickText(page, '.picker-foot .btn', 'Done');
  await wait(300);
  // open the lesson straight from the statement's indicator pills
  await page.evaluate(() => {
    const el = [...document.querySelectorAll('button, .chip, .pill, .indicator-tag')]
      .find((e) => e.textContent.trim() === 'Cash conversion');
    if (!el) throw new Error('no cash conversion pill');
    el.click();
  });
  await wait(400);
  let modal = await page.$('.modal');
  let box = await modal.boundingBox();
  await page.screenshot({ path: `/home/claude/lesson-${name}.png`,
    clip: { x: box.x - 6, y: box.y - 6, width: box.width + 12, height: box.height + 12 } });
  // and with the maths revealed
  await page.evaluate(() => [...document.querySelectorAll('.lesson__more .link-btn')][0]?.click());
  await wait(200);
  modal = await page.$('.modal'); box = await modal.boundingBox();
  await page.screenshot({ path: `/home/claude/lesson-${name}-deep.png`,
    clip: { x: box.x - 6, y: box.y - 6, width: box.width + 12, height: box.height + 12 } });
  await page.close();
}
await b.close();
console.log('lesson shots written');
