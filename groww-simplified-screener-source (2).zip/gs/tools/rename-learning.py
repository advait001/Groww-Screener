#!/usr/bin/env python3
"""
Plain-language pass over the learning screens.

The filters, categories and templates were rewritten by tools/rename-plain.py.
The learning flow was written in the old voice ("indicators", "screener
statement", "the logic") and is the last place a ten-year-old would stall.
This rewrites that chrome copy while KEEPING the real indicator names
(Revenue Growth, Price Swings...) — bridging the plain filter name to the
real financial term is the whole point of these screens.

Run with: python3 -I tools/rename-learning.py
"""
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent

EDITS = {
    'src/ui/sidebars.tsx': [
        ('Indicators Used → Why They Were Used → How They Work, the learning journey.',
         'What we checked → Why it matters → How it works, the learning journey.'),
        ('<h2>Screener Learning</h2>', '<h2>Learn as you go</h2>'),
        ('Understand how Groww builds your screen.',
         'See what is behind every filter you picked.'),
        ('label="Indicators Used" sub="See the key indicators"',
         'label="What we checked" sub="The numbers behind your filters"'),
        ('label="Why They Were Used" sub="Understand the logic"',
         'label="Why it matters" sub="What each one tells you"'),
        ('label="How They Work" sub="Learn with simple examples"',
         'label="How it works" sub="Simple examples"'),
        ('“Better investors learn how things work.”',
         '“The more you understand, the better you choose.”'),
    ],
    'src/screens/Learning.tsx': [
        ("steps={['Indicators Used', 'Why They Were Used', 'How They Work']}",
         "steps={['What we checked', 'Why it matters', 'How it works']}"),
        ('<h1>How Groww built your screen</h1>',
         '<h1>What your filters really check</h1>'),
        ('Your selected filters are powered by key financial indicators. Here’s how they connect.',
         'Everything you picked turns into a real number we can measure. Here is which one.'),
        ('<h2>No filters to explain yet</h2>', '<h2>Nothing to explain yet</h2>'),
        ('Pick a couple of preferences on the screener and this page will show exactly which indicators they turn into.',
         'Pick a couple of filters and this page will show you the real numbers behind them.'),
        ('<h2>Your screener statement</h2>', '<h2>What you asked for</h2>'),
        ('These filters work together to find companies that match your preferences.',
         'All of these have to be true before a company shows up on your list.'),
        ('<h2>Indicators used in the background</h2>', '<h2>The number behind each one</h2>'),
        ('Each filter is based on one or more financial indicators.',
         'Every filter is measured by a real number. Tap one to learn what it means.'),
        ('<IconCheckCircle size={14} /> Why we used it', '<IconCheckCircle size={14} /> Why this matters'),
        ('<span className="tiny faint">Also checks</span>',
         '<span className="tiny faint">Also looks at</span>'),
        ('A quick guide to this learning experience.', 'Three things this page shows you.'),
        ('title="What each indicator means" body="Understand it in simple terms."',
         'title="What each number means" body="Said in plain words."'),
        ('title="Why Groww checked it" body="See the logic behind each choice."',
         'title="Why we checked it" body="The reason behind each one."'),
        ('title="How it helps screen stocks" body="Know how it changes the results."',
         'title="How it changes your list" body="See what happens when you use it."'),
        ('A good screen looks at multiple factors, not just one. This helps you see a more balanced picture.',
         'A good screen looks at a few things, not just one. That gives you a fairer picture of a company.'),
        ('<b>Same screen, smarter investing</b>', '<b>Same screen, better understood</b>'),
        ('<span>Learn at your own pace</span>', '<span>Go at your own speed</span>'),
    ],
    'src/screens/IndicatorLearning.tsx': [
        ("'Back to indicators'", "'Back to the numbers'"),
        ('<h1>Understand this indicator</h1>', '<h1>What this number means</h1>'),
        ('Nothing in your current screen uses this indicator. It is here so you can read ahead — add a',
         'Nothing in your screen uses this one right now. It is here so you can read ahead — add a'),
        ('Next indicator <IconArrowRight size={15} />', 'Next number <IconArrowRight size={15} />'),
        ('<h2 style={{ fontSize: 17 }}>Related indicators</h2>',
         '<h2 style={{ fontSize: 17 }}>Close to this one</h2>'),
        ('<span className="small muted">See every indicator behind your screen.</span>',
         '<span className="small muted">See every number behind your screen.</span>'),
    ],
}

missed = []
for rel, pairs in EDITS.items():
    path = ROOT / rel
    src = path.read_text()
    for old, new in pairs:
        if old not in src:
            missed.append(f'{rel}: {old[:60]}')
            continue
        src = src.replace(old, new)
    path.write_text(src)
    print('rewrote', rel)

if missed:
    print('\nMISSED:')
    for m in missed:
        print(' ', m)
    sys.exit(1)
print('\nall replacements applied')
