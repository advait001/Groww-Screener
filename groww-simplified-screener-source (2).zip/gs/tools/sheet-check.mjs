/**
 * Confirms the prototype really posts to the configured endpoint.
 *
 * Requests to script.google.com are intercepted and aborted, so this proves
 * the client side works without writing rows into the live sheet.
 */
import puppeteer from 'puppeteer';

const FILE = 'file:///mnt/user-data/outputs/groww-simplified-screener.html';
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
const page = await browser.newPage();
await page.setViewport({ width: 1512, height: 1000 });

const sent = [];
await page.setRequestInterception(true);
page.on('request', (req) => {
  if (req.url().includes('script.google.com')) {
    sent.push({ method: req.method(), body: req.postData() });
    req.abort();                       // never reaches the real sheet
    return;
  }
  req.continue();
});

await page.goto(FILE, { waitUntil: 'networkidle0' });
await page.evaluate(() => localStorage.clear());
await page.reload({ waitUntil: 'networkidle0' });
await wait(500);

// onboarding step one asks who you are
await page.evaluate(() => [...document.querySelectorAll('.btn')]
  .find((b) => /get started/i.test(b.textContent || ''))?.click());
await wait(400);
await page.type('#ob-name', 'Test Visitor');
await page.type('#ob-email', 'visitor@example.com');
await page.evaluate(() => [...document.querySelectorAll('.onb__actions .btn')]
  .find((b) => /continue/i.test(b.textContent || ''))?.click());
await wait(400);

// skip the remaining profile questions and head for the screener
await page.evaluate(() => [...document.querySelectorAll('.onb__step .link-btn')]
  .find((b) => /skip for now/i.test(b.textContent || ''))?.click());
await wait(500);
await page.evaluate(() => [...document.querySelectorAll('.coach-card button')]
  .find((b) => /skip/i.test(b.textContent))?.click());
await wait(300);

for (const label of ['Grows a little every year', 'Calm and steady']) {
  await page.evaluate(() => [...document.querySelectorAll('button')]
    .find((b) => /add (more )?filters|tap to add/i.test(b.textContent || ''))?.click());
  await wait(340);
  await page.evaluate((t) => [...document.querySelectorAll('.picker-row')]
    .find((e) => (e.textContent || '').includes(t))?.click(), label);
  await page.evaluate(() => [...document.querySelectorAll('.picker-foot button')]
    .find((b) => /apply/i.test(b.textContent))?.click());
  await wait(280);
}
await page.evaluate(() => [...document.querySelectorAll('.ex-sentence .btn')]
  .find((b) => /run screener/i.test(b.textContent || ''))?.click());
await wait(2600);   // the processing screen runs for ~1.2s before results

// running the screen navigates away, so come back before the goal tile
await page.evaluate(() => [...document.querySelectorAll('.res-bar__edit')]
  .find((b) => /edit filters/i.test(b.textContent || ''))?.click());
await wait(500);
await page.evaluate(() => document.querySelector('.ex-goal')?.click());
await wait(500);

console.log(`requests to the endpoint: ${sent.length}`);
for (const r of sent) {
  let parsed = {};
  try { parsed = JSON.parse(r.body || '{}'); } catch { /* ignore */ }
  console.log(`  ${r.method}  ${String(parsed.event).padEnd(22)} ${parsed.name || '(none)'} <${parsed.email || ''}>`);
}
const events = sent.map((r) => { try { return JSON.parse(r.body).event; } catch { return ''; } });
const want = ['visitor_identified', 'screener_run', 'goal_planner_opened'];
const missing = want.filter((e) => !events.includes(e));
console.log(missing.length ? `MISSING: ${missing.join(', ')}` : 'all expected events were posted');
await browser.close();
