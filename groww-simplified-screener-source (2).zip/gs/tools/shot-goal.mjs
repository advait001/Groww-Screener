/** Drive the goal planner and capture it. `node tools/shot-goal.mjs [width]` */
import puppeteer from 'puppeteer';

const FILE = 'file:///mnt/user-data/outputs/groww-simplified-screener.html';
const OUT = '/tmp/claude-0/-home-claude/2cac05a6-3bef-5461-8d18-ade585261293/scratchpad/shots';
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const width = Number(process.argv[2] || 1512);
const tag = process.argv[2] ? `-${width}` : '';

const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
const page = await browser.newPage();
await page.setViewport({ width, height: 1000, deviceScaleFactor: 2 });
const errors = [];
page.on('pageerror', (e) => errors.push(String(e).slice(0, 200)));

const hit = (sel, text) => page.evaluate((s, t) => {
  const el = [...document.querySelectorAll(s)]
    .find((e) => (e.textContent || '').trim().toLowerCase().includes(t.toLowerCase()));
  if (!el) return false;
  el.click();
  return true;
}, sel, text);

const shoot = async (name, full = false) => {
  await page.screenshot({ path: `${OUT}/${name}${tag}.png`, fullPage: full });
  const o = await page.evaluate(() =>
    document.documentElement.scrollWidth - document.documentElement.clientWidth);
  console.log(name.padEnd(18), 'h-overflow:', o);
};

await page.goto(FILE, { waitUntil: 'networkidle0' });
await page.evaluate(() => localStorage.clear());
await page.reload({ waitUntil: 'networkidle0' });
await wait(450);

await hit('button', 'Explore the screener');
await wait(300);
await page.evaluate(() => [...document.querySelectorAll('.coach-card button')]
  .find((b) => /skip/i.test(b.textContent))?.click());
await wait(260);

if (!await hit('.ex-goal', 'Invest for a goal')) throw new Error('no goal tile');
await wait(400);
await shoot('goal-empty');

// a goal that does not add up: 50 lakh in 5 years on 5k a month
await hit('.gp-type', 'A home');
await wait(200);
await page.evaluate(() => {
  const set = (id, v) => {
    const el = document.getElementById(id);
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    setter.call(el, v);
    el.dispatchEvent(new Event('input', { bubbles: true }));
  };
  set('gp-goal', '5000000');
  set('gp-years', '5');
  set('gp-monthly', '5000');
});
await wait(260);
await hit('.gp-risk', 'Steady');
await wait(400);
await shoot('goal-short', true);

// take the first fix, then run the plan
if (!await hit('.gp-fixes button', '')) console.log('MISS: no fix to apply');
await wait(500);
await shoot('goal-fixed');

if (!await hit('.gp-check .btn', 'Show me the funds')) throw new Error('cannot submit');
await wait(600);
await shoot('goal-plan', true);

if (!await hit('.gp-check .btn', 'Start ')) console.log('MISS: invest button');
await wait(500);
await shoot('goal-invest');

console.log('errors:', errors.length ? errors.slice(0, 3).join(' | ') : 'none');
await browser.close();
