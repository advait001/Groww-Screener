/**
 * Groww Simplified Screener — Google Sheet endpoint.
 *
 * The prototype is a static file with no backend, so it posts rows here and
 * this script appends them to the sheet it is bound to.
 *
 * ── Setting it up ────────────────────────────────────────────────────────
 *  1. Open the Google Sheet you want the rows in.
 *  2. Extensions → Apps Script. Delete whatever is in the editor.
 *  3. Paste this whole file in and save.
 *  4. Deploy → New deployment → gear icon → Web app.
 *       Execute as:        Me
 *       Who has access:    Anyone
 *     "Anyone" is required — the prototype posts without signing in. The URL
 *     is unguessable, but treat it as public: anyone holding it can add rows.
 *  5. Authorise when prompted, then copy the deployment URL. It ends in /exec.
 *  6. Point the prototype at it, either by:
 *       • opening the prototype once with ?sheet=<that URL> on the end, which
 *         remembers it in that browser, or
 *       • pasting it into BUILT_IN_ENDPOINT in src/state/sheet.ts and
 *         rebuilding, which bakes it into the file for everyone.
 *
 * ── Changing it later ────────────────────────────────────────────────────
 * After editing this script, deploy again with Manage deployments → edit →
 * New version. Creating a *new* deployment instead gives you a different URL
 * and the prototype will keep posting to the old one.
 */

var SHEET_NAME = 'Responses';

function doPost(e) {
  var lock = LockService.getScriptLock();
  // two visitors can submit at the same moment; without this they can land
  // on the same row and one overwrites the other
  lock.waitLock(20000);
  try {
    var row = JSON.parse(e.postData.contents);
    sheetFor_().appendRow([
      new Date(),
      row.at || '',
      row.event || '',
      row.name || '',
      row.email || '',
      row.detail || '',
      row.session || ''
    ]);
    return json_({ ok: true });
  } catch (err) {
    return json_({ ok: false, error: String(err) });
  } finally {
    lock.releaseLock();
  }
}

/** Visiting the URL in a browser should say something, not throw. */
function doGet() {
  return ContentService.createTextOutput(
    'Groww Simplified Screener endpoint is live. Rows arrive by POST.'
  );
}

function sheetFor_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(SHEET_NAME) || ss.insertSheet(SHEET_NAME);
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(['Received', 'Client time', 'Event', 'Name', 'Email', 'Detail', 'Session']);
    sheet.setFrozenRows(1);
    sheet.getRange('A1:G1').setFontWeight('bold');
    sheet.setColumnWidth(1, 170);
    sheet.setColumnWidth(2, 200);
    sheet.setColumnWidth(3, 190);
    sheet.setColumnWidth(6, 320);
  }
  return sheet;
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

/** Run this once from the editor to check the sheet side works. */
function testAppend() {
  doPost({ postData: { contents: JSON.stringify({
    event: 'test_row', name: 'Test User', email: 'test@example.com',
    detail: '{"from":"Apps Script editor"}', at: new Date().toISOString(), session: 'manual'
  }) } });
}
