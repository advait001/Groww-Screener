/** Capture the onboarding contact step and the question after it. */
import puppeteer from 'puppeteer';
const FILE = 'file:///mnt/user-data/outputs/groww-simplified-screener.html';
const OUT = '/tmp/claude-0/-home-claude/2cac05a6-3bef-5461-8d18-ade585261293/scratchpad/shots';
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
const page = await browser.newPage();
await page.setViewport({ width: 1512, height: 1000, deviceScaleFactor: 2 });
const errs = []; page.on('pageerror', (e) => errs.push(String(e).slice(0, 160)));
await page.setRequestInterception(true);
page.on('request', (r) => (r.url().includes('script.google.com') ? r.abort() : r.continue()));

await page.goto(FILE, { waitUntil: 'networkidle0' });
await page.evaluate(() => localStorage.clear());
await page.reload({ waitUntil: 'networkidle0' });
await wait(500);
await page.evaluate(() => [...document.querySelectorAll('.btn')]
  .find((b) => /get started/i.test(b.textContent || ''))?.click());
await wait(400);
await page.screenshot({ path: `${OUT}/onb-contact.png` });
console.log('contact step:', await page.evaluate(() => (document.querySelector('.onb__step')?.textContent || '').trim()));

// empty submit shows errors
await page.evaluate(() => [...document.querySelectorAll('.onb__actions .btn')]
  .find((b) => /continue/i.test(b.textContent || ''))?.click());
await wait(200);
await page.screenshot({ path: `${OUT}/onb-contact-err.png` });
console.log('errors shown:', await page.evaluate(() => document.querySelectorAll('.onb__err').length));

await page.type('#ob-name', 'Priya Sharma');
await page.type('#ob-email', 'priya@example.com');
await page.evaluate(() => [...document.querySelectorAll('.onb__actions .btn')]
  .find((b) => /continue/i.test(b.textContent || ''))?.click());
await wait(400);
await page.screenshot({ path: `${OUT}/onb-q1.png` });
console.log('next step: ', await page.evaluate(() => (document.querySelector('.onb__step')?.textContent || '').trim()));
console.log('question:  ', await page.evaluate(() => (document.querySelector('.onb h1')?.textContent || '').trim()));
console.log('errors:', errs.length ? errs[0] : 'none');
await browser.close();
