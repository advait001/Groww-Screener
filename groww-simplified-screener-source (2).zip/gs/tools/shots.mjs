import puppeteer from 'puppeteer';
const FILE = 'file:///mnt/user-data/outputs/groww-simplified-screener.html';
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

const clickText = async (page, sel, text) => {
  const ok = await page.evaluate((s, t) => {
    const el = [...document.querySelectorAll(s)].find((e) => e.textContent.includes(t));
    if (!el) return false; el.click(); return true;
  }, sel, text);
  if (!ok) throw new Error(`not found: ${text}`);
  await wait(220);
};

const boot = async (page, dark) => {
  await page.goto(FILE, { waitUntil: 'networkidle0' });
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle0' });
  await wait(500);
  if (dark) {
    await page.evaluate(() => {
      const btn = [...document.querySelectorAll('button')].find((b) => /theme|dark|light/i.test(b.getAttribute('aria-label') || b.title || ''));
      btn?.click();
    });
    await wait(250);
    const theme = await page.evaluate(() => document.documentElement.getAttribute('data-theme'));
    if (theme !== 'dark') throw new Error(`theme did not switch (${theme})`);
  }
  await clickText(page, '.btn', 'Explore the screener');
  await page.evaluate(() => [...document.querySelectorAll('.coach-card .btn')].find((b) => b.textContent.includes('Skip'))?.click());
  await wait(250);
};

const browser = await puppeteer.launch({ args: ['--no-sandbox'] });

for (const [name, dark] of [['light', false], ['dark', true]]) {
  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 1000, deviceScaleFactor: 2 });
  await boot(page, dark);

  await clickText(page, '.btn', 'Add filters');
  await wait(300);
  await page.screenshot({ path: `/home/claude/v2-picker-${name}.png` });

  await clickText(page, '.picker-row', 'Growing steadily');
  await clickText(page, '.picker-row', 'Quality earnings');
  await clickText(page, '.picker-row', 'Low debt');
  await clickText(page, '.picker-foot .btn', 'Done');
  await wait(350);
  await page.screenshot({ path: `/home/claude/v2-build-${name}.png` });

  await clickText(page, '.run-row .btn', 'Run screener');
  await wait(2600);
  await page.screenshot({ path: `/home/claude/v2-results-${name}.png`, fullPage: false });
  await page.close();
}

// mobile: the picker becomes a sheet
const m = await browser.newPage();
await m.setViewport({ width: 420, height: 900, deviceScaleFactor: 2 });
await boot(m, false);
await clickText(m, '.btn', 'Add filters');
await wait(320);
await m.screenshot({ path: '/home/claude/v2-picker-mobile.png' });
const overflow = await m.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
console.log('mobile horizontal overflow:', overflow);
await m.close();

await browser.close();
console.log('shots written');
