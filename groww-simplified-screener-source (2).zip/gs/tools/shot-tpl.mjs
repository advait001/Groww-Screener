import puppeteer from 'puppeteer';
const FILE = 'file:///mnt/user-data/outputs/groww-simplified-screener.html';
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const clickText = async (page, sel, text) => {
  const ok = await page.evaluate((s, t) => {
    const el = [...document.querySelectorAll(s)].find((e) => e.textContent.trim().startsWith(t));
    if (!el) return false; el.click(); return true;
  }, sel, text);
  if (!ok) throw new Error(`not found: ${text}`);
  await wait(240);
};
const b = await puppeteer.launch({ args: ['--no-sandbox'] });
for (const [name, dark] of [['light', false], ['dark', true]]) {
  const page = await b.newPage();
  await page.setViewport({ width: 1440, height: 1100, deviceScaleFactor: 2 });
  await page.goto(FILE, { waitUntil: 'networkidle0' });
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle0' });
  await wait(420);
  if (dark) {
    await page.evaluate(() => [...document.querySelectorAll('button')]
      .find((x) => /theme/i.test(x.getAttribute('aria-label') || ''))?.click());
    await wait(200);
  }
  await clickText(page, '.btn', 'Explore the screener');
  await page.evaluate(() => [...document.querySelectorAll('.coach-card .btn')].find((x) => x.textContent.includes('Skip'))?.click());
  await wait(200);
  await clickText(page, '.head-btn', 'Guided templates');
  await wait(400);
  await page.screenshot({ path: `/home/claude/tpl-${name}.png` });
  // hover the fifth card to show the apply affordance
  const cards = await page.$$('.tpl-card');
  await cards[4].hover();
  await wait(250);
  await page.screenshot({ path: `/home/claude/tpl-${name}-hover.png` });
  await page.close();
}
await b.close();
console.log('template shots written');
