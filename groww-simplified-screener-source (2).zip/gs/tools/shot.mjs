/**
 * Screenshot helper. `node tools/shot.mjs <name> [step...]` drives the built
 * prototype and writes /tmp/.../shots/<name>.png. Steps:
 *   intro            stay on the welcome screen
 *   explore          enter the screener
 *   add:<label>      open the picker and tap that filter (repeatable)
 *   run              run the screen and wait for results
 *   why              open "why it matched" for the first result
 *   picker           leave the filter picker open
 *   tpl              open the guided templates
 *   learn            open the learning overview
 *   w:<px>           viewport width (default 1512)
 *   full             full-page screenshot
 */
import puppeteer from 'puppeteer';

const FILE = 'file:///mnt/user-data/outputs/groww-simplified-screener.html';
const OUT = '/tmp/claude-0/-home-claude/2cac05a6-3bef-5461-8d18-ade585261293/scratchpad/shots';
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

const [name, ...steps] = process.argv.slice(2);
const widthStep = steps.find((s) => s.startsWith('w:'));
const width = widthStep ? Number(widthStep.slice(2)) : 1512;
const full = steps.includes('full');

const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
const page = await browser.newPage();
await page.setViewport({ width, height: 1000, deviceScaleFactor: 2 });

const errors = [];
page.on('pageerror', (e) => errors.push(String(e).slice(0, 200)));

const clickText = async (sel, text, required = true) => {
  const ok = await page.evaluate((s, t) => {
    const el = [...document.querySelectorAll(s)]
      .find((e) => (e.textContent || '').trim().toLowerCase().includes(t.toLowerCase()));
    if (!el) return false;
    el.click();
    return true;
  }, sel, text);
  if (!ok && required) throw new Error(`not found: ${sel} "${text}"`);
  await wait(220);
  return ok;
};

await page.goto(FILE, { waitUntil: 'networkidle0' });
await page.evaluate(() => localStorage.clear());
await page.reload({ waitUntil: 'networkidle0' });
await wait(500);

for (const step of steps) {
  if (step === 'intro' || step === 'full' || step.startsWith('w:')) continue;
  if (step === 'explore') {
    await clickText('button', 'Explore the screener');
    await page.evaluate(() => [...document.querySelectorAll('.coach-card button')]
      .find((b) => /skip/i.test(b.textContent))?.click());
    await wait(260);
  } else if (step.startsWith('add:')) {
    const label = step.slice(4);
    await page.evaluate(() => {
      const el = [...document.querySelectorAll('button')]
        .find((b) => /add (more )?filters|tap to add/i.test(b.textContent || ''));
      el?.click();
    });
    await wait(320);
    await clickText('.picker-row', label);
    await page.evaluate(() => [...document.querySelectorAll('.picker-foot button, .picker__foot button')]
      .find((b) => /done|apply/i.test(b.textContent))?.click());
    await wait(260);
  } else if (step === 'picker') {
    await page.evaluate(() => {
      const el = [...document.querySelectorAll('button')]
        .find((b) => /add (more )?filters|tap to add/i.test(b.textContent || ''));
      el?.click();
    });
    await wait(400);
  } else if (step === 'tpl') {
    await clickText('button', 'template');
    await wait(400);
  } else if (step === 'run') {
    const ran = await page.evaluate(() => {
      const btn = [...document.querySelectorAll('button')].find((b) => /run screener/i.test(b.textContent || ''));
      if (btn && !btn.disabled) { btn.click(); return true; }
      return false;
    });
    if (!ran) {
      const knob = await page.$('.slide-run__knob');
      if (knob) {
        const k = await knob.boundingBox();
        const track = await (await page.$('.slide-run')).boundingBox();
        await page.mouse.move(k.x + k.width / 2, k.y + k.height / 2);
        await page.mouse.down();
        await page.mouse.move(track.x + track.width - 10, k.y + k.height / 2, { steps: 14 });
        await page.mouse.up();
      }
    }
    await wait(2800);
  } else if (step === 'why') {
    await clickText('button, a', 'Why it matched');
    await wait(600);
  } else if (step === 'learn') {
    await clickText('button', 'How the screener works', false)
      || await clickText('button', 'Learn how it works', false);
    await wait(600);
  }
}

await wait(300);
await page.screenshot({ path: `${OUT}/${name}.png`, fullPage: full });
if (errors.length) console.log('PAGE ERRORS:', errors.slice(0, 3).join(' | '));
console.log('wrote', `${OUT}/${name}.png`);
await browser.close();
