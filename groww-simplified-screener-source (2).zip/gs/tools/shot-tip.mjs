import puppeteer from 'puppeteer';
const FILE = 'file:///mnt/user-data/outputs/groww-simplified-screener.html';
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const clickText = async (page, sel, text) => {
  const ok = await page.evaluate((s, t) => {
    const el = [...document.querySelectorAll(s)].find((e) => e.textContent.includes(t));
    if (!el) return false; el.click(); return true;
  }, sel, text);
  if (!ok) throw new Error(`not found: ${text}`);
  await wait(260);
};
const b = await puppeteer.launch({ args: ['--no-sandbox'] });
for (const [name, dark] of [['light', false], ['dark', true]]) {
  const page = await b.newPage();
  await page.setViewport({ width: 1440, height: 1000, deviceScaleFactor: 2 });
  await page.goto(FILE, { waitUntil: 'networkidle0' });
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle0' });
  await wait(450);
  if (dark) {
    await page.evaluate(() => [...document.querySelectorAll('button')]
      .find((x) => /theme/i.test(x.getAttribute('aria-label') || ''))?.click());
    await wait(220);
  }
  await clickText(page, '.btn', 'Explore the screener');
  await page.evaluate(() => [...document.querySelectorAll('.coach-card .btn')].find((x) => x.textContent.includes('Skip'))?.click());
  await wait(200);
  await clickText(page, '.btn', 'Add filters');
  await clickText(page, '.picker-row', 'Growing steadily');
  await clickText(page, '.picker-foot .btn', 'Done');
  await wait(300);
  await clickText(page, '.link-btn', 'Learn how it works');
  await wait(600);
  const card = await page.$('.tip-card');
  if (!card) throw new Error('tip card not on screen');
  const box = await card.boundingBox();
  await page.screenshot({ path: `/home/claude/tip-${name}.png`,
    clip: { x: box.x - 8, y: box.y - 8, width: box.width + 16, height: box.height + 16 } });
  await page.close();
}
await b.close();
console.log('tip shots written');
