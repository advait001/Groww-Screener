import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const page = await browser.newPage();
await page.setViewport({ width: 1660, height: 1000 });
await page.goto('file:///mnt/user-data/outputs/groww-simplified-screener.html', { waitUntil: 'networkidle0' });
await page.evaluate(() => {
  localStorage.setItem('groww-simple-screener.v1', JSON.stringify({
    profile: {}, onboardingComplete: true, coachDone: true, theme: 'light', sort: 'relevance', saved: [], sessions: 2,
    selections: { horizon: 'horizon-medium', performance: 'performance-avoid-weak' },
    lastRun: { selections: { horizon: 'horizon-medium', performance: 'performance-avoid-weak' }, count: 18, at: '2026-09-18T10:00:00Z' },
  }));
});
await page.reload({ waitUntil: 'networkidle0' });
await new Promise((r) => setTimeout(r, 700));
await page.evaluate(() => {
  const el = [...document.querySelectorAll('.stage-btn, .stage__label')].find((e) => e.textContent.includes('Review'));
  el?.click();
});
await new Promise((r) => setTimeout(r, 700));
await page.screenshot({ path: '/home/claude/logos-results.png', fullPage: true });
await browser.close();
console.log('captured');
