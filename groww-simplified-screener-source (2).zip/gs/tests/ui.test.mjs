/* Interaction smoke test: drives the built single-file prototype in jsdom. */
import { JSDOM, VirtualConsole } from 'jsdom';
import { readFileSync } from 'node:fs';

const html = readFileSync('/mnt/user-data/outputs/groww-simplified-screener.html', 'utf8');
const errors = [];
const vc = new VirtualConsole();
vc.on('jsdomError', (e) => errors.push(`jsdomError: ${e.message}`));
vc.on('error', (...a) => errors.push(`console.error: ${a.join(' ')}`));

const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true, url: 'https://example.test/', virtualConsole: vc });
const { window } = dom;
window.matchMedia = () => ({ matches: false, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {} });
window.Element.prototype.scrollIntoView = function () {};

window.scrollTo = () => {};   // jsdom has no scroll; the planner calls it on step change
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const setValue = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
const doc = window.document;
const text = () => (doc.getElementById('root')?.textContent || '').replace(/\s+/g, ' ');
const all = (sel) => [...doc.querySelectorAll(sel)];
const byText = (sel, t) => all(sel).find((el) => (el.textContent || '').toLowerCase().includes(t.toLowerCase()));
const click = (el, label) => {
  if (!el) throw new Error(`cannot click: ${label} not found`);
  el.click();
};

const runScreen = (label) => {
  const btn = byText('.ex-sentence .btn', 'Run Screener');
  if (!btn || btn.disabled) throw new Error(`cannot run: ${label}`);
  btn.click();
};

let failures = 0;
const check = (name, cond, extra = '') => {
  if (!cond) { failures++; console.log(`  FAIL  ${name} ${extra}`); } else console.log(`  ok    ${name} ${extra}`);
};

await wait(150);

console.log('\n— intro —');
check('renders the intro', text().includes('Find stocks without speaking finance'));
check('header shows the Stocks section', text().includes('Screener'));
check('demo data is disclosed up front', text().toLowerCase().includes('demo data'));

console.log('\n— who are you, as onboarding step one —');
click(byText('.btn', 'Get started'), 'get started');
await wait(150);
check('the first step asks who you are', text().includes("Let's set up your screener"));
check('it is counted into the flow', /Step 1 of 6/.test(text()));
check('both fields are there', !!doc.getElementById('ob-name') && !!doc.getElementById('ob-email'));
check('it uses the same field as the rest of onboarding', all('.onb__contact .amount-field').length === 2);

click(byText('.onb__actions .btn', 'Continue'), 'continue with nothing filled');
await wait(100);
check('an empty step is refused', all('.onb__err').length === 2);
check('it does not move on', text().includes("Let's set up your screener"));

const typeIn = (id, v) => {
  const el = doc.getElementById(id);
  setValue.call(el, v);
  el.dispatchEvent(new window.Event('input', { bubbles: true }));
};
typeIn('ob-name', 'Priya Sharma');
typeIn('ob-email', 'nope');
await wait(60);
click(byText('.onb__actions .btn', 'Continue'), 'continue with a bad email');
await wait(100);
check('a malformed email is refused', text().includes("Let's set up your screener"));

typeIn('ob-email', 'priya@example.com');
await wait(60);
click(byText('.onb__actions .btn', 'Continue'), 'continue');
await wait(150);
check('the investing question comes next', text().includes('What are you investing for?'));
check('the counter advances', /Step 2 of 6/.test(text()));
check('the details are kept', JSON.parse(window.localStorage.getItem('groww-screener.identity')).email === 'priya@example.com');
check('the signup is recorded for the sheet',
  (JSON.parse(window.localStorage.getItem('groww-screener.sheet-queue')) || [])
    .some((r) => r.event === 'visitor_identified' && r.email === 'priya@example.com'));

click(byText('.onb__step .link-btn', 'Skip for now'), 'skip the rest of onboarding');
await wait(150);
check('skipping lands on the screener', !!doc.querySelector('.ex-wrap'));

console.log('\n— explore layout —');
check('the screener opens on Explore', text().includes('Find stocks that fit you'));
check('the question leads the page', text().includes('What kind of stock are you looking for?'));
check('the section tabs are present', all('.gw-tabs button').length === 4 && !!byText('.gw-tabs button', 'Explore'));
check('an empty screen offers one way in', !!byText('.ex-drop', 'Tap to add filters'));
check('and ready-made sets below it', all('.ex-tpl').length === 6 && text().includes('Or start from a ready-made set'));
check('the rail shows the sentence being built', text().includes('Show me companies that are'));
check('with nothing in it yet', text().includes('Add a filter to start the sentence'));
check('run is blocked until there is a screen', !!byText('.btn', 'Run Screener') && byText('.btn', 'Run Screener').disabled);
check('a stock strip sits below', all('.ex-stock').length === 4);
check('no filter list cluttering the page', !doc.querySelector('.picker-row'));

// only where the user picks filters; live prices below are real market figures
const buildArea = ['.ex-filters', '.ex-drop', '.ex-tpl-grid', '.ex-sentence']
  .map((sel) => all(sel).map((el) => el.textContent).join(' ')).join(' ');
check('no thresholds or ratios where filters are picked',
  !/CAGR|\bRSI\b|\bROE\b|debt-to-equity|\bP\/E\b|\d+x/.test(buildArea));
check('every filter name is plain language',
  !/CAGR|RSI|ROE|ROCE|P\/E|EBITDA|beta|volatility/i.test(
    all('.ex-tpl__tag').map((t) => t.textContent).join(' ')));
check('coach marks appear on first visit', !!doc.querySelector('.coach-card'));
click(byText('.coach-card .btn', 'Skip'), 'skip coach marks');
await wait(50);

console.log('\n— ready-made sets —');
check('each set names the filters it carries', all('.ex-tpl')[0].querySelectorAll('.ex-tpl__tag').length >= 2);
click(all('.ex-tpl__add')[0], 'use the first set');
await wait(160);
check('a set fills the screen in one tap', all('.fcard').length === 3);
check('the sentence reads back what was picked', !!doc.querySelector('.ex-sentence__word'));
check('and reports how many match', /\d+ match/.test(doc.querySelector('.ex-sentence')?.textContent || ''));
check('the drop zone now asks for more', !!byText('.ex-drop', 'Tap to add more filters'));

click(byText('.ex-rail-sec button', 'Filters already picked'), 'open every ready-made set');
await wait(160);
check('the drawer lists every set', all('.tpl-card').length >= 10);
click(all('.tpl-card')[0], 'use a set from the drawer');
await wait(160);
check('clicking a card applies it straight away', all('.fcard').length === 3);
check('drawer closes after applying', !doc.querySelector('.drawer'));

console.log('\n— swapping a filter in place —');
click(all('.fcard__cat')[0], 'open the swap list');
await wait(140);
check('the category opens its other filters', all('.fswap__opt').length >= 4);
check('the current one is marked', !!doc.querySelector('.fswap__opt.is-on'));
const beforeSwap = all('.fcard__label')[0].textContent;
click(all('.fswap__opt')[1], 'pick a different filter');
await wait(160);
check('picking another swaps it', all('.fcard__label')[0].textContent !== beforeSwap);
check('and the count stays the same', all('.fcard').length === 3);

click(byText('.link-btn', 'Clear all'), 'clear all');
await wait(120);
check('clearing empties the screen', !all('.fcard').length);

console.log('\n— filter picker —');
click(byText('.ex-drop', 'Tap to add filters'), 'open the filter picker');
await wait(140);
check('picker opens', !!doc.querySelector('.filter-picker') && text().includes('Add filters'));
check('category rail lists every category', all('.picker-rail__item').length === 14);
check('all filters browsable in one place', all('.picker-row').length >= 60, `(${all('.picker-row').length})`);
check('rows carry a one-line description', !!doc.querySelector('.picker-row__desc'));

const growthRow = byText('.picker-row', 'Grows a little every year');
click(growthRow, 'Grows a little every year');
await wait(80);
check('row shows a selected state', byText('.picker-row', 'Grows a little every year').className.includes('is-selected'));
check('chip added to the statement', !!byText('.fcard__label', 'Grows every year'));
check('sidebar lists the chosen filter', !!byText('.fcard', 'Grows every year'));

click(byText('.picker-row', 'Growing really fast'), 'Growing really fast');
await wait(80);
check('one filter per category replaces the previous', all('.fcard').length === 1 && !!byText('.fcard__label', 'Growing fast'));
click(byText('.picker-row', 'Grows a little every year'), 'back to the steady grower');
await wait(80);

click(byText('.picker-rail__item', 'Staying calm'), 'the steadiness group in the rail');
await wait(100);
check('rail narrows the list to one group', all('.picker-row').length >= 4 && all('.picker-row').length < 20, `(${all('.picker-row').length})`);
click(byText('.picker-row', 'Calm and steady'), 'Calm and steady');
await wait(80);
check('second filter added', all('.fcard').length === 2);
check('the picker shows what is already chosen', all('.pchip').length === 2);

const search = doc.querySelector('.picker-search input');
setValue.call(search, 'priced');
search.dispatchEvent(new window.Event('input', { bubbles: true }));
await wait(120);
check('search finds filters across groups', all('.picker-row').length > 0 && all('.picker-row').length < 34);
check('search results say how many matched', /filters? matching/.test(text()));
click(byText('.picker-row', 'Priced about right'), 'a filter found by search');
await wait(80);
check('a searched filter can be added', !!byText('.fcard__label', 'Fairly priced'));

// dragging a row onto the chosen filters must reach the same state
const dropzone = doc.querySelector('[data-drop="statement"]');
const dropEvent = new window.Event('drop', { bubbles: true });
Object.defineProperty(dropEvent, 'dataTransfer', { value: { getData: () => 'momentum-improving' } });
dropzone.dispatchEvent(dropEvent);
await wait(100);
check('dropping a filter selects it', !!byText('.fcard__label', 'Speeding up'));

click(byText('.picker-foot .btn', 'Apply'), 'close the picker');
await wait(100);
check('picker closes', !doc.querySelector('.filter-picker'));
check('the screen kept everything picked', all('.fcard').length === 4);

click(all('.fcard__label')[0], 'open a filter explainer');
await wait(100);
check('filter popup opens', text().includes('What Groww checks'));
check('popup lists one row per check', all('.check-item').length >= 1);
check('popup leads with one plain sentence', !!doc.querySelector('.opt-modal__lead'));
check('popup offers to remove the filter', !!byText('.modal__foot .btn', 'Remove from my screen'));
click(byText('.modal__foot .btn', 'Okay'), 'close the popup');
await wait(80);

click(all('.fcard__x')[3], 'remove the fourth filter');
await wait(100);
check('removing a filter drops its card', all('.fcard').length === 3);

const railText = doc.querySelector('.ex-sentence')?.textContent || '';
check('the rail reads the screen back as a sentence', railText.includes('Show me companies that are'));
check('every chosen filter appears in it', all('.ex-sentence__word').length === 3);
check('live match count shown', /\d+ match/.test(railText));
check('run unlocks once there are two filters',
  !!byText('.btn', 'Run Screener') && !byText('.btn', 'Run Screener').disabled);

console.log('\n— run —');
click(byText('.btn', 'Run Screener'), 'run the screen');
await wait(220);
check('processing state shows', text().includes('Running your screen'));
await wait(1400);
check('results render', text().includes('Stocks matching your filters') || text().includes('No stocks match'));
const rowCount = all('.gw-table tbody tr').length;
check('result rows rendered', rowCount > 0, `(${rowCount} rows)`);
check('match badges shown', all('.match').length > 0);
check('the results bar carries the filters and the actions',
  all('.res-bar__chips .pchip').length >= 2
  && !!byText('.res-bar__btn', 'Save screener')
  && !!byText('.res-bar__edit', 'Edit filters'));

click(doc.querySelector('.menu__trigger'), 'open the sort menu');
await wait(100);
check('sort opens a themed menu, not an OS dropdown', all('.menu__item').length === 5);
check('the current sort is marked', !!doc.querySelector('.menu__item.is-selected'));
const orderBefore = all('.gw-table tbody tr .stock-name').map((n) => n.textContent).join('|');
click(byText('.menu__item', 'Best last year'), 'sort by 1 year return');
await wait(140);
check('menu closes after choosing', !doc.querySelector('.menu__list'));
check('the trigger shows the new sort', (doc.querySelector('.menu__value')?.textContent || '').includes('Best last year'));
check('the table actually re-sorts', all('.gw-table tbody tr .stock-name').map((n) => n.textContent).join('|') !== orderBefore);

click(byText('.res-bar__btn', 'Save screener'), 'save this screen');
await wait(100);
check('saving confirms with a toast', text().includes('Screen saved'));

click(byText('.res-bar__btn', 'What we checked'), 'what we checked');
await wait(80);
check('quick translation drawer still available', all('.drawer__head h2, .drawer__head h3').length > 0);
check('each filter lists the checks behind it', all('.xlate__card').length >= 2 && all('.xlate__check').length >= 3);
click(all('.xlate__check')[0], 'open a check');
await wait(60);
check('lesson modal opens', text().includes('Careful') && text().includes('Read it'));
click(byText('.modal__foot .btn', 'Got it'), 'close lesson');
await wait(40);
click(byText('.drawer__foot .btn', 'Back to results'), 'close drawer');
await wait(40);


console.log('\n— why this stock matched —');
click(byText('.why-btn', 'Why it matched'), 'Why it matched');
await wait(120);
check('stock explanation screen opens', text().includes('Why this stock matched') || text().includes('How this stock measured up'));
check('company summary rendered', !!doc.querySelector('.wm-stock') && /\d\/\d of your filters matched/.test(text()));
const matchRows = all('.wm-row');
check('one row per filter', matchRows.length === 3, `(${matchRows.length} rows)`);
check('each row names the filter it answers', all('.wm-row__name').length === matchRows.length);
check('rows are grouped under a verdict, not colour alone', /Matched|Did not match|Partly matched/.test(text()));
check('explanations carry the real evaluated value', /clears|falls short|not available/.test(text()) && /\d/.test(text()));
check('each row offers the indicator behind it', all('.wm-row__ind .link-btn').length === matchRows.length);

console.log('\n— indicator learning —');
click(all('.wm-row__ind .link-btn')[0], 'learn more about an indicator');
await wait(120);
check('indicator screen opens', text().includes('What this number means'));
check('it names the preference it serves', text().includes('Used for:'));
check('three learning sections in order',
  text().indexOf('What it means') < text().indexOf('Why we used it')
  && text().indexOf('Why we used it') < text().indexOf('How it works'));
check('educational visual rendered', all('.means-visual svg').length === 1);
check('three how-it-works steps', all('.step-card').length === 3);
check('good to know caveat present', text().includes('Good to know'));
check('progress is dynamic', /1 of \d/.test(text()) && !!doc.querySelector('.il-prog .progress-bar'));
check('progress is shown as a share too', /\d+%/.test(doc.querySelector('.il-prog')?.textContent || ''));
check('back link remembers the origin', !!byText('.il-bar__back', 'Back to'));

const titleOf = () => doc.querySelector('.ind-summary h2').textContent.trim();
const firstTitle = titleOf();
click(byText('.learn-nav .btn', 'Next number'), 'next indicator');
await wait(100);
check('next indicator moves on', titleOf() !== firstTitle, `(${firstTitle} -> ${titleOf()})`);
click(byText('.learn-nav .btn', 'Back'), 'back indicator');
await wait(100);
check('back returns to the previous indicator', titleOf() === firstTitle);
click(byText('.related-card b', 'Keep learning')?.closest('.related-card'), 'keep learning');
await wait(120);
check('keep learning opens the overview', text().includes('What your filters really check'));

console.log('\n— how Groww built your screen —');
check('statement chips match the active filters', all('.learn-chip').length === matchRows.length);
check('one mapped row per filter', all('.map-row').length === matchRows.length);
check('each row maps a preference to its indicator', all('.map-row__arrow').length === matchRows.length);
check('cards explain why the indicator was used', text().includes('Why this matters'));
check('learning sidebar present', /What you.ll learn/.test(text()) && text().includes('Beginner tip'));
check('multi-indicator preferences list the rest', all('.pill-link').length > 0);
click(all('.pill-link')[0], 'a secondary indicator');
await wait(120);
check('secondary indicators open too', text().includes('What this number means'));
click(byText('.il-bar__back', 'Back to the numbers'), 'back to overview');
await wait(100);
click(byText('.map-row__cta', 'Learn how it works'), 'learn how it works');
await wait(120);
check('overview opens the indicator screen', text().includes('What this number means'));
click(byText('.il-bar__back', 'Back to the numbers'), 'back to indicators');
await wait(100);
check('back returns to the overview', text().includes('What your filters really check'));
click(byText('.learn-bottom .btn', 'Back to results'), 'back to results');
await wait(120);
check('overview returns to results', text().includes('Stocks matching your filters'));

console.log('\n— stock detail —');
click(all('.stock-name button')[0], 'open a stock');
await wait(140);
check('detail opens', text().includes('The numbers behind it'));
check('chart rendered', all('svg[role="img"]').length > 0);
check('range chips work', !!byText('.chip', '6M'));
click(byText('.chip', '6M'), '6M range');
await wait(40);
check('range change reflected', text().includes('6M change'));
click(byText('.sd-watch', 'Add to watchlist'), 'watchlist');
await wait(40);
check('watchlist toast shown', text().includes('demo watchlist'));
click(byText('.btn', 'Why it'), 'why it matched from detail');
await wait(120);
check('detail links into the explanation screen', text().includes('Why this stock matched') || text().includes('How this stock measured up'));
click(byText('.wm-foot .btn', 'Back to results'), 'back to results');
await wait(120);
// the list pages at 50, so compare the reported total rather than rows on screen
const countText = () => (text().match(/(\d[\d,]*) stocks?\b/) || [])[1];

console.log('\n— zero result state —');
// build a deliberately conflicting screen
click(byText('.link-btn', 'Edit filters') || byText('.btn', 'Edit filters myself') || byText('.btn', 'Back to the screener'), 'edit filters');
await wait(80);
check('editing goes back to the screener with the filters intact', all('.fcard').length >= 2);

click(doc.querySelector('.account .gw-avatar'), 'open the account menu');
await wait(100);
check('the avatar opens an account menu', !!doc.querySelector('.account__menu'));
check('the investing profile lives there', !!byText('.account__menu .menu__item', 'Investing profile'));
click(byText('.account__menu .menu__item', 'Investing profile'), 'open the profile');
await wait(120);
check('it opens the profile screen', text().includes('Your investing profile') || text().includes('What are you investing for?'));
click(byText('.btn', 'Open screener') || byText('.link-btn', 'Skip for now'), 'back to the screener');
await wait(120);

click(byText('.ex-rail-sec button', 'saved screen'), 'open saved screens');
await wait(120);
check('saved screens listed as cards', all('.saved-card').length === 1);
check('each card names the screen and its filters', /match now/.test(text()) && all('.saved-card .stmt-chip').length >= 2);
check('each card can be loaded or run', !!byText('.saved-card .btn', 'Load') && !!byText('.saved-card .btn', 'Run'));
click(byText('.drawer__foot .btn', 'Close'), 'close saved screens');
await wait(80);
click(byText('.ex-link-card', 'How the screener works'), "the beginner's guide");
await wait(100);
check('guide opens the written walkthrough', text().includes('How the screener works'));
click(byText('.modal__foot .btn', 'Okay'), 'close the guide');
await wait(80);
click(byText('.ex-drop', 'Tap to add'), 'open the picker');
await wait(120);
click(byText('.picker-row', 'Growing really fast'), 'Growing really fast');
await wait(60);
click(byText('.picker-row', 'Cheaper than companies like it'), 'Cheaper than companies like it');
await wait(60);
// across a thousand companies it takes more than two conditions to empty the list
click(byText('.picker-row', 'Pays a bit more each year'), 'Pays a bit more each year');
await wait(60);
click(byText('.picker-row', 'Has dropped a lot lately'), 'Has dropped a lot lately');
await wait(60);
click(byText('.picker-foot .btn', 'Apply'), 'close the picker');
await wait(80);
check('conflict explained before running', text().includes('rarely priced below their peers') || text().includes('Expect few matches'));
runScreen('run conflicting screen');
await wait(1500);
check('zero state shown', text().includes('Nothing clears every condition'));
check('relaxation suggestions give real counts', /would match/.test(text()));
check('close matches offered', text().includes('close matches') || text().includes('Close matches'));

console.log('\n— partial match —');
click(byText('.btn', 'Show') || byText('.why-btn', 'Why it nearly matched'), 'show close matches');
await wait(80);
check('close matches name the condition they fell short on', !doc.querySelector('.close-card') || !!doc.querySelector('.gap-block__name'));
check('close matches show how many conditions were met', !doc.querySelector('.close-card') || !!doc.querySelector('.close-card__score i.is-met'));
const nearly = byText('.close-card .btn', 'Why it nearly matched');
if (nearly) {
  click(nearly, 'why it nearly matched');
  await wait(140);
  check('close match gets an honest heading', text().includes('How this stock measured up'));
  check('failed conditions are marked, not hidden', text().includes('Did not match') || text().includes('Partly matched'));
  check('the miss is explained with the real shortfall', /falls short|not available/.test(text()));
  check('match summary is not overstated',
    /\d\/\d of your filters matched/.test(text()) && !!doc.querySelector('.wm-badge.is-partial'));
  click(byText('.wm-foot .btn', 'Back to results'), 'back to results');
  await wait(100);
}

console.log('\n— persistence —');
const stored = window.localStorage.getItem('groww-simple-screener.v1');
check('state persisted to localStorage', !!stored && stored.includes('selections'));

console.log('\n— language audit —');
const banned = ['best pick', 'best stock', 'top pick', 'our recommendation', 'we recommend', 'will rise', 'will grow', 'guaranteed', 'safe bet', 'risk-free', 'sure shot', 'multibagger', 'lorem ipsum', 'undervalued stock', 'fair value is', 'should buy'];
// negated uses ("not guaranteed", "no guarantee") are honest caveats, so drop them before auditing
const body = text().toLowerCase()
  .replace(/(not|never|no|nothing is) guarantee[a-z]*/g, '')
  .replace(/does not predict|do not predict|not a forecast|never recommends|does not recommend|not recommend/g, '');
for (const phrase of banned) check(`no "${phrase}"`, !body.includes(phrase));

console.log('\n— the account menu —');
click(doc.querySelector('.account .gw-avatar'), 'open the account menu');
await wait(100);
check('start over is no longer offered', !byText('.menu__item', 'Start over'));
check('the profile is still reachable', !!byText('.menu__item', 'Investing profile'));

console.log('\n— the amount step —');
click(byText('.menu__item', 'Investing profile'), 'open the profile questions');
await wait(180);
for (let i = 0; i < 5 && !doc.querySelector('.amount-presets'); i++) {
  click(all('.choice')[0], 'pick the first answer');
  await wait(80);
  click(all('.onb__actions .btn').find((b) => /Continue|See my profile/.test(b.textContent)), 'continue');
  await wait(140);
}
check('the amount step offers presets and a box', all('.amount-presets button').length === 4 && !!doc.querySelector('.amount-field input'));
const amountBox = () => doc.querySelector('.amount-field input');
click(all('.amount-presets button')[1], 'tap a preset amount');
await wait(120);
check('tapping a preset fills the amount box', amountBox().value === '25,000');
check('and marks that preset as chosen', all('.amount-presets .is-selected').length === 1);
setValue.call(amountBox(), '30000');
amountBox().dispatchEvent(new window.Event('input', { bubbles: true }));
await wait(120);
check('the amount stays editable afterwards', amountBox().value === '30000');
check('editing releases the preset', all('.amount-presets .is-selected').length === 0);
click(all('.amount-presets button')[3], 'tap a different preset');
await wait(120);
check('a second preset replaces the typed amount', amountBox().value === '1,00,000');


/* ====================================================== invest for a goal */

console.log('\n— invest for a goal —');
const setField = (id, v) => {
  const el = doc.getElementById(id);
  setValue.call(el, v);
  el.dispatchEvent(new window.Event('input', { bubbles: true }));
};

// the amount step left us inside onboarding; skip out to the screener
click(byText('.onb__step .link-btn', 'Skip for now'), 'skip out of onboarding');
await wait(250);
const skip = byText('.coach-card button', 'Skip');
if (skip) { click(skip, 'skip the tour'); await wait(150); }

click(doc.querySelector('.ex-goal'), 'open the goal planner');
await wait(200);
check('the planner opens', text().includes('What are you saving for?'));
check('it starts with nothing answered', text().includes('0 of 4'));
check('the panel waits for answers', text().includes('Not enough yet'));
check('all six goal types are offered', all('.gp-type').length === 6);

click(byText('.gp-type', 'A home'), 'pick a home goal');
await wait(150);
check('picking a type fills in a usual amount', doc.getElementById('gp-goal').value === '25,00,000');
check('it says the numbers were filled in', text().includes('usual'));

setField('gp-goal', '5000000');
setField('gp-years', '5');
setField('gp-monthly', '5000');
await wait(150);
check('three of four answered', text().includes('3 of 4'));
click(byText('.gp-risk', 'Steady'), 'pick the steady mix');
await wait(200);
check('four of four answered', text().includes('4 of 4'));

check('an impossible goal is called out', text().includes('Not quite enough'));
check('the shortfall is stated in money', /short of/.test(text()));
check('it offers ways to close the gap', all('.gp-fixes button').length >= 2);
const fixText = all('.gp-fixes button').map((b) => b.textContent).join(' ');
check('the fixes name real numbers', /Put in ₹|Keep going for|Aim for ₹/.test(fixText), `(${fixText.slice(0, 60)})`);
check('no plan is offered while it does not add up', !byText('.gp-check .btn', 'Show me the funds'));

click(all('.gp-fixes button')[0], 'take the first fix');
await wait(250);
check('taking a fix makes it add up', text().includes('This adds up'));
check('the changed answer is remembered', doc.getElementById('gp-monthly').value !== '5,000');

click(byText('.gp-check .btn', 'Show me the funds'), 'build the plan');
await wait(300);
check('the plan screen opens', text().includes('How these funds were picked'));
check('the plan is titled with the goal', /Your home plan/.test(text()));
check('it says what was changed', text().includes('Changed to make it add up'));
check('the rules used are shown', all('.gp-rule').length >= 4);
check('every rule is named', /Big enough/.test(text()) && /Yearly fee/.test(text()));

const fundRows = all('.gp-row');
check('one row per fund in the mix', fundRows.length >= 3, `(${fundRows.length})`);
check('each row names a prototype fund',
  fundRows.every((r) => /Prototype Fund/.test(r.textContent)));
const pcts = all('.gp-row__pct').map((e) => Number(e.textContent.replace('%', '')));
check('the shares add up to 100', pcts.reduce((a, b) => a + b, 0) === 100, `(${pcts.join('+')})`);
const amounts = all('.gp-row__amt b').map((e) => Number(e.textContent.replace(/[^0-9]/g, '')));
const monthlyCell = all('.gp-sum dd')[1].cloneNode(true);
monthlyCell.querySelectorAll('.gp-was').forEach((n) => n.remove());
const monthlyNow = Number(monthlyCell.textContent.replace(/[^0-9]/g, ''));
check('the money splits exactly, no rupee lost',
  amounts.reduce((a, b) => a + b, 0) === monthlyNow, `(${amounts.join('+')} vs ${monthlyNow})`);
check('the allocation bar has a band per fund', all('.gp-alloc span').length === fundRows.length);
check('it says it is prototype data', /invented for the prototype/.test(text()));
check('it does not claim to recommend', /does not tell you what to buy/.test(text()));

const housesBefore = all('.gp-row .tiny.muted').map((e) => e.textContent).join('|');
click(byText('.gp-block__head .btn', 'Show another set'), 'shuffle the mix');
await wait(200);
check('another set gives different funds',
  all('.gp-row .tiny.muted').map((e) => e.textContent).join('|') !== housesBefore);

click(byText('.gp-check .btn', 'Start '), 'open the invest drawer');
await wait(200);
check('the confirm drawer lists every fund', all('.gp-confirm li').length === fundRows.length);
check('it is honest that nothing is bought', /no money moves/.test(text()));
click(byText('.drawer__foot .btn', 'Confirm'), 'confirm the monthly plans');
await wait(200);
check('confirming reports the first payment date', /First payment on/.test(text()));

click(byText('.gp-back', 'Change my goal'), 'back to the questions');
await wait(200);
check('the answers are still there', doc.getElementById('gp-goal').value === '50,00,000');

console.log('\n— no runtime errors —');
check('no console errors', errors.length === 0, errors.slice(0, 3).join(' | '));

console.log(failures ? `\n${failures} FAILURES\n` : '\nAll UI checks passed.\n');
if (failures) process.exitCode = 1;
