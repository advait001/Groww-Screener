import puppeteer from 'puppeteer';
const url = 'file:///mnt/user-data/outputs/groww-simplified-screener.html';
const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const page = await browser.newPage();
await page.setViewport({ width: 1660, height: 1000, deviceScaleFactor: 1 });
await page.goto(url, { waitUntil: 'networkidle0' });
// land on the screener with the reference's four selections, coach marks dismissed
await page.evaluate(() => {
  localStorage.setItem('groww-simple-screener.v1', JSON.stringify({
    profile: {}, onboardingComplete: true, coachDone: true, theme: 'light', sort: 'relevance', saved: [], sessions: 2,
    selections: { growth: 'growth-steady', stability: 'stability-stable', valuation: 'valuation-reasonable', momentum: 'momentum-improving' },
  }));
});
await page.reload({ waitUntil: 'networkidle0' });
await new Promise((r) => setTimeout(r, 900));
await page.screenshot({ path: '/home/claude/shot-desktop.png' });
await page.screenshot({ path: '/home/claude/shot-full.png', fullPage: true });
await page.setViewport({ width: 420, height: 900, deviceScaleFactor: 1 });
await new Promise((r) => setTimeout(r, 400));
await page.screenshot({ path: '/home/claude/shot-mobile.png' });
await page.evaluate(() => document.querySelector('.cat-tabs')?.scrollIntoView({ block: 'start' }));
await new Promise((r) => setTimeout(r, 300));
await page.screenshot({ path: '/home/claude/shot-mobile-filters.png' });
await browser.close();
console.log('captured');
