import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const shot = async (theme, file) => {
  const page = await browser.newPage();
  await page.setViewport({ width: 1500, height: 950 });
  await page.goto('file:///mnt/user-data/outputs/groww-simplified-screener.html', { waitUntil: 'networkidle0' });
  await page.evaluate((t) => {
    const selections = { growth: 'growth-steady', stability: 'stability-stable' };
    localStorage.setItem('groww-simple-screener.v1', JSON.stringify({
      profile: {}, onboardingComplete: true, coachDone: true, tipsDone: true, theme: t, sort: 'relevance', saved: [], sessions: 4,
      selections, lastRun: { selections, count: 11, at: '2026-09-19T09:00:00Z' },
    }));
  }, theme);
  await page.reload({ waitUntil: 'networkidle0' });
  await new Promise((r) => setTimeout(r, 500));
  await page.evaluate(() => [...document.querySelectorAll('.run-row .btn')].find((b) => b.textContent.includes('Run screener'))?.click());
  await new Promise((r) => setTimeout(r, 1900));
  await page.evaluate(() => document.querySelector('.menu__trigger')?.click());
  await new Promise((r) => setTimeout(r, 300));
  const box = await page.evaluate(() => {
    const t = document.querySelector('.menu').getBoundingClientRect();
    return { x: Math.max(0, t.left - 120), y: Math.max(0, t.top - 20), width: 420, height: 300 };
  });
  await page.screenshot({ path: file, clip: box });
  await page.close();
};
await shot('light', '/home/claude/sort-light.png');
await shot('dark', '/home/claude/sort-dark.png');
await browser.close();
console.log('captured');
