import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });

const overlapCheck = async (page) => page.evaluate(() => {
  const card = document.querySelector('.coach-card');
  const spot = document.querySelector('.coach-spot');
  if (!card || !spot) return { overlap: -1 };
  const c = card.getBoundingClientRect();
  const s = spot.getBoundingClientRect();
  const x = Math.max(0, Math.min(c.right, s.right) - Math.max(c.left, s.left));
  const y = Math.max(0, Math.min(c.bottom, s.bottom) - Math.max(c.top, s.top));
  const inView = c.top >= 0 && c.left >= 0 && c.bottom <= innerHeight && c.right <= innerWidth;
  return { overlap: Math.round(x * y), inView, step: document.querySelector('.coach-card .label-caps')?.textContent };
});

for (const [w, h, name] of [[1660, 1000, 'desktop'], [1180, 820, 'laptop'], [420, 820, 'mobile']]) {
  const page = await browser.newPage();
  await page.setViewport({ width: w, height: h });
  await page.goto('file:///mnt/user-data/outputs/groww-simplified-screener.html', { waitUntil: 'networkidle0' });
  await page.evaluate(() => localStorage.setItem('groww-simple-screener.v1', JSON.stringify({
    profile: {}, onboardingComplete: true, coachDone: false, theme: 'light', sort: 'relevance', saved: [], sessions: 1,
    selections: { growth: 'growth-steady', stability: 'stability-low-debt', valuation: 'valuation-reasonable', performance: 'performance-recent' },
  })));
  await page.reload({ waitUntil: 'networkidle0' });
  await new Promise((r) => setTimeout(r, 900));
  for (let step = 1; step <= 3; step++) {
    const res = await overlapCheck(page);
    console.log(`${name} step ${step}:`, JSON.stringify(res));
    if (step === 1) await page.screenshot({ path: `/home/claude/coach-${name}.png` });
    await page.evaluate(() => [...document.querySelectorAll('.coach-card .btn')].find((b) => /Next|Got it/.test(b.textContent))?.click());
    await new Promise((r) => setTimeout(r, 700));
  }
  await page.close();
}
await browser.close();
