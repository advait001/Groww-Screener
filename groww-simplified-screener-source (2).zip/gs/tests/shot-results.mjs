import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const shot = async (theme, w, file) => {
  const page = await browser.newPage();
  await page.setViewport({ width: w, height: 1000 });
  await page.goto('file:///mnt/user-data/outputs/groww-simplified-screener.html', { waitUntil: 'networkidle0' });
  await page.evaluate((t) => {
    const selections = { growth: 'growth-steady', stability: 'stability-stable', momentum: 'momentum-improving' };
    localStorage.setItem('groww-simple-screener.v1', JSON.stringify({
      profile: {}, onboardingComplete: true, coachDone: true, tipsDone: true, theme: t, sort: 'relevance', saved: [], sessions: 4,
      selections, lastRun: { selections, count: 8, at: '2026-09-19T09:00:00Z' },
    }));
  }, theme);
  await page.reload({ waitUntil: 'networkidle0' });
  await new Promise((r) => setTimeout(r, 500));
  await page.evaluate(() => [...document.querySelectorAll('.run-row .btn')].find((b) => b.textContent.includes('Run screener'))?.click());
  await new Promise((r) => setTimeout(r, 1900));
  await page.screenshot({ path: file });
  await page.close();
};
await shot('light', 1500, '/home/claude/results-light.png');
await shot('dark', 1500, '/home/claude/results-dark.png');
await shot('light', 420, '/home/claude/results-mobile.png');
await browser.close();
console.log('captured');
