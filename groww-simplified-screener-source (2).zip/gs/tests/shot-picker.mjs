import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const page = await browser.newPage();
await page.setViewport({ width: 1660, height: 1000 });
await page.goto('file:///mnt/user-data/outputs/groww-simplified-screener.html', { waitUntil: 'networkidle0' });
await page.evaluate(() => localStorage.setItem('groww-simple-screener.v1', JSON.stringify({
  profile: {}, onboardingComplete: true, coachDone: true, theme: 'light', sort: 'relevance', saved: [], sessions: 2,
  selections: { growth: 'growth-steady', stability: 'stability-stable' },
})));
await page.reload({ waitUntil: 'networkidle0' });
await new Promise((r) => setTimeout(r, 600));
await page.evaluate(() => [...document.querySelectorAll('.btn')].find((b) => b.textContent.includes('Add filters'))?.click());
await new Promise((r) => setTimeout(r, 400));
await page.screenshot({ path: '/home/claude/picker-all.png' });
await page.evaluate(() => {
  const el = [...document.querySelectorAll('.picker-rail__item')].find((b) => b.textContent.includes('Valuation'));
  el?.click();
});
await new Promise((r) => setTimeout(r, 300));
await page.screenshot({ path: '/home/claude/picker-cat.png' });
await page.type('.picker-search input', 'debt');
await new Promise((r) => setTimeout(r, 400));
await page.screenshot({ path: '/home/claude/picker-search.png' });
await browser.close();
console.log('captured');
