import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const page = await browser.newPage();
await page.setViewport({ width: 1660, height: 1000 });
await page.goto('file:///mnt/user-data/outputs/groww-simplified-screener.html', { waitUntil: 'networkidle0' });
await page.evaluate(() => {
  const selections = { growth: 'growth-steady', stability: 'stability-stable' };
  localStorage.setItem('groww-simple-screener.v1', JSON.stringify({
    profile: {}, onboardingComplete: true, coachDone: true, tipsDone: true, theme: 'dark', sort: 'relevance', saved: [], sessions: 3,
    selections, lastRun: { selections, count: 11, at: '2026-09-19T09:00:00Z' },
  }));
});
await page.reload({ waitUntil: 'networkidle0' });
await new Promise((r) => setTimeout(r, 600));
await page.evaluate(() => [...document.querySelectorAll('.run-row .btn')].find((b) => b.textContent.includes('Run screener'))?.click());
await new Promise((r) => setTimeout(r, 1900));
await page.evaluate(() => document.querySelector('.why-btn')?.click());
await new Promise((r) => setTimeout(r, 700));
await page.screenshot({ path: '/home/claude/links-dark.png' });
await browser.close();
console.log('captured');
