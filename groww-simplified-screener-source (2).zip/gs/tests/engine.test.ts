/* Engine checks: run with `node dist/test.cjs` after bundling. */
import { STOCKS, buildUniverseContext, isLender } from '../src/data/stocks';
import { CATEGORY_ORDER, OPTIONS, optionsForCategory } from '../src/data/config';
import { countMatches, evaluateStock, narrowings, relaxations, runScreener, type Selections } from '../src/engine/screener';
import { sentenceText } from '../src/engine/sentence';
import * as gp from '../src/engine/goalPlan';
import { FUNDS } from '../src/data/funds';

let failures = 0;
const check = (name: string, cond: boolean, extra = '') => {
  if (!cond) { failures++; console.log(`  FAIL  ${name} ${extra}`); } else console.log(`  ok    ${name} ${extra}`);
};

const ctx = buildUniverseContext(STOCKS);
console.log('\n— dataset —');
check('universe is the full demo list', STOCKS.length >= 60, `(${STOCKS.length})`);
const sectors = new Set(STOCKS.map((s) => s.sector));
check('every sector has enough peers to rank against', [...sectors].every((sec) => STOCKS.filter((s) => s.sector === sec).length >= 10));
check('sector medians computed', [...sectors].every((s) => typeof ctx.median('pe', s) === 'number'));
check('lenders report no return on capital, so rules using it must skip', STOCKS.some((s) => isLender(s) && s.roce === null));
check('has a newly listed company (<3y)', STOCKS.some((s) => s.listedYears < 3));
check('has lenders with capital adequacy', STOCKS.some((s) => isLender(s) && s.capitalAdequacy !== null));

console.log('\n— combinations —');
const combos: [string, Selections][] = [
  ['steady + stable', { growth: 'growth-steady', stability: 'stability-stable' }],
  ['steady + stable + reasonable + long', { growth: 'growth-steady', stability: 'stability-stable', valuation: 'valuation-reasonable', horizon: 'horizon-long' }],
  ['fast + peer discount (conflict)', { growth: 'growth-fast', valuation: 'valuation-discount' }],
  ['discount + oversold', { valuation: 'valuation-discount', momentum: 'momentum-oversold' }],
  ['low beta + steady returns', { stability: 'stability-low-beta', performance: 'performance-steady' }],
  ['consistent growth + strong trend', { growth: 'growth-consistent', momentum: 'momentum-strong' }],
  ['recovery + positive year', { growth: 'growth-recovery', performance: 'performance-positive' }],
  ['growth premium + medium', { valuation: 'valuation-growth-premium', horizon: 'horizon-medium' }],
];
for (const [label, sel] of combos) {
  const run = runScreener(sel);
  console.log(`  ${label}: ${run.exact.length} exact, ${run.close.length} close — "${sentenceText(sel)}"`);
}
const counts = combos.map(([, sel]) => countMatches(sel));
check('a deliberately contradictory screen returns almost nothing',
  countMatches({ growth: 'growth-fast', valuation: 'valuation-discount', dividends: 'dividend-yield', size: 'size-large' }) <= 3);
check('one combination returns nothing at all',
  countMatches({ growth: 'growth-fast', valuation: 'valuation-discount', dividends: 'dividend-growing', momentum: 'momentum-oversold' }) === 0);
check('no combination returns everything', counts.every((c) => c < STOCKS.length));
check('combinations narrow the list rather than returning most of it', counts.every((c) => c < STOCKS.length * 0.6));

console.log('\n— every option is reachable —');
for (const option of OPTIONS) {
  if (!option.rules.length) continue;
  const n = countMatches({ [option.categoryId]: option.id } as Selections);
  check(`${option.id}`, n > 0, `-> ${n}`);
}

console.log('\n— missing data never passes —');
const newbie = STOCKS.find((s) => s.listedYears < 3)!;
const longTerm = evaluateStock(newbie, { horizon: 'horizon-long' });
check('newly listed fails the long-term history check', !longTerm.exact);
// this register reports a P/E for every company, so the unreported-figure path
// is exercised by the lenders, whose return on capital is not meaningful
const lender = STOCKS.find((s) => s.roce === null)!;
const capital = evaluateStock(lender, { profitability: 'profit-roce' });
check('a rule with no figure to read is skipped, not passed',
  capital.conditions[0].outcomes.every((o) => o.status !== 'pass'));
check('no-data is reported, not silently failed',
  longTerm.conditions[0].outcomes.some((o) => o.status === 'no-data'));

console.log('\n— lender substitution —');
const bank = STOCKS.find((s) => isLender(s))!;
const lowDebt = evaluateStock(bank, { balance: 'balance-low-debt' });
const substituted = lowDebt.conditions[0].outcomes.find((o) => o.applied.indicator === 'capitalAdequacy');
const manageable = evaluateStock(bank, { balance: 'balance-manageable' });
const skipped = manageable.conditions[0].outcomes.find((o) => o.status === 'not-applicable');
check('debt check swapped for capital adequacy', !!substituted);
check('interest coverage skipped for a lender', !!skipped);

console.log('\n— suggestions are real —');
const zero: Selections = { growth: 'growth-fast', valuation: 'valuation-discount', dividends: 'dividend-growing', momentum: 'momentum-oversold' };
check('zero-result combination really is zero', countMatches(zero) === 0);
const rel = relaxations(zero);
check('relaxations computed for each condition', rel.length === 4);
check('the best relaxation reports its true count',
  rel[0].resultingCount === countMatches(Object.fromEntries(Object.entries(zero).filter(([k]) => k !== rel[0].categoryId)) as Selections));
const broad: Selections = { horizon: 'horizon-medium', performance: 'performance-positive' };
const nar = narrowings(broad);
check('narrowings suggested for a broad screen', nar.length > 0, `(${nar.map((n) => `${n.optionLabel}->${n.resultingCount}`).join(', ')})`);
check('narrowing counts are honest',
  nar.every((n) => n.resultingCount === countMatches({ ...broad, [n.categoryId]: n.optionId })));

console.log('\n— one option per category —');
check('each category has options', CATEGORY_ORDER.every((c) => optionsForCategory(c).length >= 3));



/* ======================================================= the goal planner */

console.log('\n— goal planner: the maths —');
{
  // A SIP of 10k for 10 years at 12% should land near 23.2 lakh. Checked
  // against the closed form rather than a hard-coded number so the test
  // still means something if the rate ever moves.
  const fv = gp.futureValue(10_000, 120, 0.12);
  check('future value is in the right region', fv > 2_200_000 && fv < 2_500_000, `(${Math.round(fv)})`);
  check('future value of nothing is nothing', gp.futureValue(10_000, 0, 0.12) === 0);

  const need = gp.monthlyNeeded(2_000_000, 120, 0.12);
  check('monthlyNeeded inverts futureValue',
    Math.abs(gp.futureValue(need, 120, 0.12) - 2_000_000) < 1);

  const months = gp.monthsNeeded(2_000_000, need, 0.12);
  check('monthsNeeded agrees with monthlyNeeded', Math.abs(months - 120) < 0.5, `(${months.toFixed(2)})`);
  check('no monthly means never', gp.monthsNeeded(100, 0, 0.1) === Infinity);
}

console.log('\n— goal planner: the mix —');
{
  for (const risk of ['low', 'medium', 'high'] as const) {
    for (const years of [2, 5, 12]) {
      const w = gp.mixWeights(risk, years);
      const total = w.reduce((a, [, x]) => a + x, 0);
      check(`${risk}/${years}y allocation sums to 100`, total === 100, `(${total})`);
      check(`${risk}/${years}y is sorted heaviest first`,
        w.every((p, i) => i === 0 || w[i - 1][1] >= p[1]));
    }
  }
  const low = gp.mixRates('low', 12).base;
  const med = gp.mixRates('medium', 12).base;
  const high = gp.mixRates('high', 12).base;
  check('more risk means a higher expected return', low < med && med < high,
    `(${(low * 100).toFixed(1)} < ${(med * 100).toFixed(1)} < ${(high * 100).toFixed(1)})`);
  const band = gp.mixRates('medium', 12);
  check('the band brackets the base rate', band.low < band.base && band.base < band.high);
  check('horizon bands split at 3 and 7 years',
    gp.horizonBand(3) === 'short' && gp.horizonBand(7) === 'medium' && gp.horizonBand(8) === 'long');
}

console.log('\n— goal planner: fund picking —');
{
  const ranked = gp.rankedFunds();
  const all = Object.values(ranked).flat();
  check('some funds survive the quality bar', all.length > 50, `(${all.length} of ${FUNDS.length})`);
  check('every surviving fund clears every rule', all.every((f) =>
    f.aum >= gp.FUND_RULES.minAum && f.exp <= gp.FUND_RULES.maxExp && f.sharpe >= gp.FUND_RULES.minSharpe));
  check('a fund failing a rule is really dropped',
    FUNDS.some((f) => f.exp > gp.FUND_RULES.maxExp) &&
    !all.some((f) => f.exp > gp.FUND_RULES.maxExp));
  check('each category is ranked best first', Object.values(ranked).every((list) =>
    list.every((f, i) => i === 0 || list[i - 1].sharpe >= f.sharpe)));

  for (const risk of ['low', 'medium', 'high'] as const) {
    const picks = gp.pickFunds(risk, 12, 0);
    check(`${risk} plan has one fund per category`, picks.length === gp.mixWeights(risk, 12).length);
    const amcs = picks.map((p) => p.fund.amc);
    check(`${risk} plan never repeats a fund house`, new Set(amcs).size === amcs.length,
      `(${amcs.map(gp.amcShort).join(', ')})`);
    check(`${risk} plan matches the allocation`,
      picks.every((p, i) => p.pct === gp.mixWeights(risk, 12)[i][1]));
    check(`${risk} plan only uses funds that passed`,
      picks.every((p) => all.some((f) => f.id === p.fund.id)));
  }

  const a = gp.pickFunds('high', 12, 0).map((p) => p.fund.id).join();
  const b = gp.pickFunds('high', 12, 1).map((p) => p.fund.id).join();
  check('a different mix index gives a different plan', a !== b);
}

console.log('\n— goal planner: splitting the money —');
{
  const split = gp.largestRemainder([33.333, 33.333, 33.334], 10_000);
  check('the split loses no rupee', split.reduce((x, y) => x + y, 0) === 10_000, `(${split.join('+')})`);
  const weights = gp.mixWeights('medium', 12).map(([, pct]) => (pct / 100) * 7_777);
  const money = gp.largestRemainder(weights, 7_777);
  check('a real allocation splits exactly', money.reduce((x, y) => x + y, 0) === 7_777, `(${money.join('+')})`);
  check('every slice gets something', money.every((m) => m > 0));
}

console.log('\n— goal planner: reachable and not —');
{
  const partial = gp.evaluate({ goal: 1_000_000, years: null, monthly: 5_000, risk: 'medium' });
  check('an unfinished plan is not ready', !partial.ready && !partial.complete);
  check('it reports which answers are in', partial.filled.goal && !partial.filled.years);

  const tooSmall = gp.evaluate({ goal: 500, years: 5, monthly: 5_000, risk: 'low' });
  check('a goal under the floor is an error', !!tooSmall.errors.goal && !tooSmall.ready);
  const tooLittle = gp.evaluate({ goal: 1_000_000, years: 5, monthly: 10, risk: 'low' });
  check('a monthly under the floor is an error', !!tooLittle.errors.monthly);

  const easy = gp.evaluate({ goal: 100_000, years: 10, monthly: 10_000, risk: 'medium' });
  check('an easy goal is reachable', easy.ready === true && easy.feasible === true);
  check('it says when it gets there', (easy.monthsToGoal ?? 0) > 0 && easy.monthsToGoal! <= easy.months!);
  check('projection sits inside its own band', easy.low! <= easy.projected! && easy.projected! <= easy.high!);
  check('invested is just the sum paid in', easy.invested === 10_000 * 120);
  check('an easily reachable goal is also safe at the low rate', easy.safe === true);

  const hard = gp.evaluate({ goal: 50_000_000, years: 5, monthly: 5_000, risk: 'low' });
  check('an unreachable goal is reported, not rounded', hard.ready === true && hard.feasible === false);
  check('the shortfall is the real gap',
    Math.abs(hard.shortfall! - (50_000_000 - hard.projected!)) < 1);
  check('it offers ways out', (hard.suggestions?.length ?? 0) > 0,
    `(${hard.suggestions?.map((s) => s.kind).join(', ')})`);

  const mid = gp.evaluate({ goal: 5_000_000, years: 10, monthly: 10_000, risk: 'low' });
  if (mid.suggestions) {
    for (const s of mid.suggestions) {
      if (s.kind === 'monthly') {
        const after = gp.evaluate({ goal: 5_000_000, years: 10, monthly: s.value as number, risk: 'low' });
        check('the "pay more" suggestion actually reaches the goal', after.feasible === true);
      }
      if (s.kind === 'years') {
        const after = gp.evaluate({ goal: 5_000_000, years: s.value as number, monthly: 10_000, risk: 'low' });
        check('the "wait longer" suggestion actually reaches the goal', after.feasible === true);
      }
      if (s.kind === 'risk') {
        const after = gp.evaluate({ goal: 5_000_000, years: 10, monthly: 10_000, risk: s.value as gp.RiskId });
        check('the "more risk" suggestion actually reaches the goal', after.feasible === true);
      }
      if (s.kind === 'goal') {
        const after = gp.evaluate({ goal: s.value as number, years: 10, monthly: 10_000, risk: 'low' });
        check('the "aim lower" suggestion actually reaches the goal', after.feasible === true);
      }
    }
  }
}

console.log('\n— goal planner: money reads properly —');
{
  check('lakhs', gp.inrShort(2_500_000) === '₹25 L', `(${gp.inrShort(2_500_000)})`);
  check('crores', gp.inrShort(20_000_000) === '₹2 Cr', `(${gp.inrShort(20_000_000)})`);
  check('small amounts stay whole', gp.inrShort(9_000) === '₹9,000', `(${gp.inrShort(9_000)})`);
  check('words for a goal', gp.inWords(2_500_000) === '₹25 lakh', `(${gp.inWords(2_500_000)})`);
  check('duration reads in years and months', gp.durationText(26) === '2 years 2 months', `(${gp.durationText(26)})`);
  check('typing picks out digits', gp.parseDigits('₹25,000') === 25000);
  check('empty input is nothing, not zero', gp.parseDigits('') === null);
}

console.log(failures ? `\n${failures} FAILURES\n` : '\nAll engine checks passed.\n');
if (failures) process.exitCode = 1;
