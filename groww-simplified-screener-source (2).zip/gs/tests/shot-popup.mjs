import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const shot = async (theme, file) => {
  const page = await browser.newPage();
  await page.setViewport({ width: 1400, height: 900 });
  await page.goto('file:///mnt/user-data/outputs/groww-simplified-screener.html', { waitUntil: 'networkidle0' });
  await page.evaluate((t) => localStorage.setItem('groww-simple-screener.v1', JSON.stringify({
    profile: {}, onboardingComplete: true, coachDone: true, tipsDone: true, theme: t, sort: 'relevance', saved: [], sessions: 3,
    selections: { valuation: 'valuation-growth-premium', stability: 'stability-stable' },
  })), theme);
  await page.reload({ waitUntil: 'networkidle0' });
  await new Promise((r) => setTimeout(r, 600));
  await page.evaluate(() => [...document.querySelectorAll('.stmt-chip__label')].find((b) => b.textContent.includes('Paying up for growth'))?.click());
  await new Promise((r) => setTimeout(r, 400));
  const el = await page.$('.modal');
  await el.screenshot({ path: file });
  await page.close();
};
await shot('light', '/home/claude/popup-light.png');
await shot('dark', '/home/claude/popup-dark.png');
await browser.close();
console.log('captured');
