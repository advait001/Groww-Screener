import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const shot = async (theme, file) => {
  const page = await browser.newPage();
  await page.setViewport({ width: 1500, height: 950 });
  await page.goto('file:///mnt/user-data/outputs/groww-simplified-screener.html', { waitUntil: 'networkidle0' });
  await page.evaluate((t) => {
    const a = { growth: 'growth-steady', stability: 'stability-stable', valuation: 'valuation-reasonable', momentum: 'momentum-improving', performance: 'performance-consistent', horizon: 'horizon-long' };
    const b = { valuation: 'valuation-cheap', performance: 'performance-avoid-weak' };
    localStorage.setItem('groww-simple-screener.v1', JSON.stringify({
      profile: {}, onboardingComplete: true, coachDone: true, tipsDone: true, theme: t, sort: 'relevance', sessions: 4,
      selections: {},
      saved: [
        { id: 's1', name: 'old long name', selections: a, createdAt: '2026-09-18T09:00:00Z' },
        { id: 's2', name: 'old', selections: b, createdAt: '2026-09-15T09:00:00Z' },
      ],
    }));
  }, theme);
  await page.reload({ waitUntil: 'networkidle0' });
  await new Promise((r) => setTimeout(r, 600));
  await page.evaluate(() => [...document.querySelectorAll('.side-links .link-btn')].find((b) => b.textContent.includes('My screeners'))?.click());
  await new Promise((r) => setTimeout(r, 400));
  await page.screenshot({ path: file, clip: { x: 1500 - 500, y: 0, width: 500, height: 950 } });
  await page.close();
};
await shot('light', '/home/claude/saved-light.png');
await shot('dark', '/home/claude/saved-dark.png');
await browser.close();
console.log('captured');
