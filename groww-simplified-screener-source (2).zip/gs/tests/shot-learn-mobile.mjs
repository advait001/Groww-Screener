import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const page = await browser.newPage();
await page.setViewport({ width: 420, height: 1000 });
await page.goto('file:///mnt/user-data/outputs/groww-simplified-screener.html', { waitUntil: 'networkidle0' });
await page.evaluate(() => {
  localStorage.setItem('groww-simple-screener.v1', JSON.stringify({
    profile: {}, onboardingComplete: true, coachDone: true, theme: 'light', sort: 'relevance', saved: [], sessions: 2,
    selections: { growth: 'growth-steady', stability: 'stability-stable', valuation: 'valuation-reasonable' },
    lastRun: { selections: { growth: 'growth-steady', stability: 'stability-stable', valuation: 'valuation-reasonable' }, count: 5, at: '2026-09-18T10:00:00Z' },
  }));
});
await page.reload({ waitUntil: 'networkidle0' });
await new Promise((r) => setTimeout(r, 600));
const clickText = async (sel, t) => {
  const ok = await page.evaluate((s, t) => {
    const el = [...document.querySelectorAll(s)].find((e) => (e.textContent || '').toLowerCase().includes(t.toLowerCase()));
    if (el) { el.click(); return true; } return false;
  }, sel, t);
  if (!ok) throw new Error('missing ' + t);
  await new Promise((r) => setTimeout(r, 400));
};
await clickText('.link-btn', 'See what Groww checked');
await page.screenshot({ path: '/home/claude/learn-m1.png' });
await clickText('.ind-card__cta', 'Learn how it works');
await page.screenshot({ path: '/home/claude/learn-m2.png' });
await browser.close();
console.log('mobile learning captured');
