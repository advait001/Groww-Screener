import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const page = await browser.newPage();
await page.setViewport({ width: 1660, height: 1100 });
await page.goto('file:///mnt/user-data/outputs/groww-simplified-screener.html', { waitUntil: 'networkidle0' });
// the hardest case: all six categories in play
await page.evaluate(() => {
  const selections = {
    growth: 'growth-steady', stability: 'stability-stable', valuation: 'valuation-growth-premium',
    momentum: 'momentum-improving', performance: 'performance-consistent', horizon: 'horizon-long',
  };
  localStorage.setItem('groww-simple-screener.v1', JSON.stringify({
    profile: {}, onboardingComplete: true, coachDone: true, theme: 'light', sort: 'relevance', saved: [], sessions: 2,
    selections, lastRun: { selections, count: 3, at: '2026-09-19T09:00:00Z' },
  }));
});
await page.reload({ waitUntil: 'networkidle0' });
await new Promise((r) => setTimeout(r, 600));
await page.evaluate(() => {
  [...document.querySelectorAll('.link-btn')].find((e) => e.textContent.includes('Learn how it works'))?.click();
});
await new Promise((r) => setTimeout(r, 600));
await page.screenshot({ path: '/home/claude/learn-six.png', fullPage: true });
await page.setViewport({ width: 420, height: 1000 });
await new Promise((r) => setTimeout(r, 400));
await page.screenshot({ path: '/home/claude/learn-six-mobile.png' });
await browser.close();
console.log('captured six-filter case');
