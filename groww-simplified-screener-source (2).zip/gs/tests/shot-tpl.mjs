import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const page = await browser.newPage();
await page.setViewport({ width: 1660, height: 1000 });
await page.goto('file:///mnt/user-data/outputs/groww-simplified-screener.html', { waitUntil: 'networkidle0' });
await page.evaluate(() => localStorage.setItem('groww-simple-screener.v1', JSON.stringify({
  profile: {}, onboardingComplete: true, coachDone: true, theme: 'light', sort: 'relevance', saved: [], sessions: 2, selections: {},
})));
await page.reload({ waitUntil: 'networkidle0' });
await new Promise((r) => setTimeout(r, 600));
await page.evaluate(() => [...document.querySelectorAll('.head-btn')].find((b) => b.textContent.includes('Guided templates'))?.click());
await new Promise((r) => setTimeout(r, 500));
await page.screenshot({ path: '/home/claude/tpl-drawer.png' });
// apply one and check the screen updates
await page.evaluate(() => [...document.querySelectorAll('.tpl-detail .btn')].find((b) => b.textContent.includes('Use this template'))?.click());
await new Promise((r) => setTimeout(r, 600));
await page.screenshot({ path: '/home/claude/tpl-applied.png', fullPage: true });
await page.setViewport({ width: 420, height: 1000 });
await new Promise((r) => setTimeout(r, 400));
await page.screenshot({ path: '/home/claude/nav-mobile.png' });
await browser.close();
console.log('captured');
