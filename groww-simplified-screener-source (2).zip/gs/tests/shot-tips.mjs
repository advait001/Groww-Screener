import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const page = await browser.newPage();
await page.setViewport({ width: 1660, height: 1000 });
const url = 'file:///mnt/user-data/outputs/groww-simplified-screener.html';
await page.goto(url, { waitUntil: 'networkidle0' });
// first visit: nothing stored, tips visible
await page.evaluate(() => localStorage.setItem('groww-simple-screener.v1', JSON.stringify({
  profile: {}, onboardingComplete: true, coachDone: true, theme: 'light', sort: 'relevance', saved: [], sessions: 0,
  selections: { growth: 'growth-steady', stability: 'stability-stable' },
})));
await page.reload({ waitUntil: 'networkidle0' });
await new Promise((r) => setTimeout(r, 700));
const first = await page.evaluate(() => (document.getElementById('root')?.textContent || '').includes('Learn as you screen'));
await page.screenshot({ path: '/home/claude/tips-first.png' });
// run a screen, which retires the tips
await page.evaluate(() => [...document.querySelectorAll('.run-row .btn')].find((b) => b.textContent.includes('Run screener'))?.click());
await new Promise((r) => setTimeout(r, 1800));
await page.evaluate(() => [...document.querySelectorAll('.btn')].find((b) => b.textContent.includes('Edit filters'))?.click());
await new Promise((r) => setTimeout(r, 700));
const after = await page.evaluate(() => (document.getElementById('root')?.textContent || '').includes('Learn as you screen'));
await page.screenshot({ path: '/home/claude/tips-after.png' });
// the two-column class must never beat the mobile breakpoint
const page2 = await browser.newPage();
await page2.setViewport({ width: 420, height: 820 });
await page2.goto(url, { waitUntil: 'networkidle0' });
await page2.evaluate(() => localStorage.setItem('groww-simple-screener.v1', JSON.stringify({
  profile: {}, onboardingComplete: true, coachDone: true, tipsDone: true, theme: 'light', sort: 'relevance', saved: [], sessions: 3,
  selections: { growth: 'growth-steady', stability: 'stability-low-debt' },
})));
await page2.reload({ waitUntil: 'networkidle0' });
await new Promise((r) => setTimeout(r, 500));
const mobile = await page2.evaluate(() => ({
  columns: getComputedStyle(document.querySelector('.sc-wrap')).gridTemplateColumns.split(' ').length,
  overflow: document.documentElement.scrollWidth - window.innerWidth,
}));
await browser.close();
console.log('tips on first visit:', first, '| tips after running:', after);
console.log('mobile columns (want 1):', mobile.columns, '| horizontal overflow (want 0):', mobile.overflow);
