import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const page = await browser.newPage();
await page.setViewport({ width: 1660, height: 1100 });
await page.goto('file:///mnt/user-data/outputs/groww-simplified-screener.html', { waitUntil: 'networkidle0' });
await page.evaluate(() => {
  const selections = {
    growth: 'growth-steady', stability: 'stability-stable', valuation: 'valuation-reasonable',
    momentum: 'momentum-improving', performance: 'performance-consistent', horizon: 'horizon-long',
  };
  localStorage.setItem('groww-simple-screener.v1', JSON.stringify({
    profile: {}, onboardingComplete: true, coachDone: true, theme: 'dark', sort: 'relevance', saved: [], sessions: 2,
    selections, lastRun: { selections, count: 2, at: '2026-09-19T09:00:00Z' },
  }));
});
await page.reload({ waitUntil: 'networkidle0' });
await new Promise((r) => setTimeout(r, 600));
const clickText = async (sel, t) => {
  await page.evaluate((s, t) => [...document.querySelectorAll(s)].find((e) => (e.textContent || '').toLowerCase().includes(t.toLowerCase()))?.click(), sel, t);
  await new Promise((r) => setTimeout(r, 500));
};
await clickText('.link-btn', 'See what Groww checked');
await page.screenshot({ path: '/home/claude/dark-learn.png', fullPage: true });
await browser.close();
console.log('captured');
