import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const page = await browser.newPage();
await page.setViewport({ width: 1660, height: 1000 });
await page.goto('file:///mnt/user-data/outputs/groww-simplified-screener.html', { waitUntil: 'networkidle0' });
await page.evaluate(() => {
  localStorage.setItem('groww-simple-screener.v1', JSON.stringify({
    profile: { amount: 25000 }, onboardingComplete: true, coachDone: true, theme: 'light', sort: 'relevance',
    saved: [], sessions: 2,
    selections: { growth: 'growth-steady', stability: 'stability-stable', valuation: 'valuation-reasonable', momentum: 'momentum-improving' },
    lastRun: { selections: { growth: 'growth-steady', stability: 'stability-stable', valuation: 'valuation-reasonable', momentum: 'momentum-improving' }, count: 4, at: '2026-09-18T10:00:00Z' },
  }));
});
await page.reload({ waitUntil: 'networkidle0' });
await new Promise((r) => setTimeout(r, 700));

const clickText = async (sel, text) => {
  const ok = await page.evaluate((s, t) => {
    const el = [...document.querySelectorAll(s)].find((e) => (e.textContent || '').toLowerCase().includes(t.toLowerCase()));
    if (el) { el.click(); return true; }
    return false;
  }, sel, text);
  if (!ok) throw new Error(`not found: ${text}`);
  await new Promise((r) => setTimeout(r, 450));
};

await clickText('.link-btn', 'Learn how it works');
await page.screenshot({ path: '/home/claude/learn-1.png', fullPage: true });

await clickText('.map-row__cta', 'Learn how it works');
await page.screenshot({ path: '/home/claude/learn-2.png', fullPage: true });

await clickText('.link-btn', 'Back to indicators');
await clickText('.btn', 'Back to results');
await clickText('.why-btn', 'Why it matched');
await page.screenshot({ path: '/home/claude/learn-3.png', fullPage: true });

await browser.close();
console.log('learning screens captured');
