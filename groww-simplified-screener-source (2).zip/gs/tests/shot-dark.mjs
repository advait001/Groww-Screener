import puppeteer from 'puppeteer';
const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const page = await browser.newPage();
await page.setViewport({ width: 1440, height: 940 });
await page.goto('file:///mnt/user-data/outputs/groww-simplified-screener.html', { waitUntil: 'networkidle0' });
await page.evaluate(() => {
  localStorage.setItem('groww-simple-screener.v1', JSON.stringify({
    profile: { amount: 25000, experience: 'new', horizon: '5plus' }, onboardingComplete: true, coachDone: true,
    theme: 'dark', sort: 'relevance', saved: [{ id: 's1', name: 'Steady + stable', selections: { growth: 'growth-steady', stability: 'stability-stable' }, createdAt: '2026-09-18' }], sessions: 3,
    selections: { growth: 'growth-steady', stability: 'stability-low-debt', valuation: 'valuation-cheap', performance: 'performance-steady' },
  }));
});
await page.reload({ waitUntil: 'networkidle0' });
await new Promise((r) => setTimeout(r, 800));
await page.screenshot({ path: '/home/claude/shot-dark.png' });
await browser.close();
console.log('dark captured');
