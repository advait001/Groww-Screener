# Groww Simplified Screener — concept prototype

A working prototype of a plain-English stock screener: the user describes the
company they want, the app compiles that into transparent financial rules,
runs them over a demo dataset, and explains every match.

## Run it

```bash
npm install
node build.mjs      # writes a single self-contained index.html
node dist/test.cjs      # engine checks (bundle first: see build.mjs)
node tests/ui.test.mjs  # interaction smoke test in jsdom
node tools/sweep.mjs    # walks onboarding -> results -> drawer (needs puppeteer)
node tools/verify.mjs   # coach marks, processing, learning + 720/420 widths
node tools/shot.mjs <name> <step...>   # one screenshot of any state
```

The `tools/shot-*.mjs` and `tests/shot-*.mjs` files are one-off capture scripts
kept from earlier rounds; `sweep`, `verify` and `shot` are the ones maintained
against the current markup.

## How it is put together

| Path | What lives there |
| --- | --- |
| `src/data/stocks.ts` | 1,000 synthetic companies across 20 sectors, ~60 fields each, packed columnar and expanded at load, plus the peer-group helpers (`median`, `rank`) the rules use |
| `tools/build-dataset.py` | Turns the 1,000-stock prototype register into the app's shape — published columns carried over, the rest derived or seeded per ticker |
| `tools/emit-dataset.py` | Packs that into `stocks.ts` (field list + one array per company, so 1,000 rows cost ~300 KB rather than ~1 MB of repeated keys) |
| `src/data/config.ts` | The screener itself: 13 optional categories, 73 plain-English tags (52 primary, 21 expanded), and the rules each compiles into |
| `src/data/indicators.ts` | Beginner name, how to read it, where it misleads, and the formula for each indicator |
| `src/data/profile.ts` | The five onboarding questions and what the answers are allowed to change |
| `src/data/funds.ts` | 500 invented mutual funds, 25 categories with their expected-return bands and benchmarks, and the risk x horizon allocation matrix |
| `tools/emit-funds.py` | Lifts those three tables out of a built HTML and emits the typed module, checking every allocation sums to 100 |
| `src/engine/goalPlan.ts` | The goal planner: SIP maths, the blended rate for a mix, the fund quality bar and ranking, and the four ways out when a goal is unreachable |
| `src/screens/Goal.tsx` | Invest for a goal — four questions, a live verdict panel, and the fund plan |
| `src/state/sheet.ts` | Sending rows to a Google Sheet: endpoint resolution, the no-cors POST, and the offline retry queue |
| `tools/google-sheet-endpoint.gs` | The Apps Script to paste into the sheet, with its deployment steps |
| `tools/rename-plain.py` | The plain-language pass over `config.ts` — rewrites every filter's label, chip and blurb, and every category's name, question and blurb. Re-runnable, so the wording stays one edit away |
| `tools/rename-learning.py` | The same pass over the three learning screens, which were written in the old voice |
| `src/data/templates.ts` | 12 ready-made sets — each is just a set of the same preferences a user could pick by hand, with a name, a theme and the mark its card shows |
| `src/engine/rules.ts` | Rule evaluation: sector substitution for lenders, history checks, missing data never passes |
| `src/engine/screener.ts` | Running a screen, close matches, sorting, and the relaxation / narrowing suggestions |
| `src/engine/sentence.ts` | Selections to a readable sentence with removable chips |
| `src/state/` | Reducer, localStorage persistence, analytics events |
| `src/ui/` | Header and chrome, primitives, lesson visuals, explanation components |
| `src/ui/explain.tsx` | The preference popup (one lead line plus a row per check), the full translation list, match explanations and the indicator lesson |
| `src/ui/filterPicker.tsx` | The floating filter panel — search, a category rail, and rows that can be tapped or dragged onto the statement, with the drag animated by hand (pointer events, a trailing ghost, and a landing) |
| `src/screens/` | Intro, onboarding, screener, processing, results, stock detail |
| `src/data/learning.ts` | Teaching content per indicator: plain-English title, what it means, the three "how it works" steps, and the hedged takeaway |
| `src/ui/learnVisuals.tsx` | The educational diagram library (growth bars, debt level, peer bars, trend line, gauge, and so on) |
| `src/screens/Learning.tsx` | What your filters really check — filter → the number behind it, with connectors |
| `src/screens/IndicatorLearning.tsx` | What this number means — one reusable module for every indicator |
| `src/screens/WhyMatched.tsx` | Why this stock matched — one row per filter, generated from the evaluation |
| `src/assets/logo.ts` | The Groww mark and the Screener wordmark, inlined as data URIs |
| `src/ui/companyLogo.tsx` | Generated brand marks for the fictional companies — a fixed colour pair and shape per company, so no real trademark is used |

The three learning screens share one flow. From the results page, "What the
numbers mean" opens the overview; from a result, "Why it matched" opens the
stock explanation; both lead into the same indicator module, which remembers
where it was opened from. Routes live in the reducer as `learning`,
`indicator` (with `origin` and optional `stockId`) and `whyMatched`.

Filters are chosen from one floating panel rather than a per-category list: it
searches across all 73 filters, the rail walks the 13 categories, and a row can
be tapped to add or dragged onto the statement. The panel does not block the
page behind it, which is what keeps dragging possible. The sidebar then shows
only what you picked, one row per category, each removable.

The main screen ("Explore") is two columns. The left is where the work happens:
the filters you have picked as cards, the drop zone that opens the picker, the
ready-made sets, and a live strip of companies that narrows as you choose. The
right rail is where the screen reads back to you — your picks as one sentence,
the live match count, the Run button, and the ways in. Each filter card carries
its category as a label, and tapping that label swaps the filter for a sibling
in the same group without reopening the picker.

## Theme

Dark only. There is no light palette and no theme toggle: the tokens at the top
of `src/styles/app.css` define one near-black surface set (`--bg`, `--bg-2`,
`--bg-3`), one text ramp, and Groww's mint green as the single accent. Each of
the 13 categories owns a hue, exposed as `--cat-fg` / `--cat-bg` by a
`.cat-<id>` class; gradients, icon tiles and accent bars are all derived from
that pair with `color-mix()`, so a new category needs two values and nothing
else.

## Language

Every filter, category and ready-made set is named for what it does, not for
the ratio behind it: "Grows a little every year", "Hardly borrows anything",
"Cheaper than companies like it", "Slow and steady winners". The financial
terms are not hidden — they are one tap away, in the drawer and the learning
screens, which is where a beginner meets "Revenue Growth" or "P/E vs peers"
attached to the plain phrase it came from. That split is deliberate: the
screen you build on speaks intent, and the screens that explain it teach the
vocabulary.

Rules are written in the operator set the product spec defines. Besides fixed
thresholds (`gte`, `lte`, `between`, `is_true`) there are peer-relative
operators — `percentile_gte` / `percentile_lte` rank a company inside its sector
or the whole list, and `median_ratio_lte` / `median_ratio_gte` compare it with
the peer median. A percentile rule reports the actual rank in its requirement
text ("ranks 78 out of 100 against Pharma"), so the explanation stays true to
what was computed. Sector policy is carried on the rule itself: lenders swap
debt-to-equity for capital adequacy (`substitute`) and skip interest cover and
ROCE entirely (`skip`), and rules that need history declare
`requiresHistoryYears`, so a recent listing is reported as unable to evaluate
rather than quietly failed.

Adding a new preference means adding one object to `src/data/config.ts`. The
sentence, the translation panel, the filtering, the match explanations and the
suggestion engine all pick it up without further changes.

## Invest for a goal

A second way in, beside the screener. Four questions — what it is for, how much,
how long, how bumpy a ride you can take — and the planner works out whether the
monthly amount actually gets there, then splits it across funds.

The verdict panel is live from the first answer rather than waiting for a submit,
so an impossible goal is called out while you are still typing. When the goal is
out of reach the planner says by how much and offers the four real ways out —
pay more, wait longer, take more risk, want less — each carrying the exact number.
Taking one remembers what it replaced, and the plan screen shows the change
("Every month ₹69,700, was ₹5,000") rather than quietly moving the goalposts.
Every suggestion is checked by the engine suite to actually reach the goal when
applied, because a fix that does not fix anything is worse than none.

Funds are chosen the same way stocks are: a filter, not a recommendation. Your
horizon and risk pick the categories and their weights (`ALLOCATIONS`, always
summing to 100). Inside each category, funds under ₹500 crore, over 0.75% expense
or with a negative Sharpe are dropped, the rest are ranked on Sharpe then cost
then size, and the best survivor is taken — never twice from the same fund house,
since concentrating a plan in one AMC is a risk the user did not ask for. The
monthly amount is split with a largest-remainder rule so the parts add back to the
whole rupee.

Projections always carry a band. The low / base / high rates are blended from the
categories in the mix, the chart draws the band behind the line, and the panel
shows what happens if it goes badly next to the usual case. When a goal towers
over what the money reaches, the chart pins the goal line to the top edge and
labels it rather than flattening the curve into a meaningless line.

The 500 funds are invented, every name carrying "Prototype Fund", and the Buy
flow confirms nothing: the drawer says plainly that no money moves.

## Capturing who tried it

"Get started" opens onto a name-and-email step before the profile questions —
step one of six, built from the same pieces as every other onboarding step, so
it reads as part of the flow rather than a gate in front of it. "Explore the
screener" still skips onboarding entirely and asks for nothing. A short list of
calls to action is also forwarded to a Google Sheet. All of it is optional:
with no endpoint configured the prototype behaves exactly as before and rows
simply queue locally.

**Setting it up.** Paste `tools/google-sheet-endpoint.gs` into the sheet's Apps
Script editor and deploy it as a web app ("execute as me", "anyone has
access" — the prototype posts without signing in). Then point the prototype at
the deployment URL either by opening it once with `?sheet=<url>` appended,
which remembers it in that browser, or by setting `BUILT_IN_ENDPOINT` in
`src/state/sheet.ts` and rebuilding, which bakes it in for everyone. A live
endpoint is currently baked in; replace that constant to send rows elsewhere.

Note that the deployment URL is the one on `script.google.com` ending in
`/exec`. Opening it in a browser redirects to a short-lived
`script.googleusercontent.com/macros/echo?...` address, which is the rendered
output rather than the endpoint and will not accept posts.

`tools/sheet-check.mjs` drives the built file through the gate, a screen run
and the goal tile, intercepting and aborting every request to the endpoint, so
the client side can be verified without writing rows into the live sheet.

**What gets a row.** The contact step's submit (or skip), running a screen, opening the
goal planner, submitting a goal plan, confirming the monthly plans, applying a
ready-made set, saving a screen, and opening a stock. Each row carries the
event, the name and email, a JSON detail blob, the client timestamp and a
per-visit session id. Everything else still fires into the in-app event log
but is not forwarded — a spreadsheet of every tap is not worth reading.

Two mechanics are easy to get wrong and are handled deliberately. The POST goes
out with `mode: 'no-cors'` and a `text/plain` content type, because Apps Script
does not answer CORS preflight and anything triggering one is rejected before
it arrives; the cost is an opaque response, so a request that leaves without
throwing is treated as delivered. And a send that fails — offline, endpoint not
set, script redeployed — is appended to a `localStorage` queue and flushed on
the next load rather than surfaced, because a concept demo should not interrupt
someone to report that a spreadsheet is unreachable.

**Where it will and will not work.** A hosted or locally opened copy of the
HTML file posts fine. A page served from a sandboxed context with a strict
content-security policy may have the request blocked before it leaves the
browser; the queue means nothing is lost, but nothing arrives either. Check the
sheet after a test run rather than assuming.

## Where the demo data comes from

The register publishes price, market cap, 1Y return, 3Y revenue and profit
CAGR, ROE, ROCE, D/E, P/E, sector P/E, RSI, beta and dividend yield for each of
its 1,000 companies; those are carried over untouched. Four more fields follow
by identity — P/B from P/E and ROE, payout from yield and P/E, earnings yield
and PEG from P/E — so they cannot contradict the source. Everything else the
screener needs (margins, cash conversion, coverage, consistency counts, moving
averages, ownership) is generated from a seed made of the company's own ticker
and conditioned on its sector, size, growth, quality and beta, so a high-ROCE
low-debt company also reads as one on the fields the register does not print.
Rebuild with `python3 tools/build-dataset.py && python3 tools/emit-dataset.py`.

## Ground rules encoded in the app

- No advice, predictions, or ranking of stocks by quality. Results are matches, not picks.
- P/E and P/B are judged against sector peers, never against a universal number.
- RSI below its threshold is described as oversold, with no implication of a rebound.
- Missing or not-yet-available data never counts as a pass, and says so.
- Banks and lenders swap debt-to-equity for capital adequacy, and skip interest coverage.
- Every category is optional; one option per category; nothing is auto-applied from the profile.
- Demo data throughout: fictional companies, invented figures, a labelled snapshot date.
  Company logos are generated from a per-company colour and shape, never copied from a real business.
- Match explanations are generated from the evaluation that actually ran: the
  indicator, the company's value, the threshold, and pass or fail. Failed and
  partly-met conditions are labelled as such, never quietly marked as passed.
- The main screen speaks in investment intent only. Ratios, thresholds and
  indicator names live in the translation and explanation layers, one tap away.
- The stock page carries the shape of a trade panel because the reference
  designs do, but Buy is disabled and says so: the companies are invented, and
  a prototype that filters and explains should not end in a transaction.
- The goal planner suggests fund categories and names funds that pass published
  filters. It never claims a return: every figure is a scenario with a worse and
  a better case beside it, and an unreachable goal is reported as unreachable.
- The contact step asks for a name and email but does not insist: "Skip for
  now" is there as on every other onboarding step, and skipping is recorded as
  its own event rather than silently dropped. It also sits behind "Get
  started" rather than in front of the whole prototype, so anyone who just
  wants to look around never meets it.
