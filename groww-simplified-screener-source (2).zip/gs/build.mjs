import { build } from 'esbuild';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';

mkdirSync('dist', { recursive: true });

await build({
  entryPoints: ['src/main.tsx'],
  bundle: true,
  minify: true,
  format: 'iife',
  target: ['es2020'],
  jsx: 'automatic',
  define: { 'process.env.NODE_ENV': '"production"' },
  loader: { '.css': 'css' },
  outdir: 'dist',
  logLevel: 'info',
});

const js = readFileSync('dist/main.js', 'utf8');
const css = readFileSync('dist/main.css', 'utf8');

// the tab icon is the same Groww mark the header shows, read straight out of
// the inlined asset so there is only ever one copy of it in the project
const markSource = readFileSync('src/assets/logo.ts', 'utf8');
const favicon = markSource.match(/GROWW_MARK = '(data:image\/png;base64,[A-Za-z0-9+/=]+)'/)?.[1];
if (!favicon) throw new Error('could not find GROWW_MARK in src/assets/logo.ts');

const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Groww Simplified Screener — concept prototype</title>
<meta name="description" content="A concept prototype: describe the company you want in plain words, see the financial filters it compiles into, and learn the indicators as you go. Demo data only." />
<link rel="icon apple-touch-icon" type="image/png" href="${favicon}" />
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link href="https://fonts.googleapis.com/css2?family=Hanken+Grotesk:wght@400;500;600&display=swap" rel="stylesheet" />
<style>
${css}
</style>
</head>
<body>
<a class="sr-only" href="#main">Skip to content</a>
<div id="root"></div>
<noscript>This prototype needs JavaScript: the screening rules run in the browser.</noscript>
<script>
${js}
</script>
</body>
</html>
`;

mkdirSync('/mnt/user-data/outputs', { recursive: true });
writeFileSync('/mnt/user-data/outputs/groww-simplified-screener.html', html);
console.log('single-file html bytes:', html.length);
